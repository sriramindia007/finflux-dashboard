import React, { useState, useMemo } from 'react';
import {
    Users, Banknote, AlertCircle, CheckCircle2,
    MapPin, TrendingUp, Calendar, FileText, Smartphone, Search, Briefcase, Star
} from 'lucide-react';
import KPICard from '../components/KPICard';
import { cn } from '../lib/utils';
import { COMPANY_METRICS } from '../data/mfiData';

// --- Data Types ---
interface BranchData {
    id: string;
    name: string;
    region: string;
    applications: { approved: number, received: number, approvedYtd: number, receivedYtd: number };
    disbursement: { count: number, countYtd: number, amount: number, amountYtd: number }; // amt in Cr
    collections: { due: number, paid: number, dueYtd: number, paidYtd: number, efficiency: number }; // amt in Cr
    overdue: number; // Cr
    glp: number; // Cr
    clients: { active: number, loans: number };
    meetings: { total: number, within: number, outside: number, attendance: number };
    digitalSplit: { digital: number, cash: number };
    par: { par30: number, par90: number };
    writeOff: number; // Cr
    coords: [number, number];
}

interface FieldOfficer {
    id: string;
    name: string;
    centers: number;
    clients: number;
    portfolio: number;
    par: number;
    efficiency: number;
    rating: number; // 1-5
}

// --- Dataset (Synced with mfiData.ts) ---
const BRANCHES: BranchData[] = [
    {
        id: 'b1', name: 'Bhubaneswar Main', region: 'Khordha',
        applications: { received: 1200, approved: 1050, receivedYtd: 12000, approvedYtd: 10500 },
        disbursement: { count: 980, countYtd: 8500, amount: 4.2, amountYtd: 38.0 },
        collections: { due: 1.2, paid: 1.15, dueYtd: 12.0, paidYtd: 11.5, efficiency: 95.8 },
        overdue: 0.05, glp: 47.5,
        clients: { active: 9500, loans: 11000 },
        meetings: { total: 120, within: 110, outside: 10, attendance: 92 },
        digitalSplit: { digital: 65, cash: 35 },
        par: { par30: 3.2, par90: 1.1 },
        writeOff: 0.06,
        coords: [20.2961, 85.8245]
    },
    {
        id: 'b2', name: 'Cuttack Central', region: 'Cuttack',
        applications: { received: 1100, approved: 1000, receivedYtd: 11000, approvedYtd: 10000 },
        disbursement: { count: 950, countYtd: 8200, amount: 4.0, amountYtd: 36.0 },
        collections: { due: 1.1, paid: 1.05, dueYtd: 11.0, paidYtd: 10.5, efficiency: 95.5 },
        overdue: 0.05, glp: 45.0,
        clients: { active: 9000, loans: 10500 },
        meetings: { total: 115, within: 107, outside: 8, attendance: 91 },
        digitalSplit: { digital: 64, cash: 36 },
        par: { par30: 2.8, par90: 0.9 },
        writeOff: 0.05,
        coords: [20.4625, 85.8828]
    },
    {
        id: 'b3', name: 'Patna Central', region: 'Patna',
        applications: { received: 950, approved: 800, receivedYtd: 9500, approvedYtd: 8000 },
        disbursement: { count: 700, countYtd: 7000, amount: 2.5, amountYtd: 25.0 },
        collections: { due: 0.9, paid: 0.82, dueYtd: 9.0, paidYtd: 8.2, efficiency: 91.1 },
        overdue: 0.08, glp: 32.0,
        clients: { active: 6500, loans: 7000 },
        meetings: { total: 95, within: 85, outside: 10, attendance: 89 },
        digitalSplit: { digital: 45, cash: 55 },
        par: { par30: 4.2, par90: 1.5 },
        writeOff: 0.08,
        coords: [25.5941, 85.1376]
    },
    {
        id: 'b4', name: 'Puri Branch', region: 'Puri',
        applications: { received: 880, approved: 750, receivedYtd: 8800, approvedYtd: 7500 },
        disbursement: { count: 650, countYtd: 6500, amount: 2.2, amountYtd: 22.0 },
        collections: { due: 0.8, paid: 0.76, dueYtd: 8.0, paidYtd: 7.6, efficiency: 95.0 },
        overdue: 0.04, glp: 28.5,
        clients: { active: 5800, loans: 6200 },
        meetings: { total: 85, within: 80, outside: 5, attendance: 90 },
        digitalSplit: { digital: 70, cash: 30 },
        par: { par30: 2.5, par90: 0.8 },
        writeOff: 0.03,
        coords: [19.8135, 85.8312]
    },
    {
        id: 'b5', name: 'Ranchi Main', region: 'Ranchi',
        applications: { received: 850, approved: 700, receivedYtd: 8500, approvedYtd: 7000 },
        disbursement: { count: 620, countYtd: 6200, amount: 2.0, amountYtd: 20.0 },
        collections: { due: 0.7, paid: 0.65, dueYtd: 7.0, paidYtd: 6.5, efficiency: 92.8 },
        overdue: 0.05, glp: 26.0,
        clients: { active: 5500, loans: 6000 },
        meetings: { total: 80, within: 75, outside: 5, attendance: 88 },
        digitalSplit: { digital: 55, cash: 45 },
        par: { par30: 3.8, par90: 1.2 },
        writeOff: 0.05,
        coords: [23.3441, 85.3096]
    }
];

const BranchDashboard = () => {
    const [selectedBranch, setSelectedBranch] = useState<BranchData>(BRANCHES[0]);
    const [searchQuery, setSearchQuery] = useState('');

    // Filter branches
    const filteredBranches = BRANCHES.filter(b =>
        b.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        b.region.toLowerCase().includes(searchQuery.toLowerCase())
    );

    // Format helpers
    const fmtCr = (v: number) => `₹${v} Cr`;
    const fmtK = (v: number) => `${(v / 1000).toFixed(0)}k`;

    // Mock Field Officers Generator (Dynamic based on Company Metrics apportionment)
    const fieldOfficers: FieldOfficer[] = useMemo(() => {
        // Apportion logic: Total Employees (13668) / Total Branches (1636) ~ 8.35 per branch
        const avgStaffCount = Math.round(COMPANY_METRICS.totalEmployees / COMPANY_METRICS.totalBranches);
        // Add some variance per branch (e.g. 7 to 9)
        const branchStaffCount = avgStaffCount + (selectedBranch.name.length % 3 - 1);

        const baseNames = [
            'Rajesh Kumar', 'Anita Das', 'Suresh Malik', 'Priya Singh', 'Amit Nayak',
            'Kiran Bedi', 'Rahul Verma', 'Sneha Gupta', 'Vikram Rathore', 'Pooja Sharma',
            'Manish Tiwari', 'Deepa Reddy'
        ];

        return Array.from({ length: branchStaffCount }).map((_, idx) => ({
            id: `fo-${idx}`,
            name: baseNames[idx % baseNames.length],
            centers: Math.floor(selectedBranch.meetings.total / branchStaffCount) + (idx % 2),
            clients: Math.floor(selectedBranch.clients.active / branchStaffCount) + Math.floor(Math.random() * 20),
            portfolio: (selectedBranch.glp / branchStaffCount) + (Math.random() - 0.5),
            par: Math.max(0, selectedBranch.par.par30 + (Math.random() * 2 - 1)).toFixed(1) as any,
            efficiency: Math.min(100, selectedBranch.collections.efficiency + (Math.random() * 4 - 2)).toFixed(1) as any,
            rating: 5 - (idx % 3)
        }));
    }, [selectedBranch]);

    return (
        <div className="flex flex-col lg:flex-row gap-6 h-auto lg:h-[calc(100vh-100px)]">
            {/* Sidebar List (Top Branches) */}
            <div className="w-full lg:w-80 bg-white rounded-xl border border-secondary-200 shadow-sm overflow-hidden flex flex-col shrink-0">
                <div className="p-4 border-b border-secondary-200 bg-secondary-50">
                    <h3 className="font-bold text-secondary-900 mb-2">Branch Network</h3>
                    <div className="relative">
                        <Search className="absolute left-3 top-2.5 text-secondary-400" size={16} />
                        <input
                            type="text"
                            placeholder="Search branch..."
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                            className="w-full pl-9 pr-4 py-2 bg-secondary-50 border border-secondary-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary-500 transition-all"
                        />
                    </div>
                </div>
                <div className="overflow-y-auto flex-1">
                    {filteredBranches.length > 0 ? filteredBranches.map(branch => (
                        <div
                            key={branch.id}
                            onClick={() => setSelectedBranch(branch)}
                            className={cn(
                                "p-4 border-b border-secondary-100 cursor-pointer transition-colors hover:bg-secondary-50",
                                selectedBranch.id === branch.id ? "bg-primary-50 border-l-4 border-l-primary-500" : "border-l-4 border-l-transparent"
                            )}
                        >
                            <div className="flex justify-between items-start mb-1">
                                <h4 className={cn("font-medium", selectedBranch.id === branch.id ? "text-primary-900" : "text-secondary-900")}>{branch.name}</h4>
                                <span className="text-xs font-semibold bg-secondary-100 px-2 py-0.5 rounded text-secondary-600">{fmtCr(branch.glp)}</span>
                            </div>
                            <div className="flex justify-between text-xs text-secondary-500">
                                <span>{branch.region}</span>
                                <span>{fmtK(branch.clients.active)} Clients</span>
                            </div>
                        </div>
                    )) : (
                        <div className="p-8 text-center text-secondary-500 text-sm">
                            No branches found matching "{searchQuery}"
                        </div>
                    )}
                </div>
            </div>

            {/* Main Details View */}
            <div className="flex-1 overflow-y-auto space-y-6">
                {/* Header & Mini Map Header */}
                <div className="flex items-start justify-between bg-white p-6 rounded-xl border border-secondary-200 shadow-sm">
                    <div>
                        <div className="flex items-center gap-3 mb-2">
                            <h2 className="text-2xl font-bold text-secondary-900">{selectedBranch.name} Branch</h2>
                            <span className="px-3 py-1 bg-primary-100 text-primary-700 rounded-full text-xs font-bold uppercase tracking-wider">{selectedBranch.region} District</span>
                        </div>
                        <p className="text-secondary-500 flex items-center gap-2"><MapPin size={16} /> Branch Code: {selectedBranch.id.toUpperCase()}-AFPL-2025</p>
                    </div>

                    <div className="text-right">
                        <div className="text-sm text-secondary-500">Branch GLP</div>
                        <div className="text-3xl font-bold text-primary-600">{fmtCr(selectedBranch.glp)}</div>
                    </div>
                </div>

                {/* KPI Grid 1: Business Growth */}
                <h3 className="text-lg font-semibold text-secondary-800">Business Growth (MTD)</h3>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <KPICard title="Applications" value={selectedBranch.applications.received.toString()} subValue={`Appr: ${selectedBranch.applications.approved}`} icon={FileText} />
                    <KPICard title="Disbursed Loans" value={selectedBranch.disbursement.count.toString()} subValue={`Value: ${fmtCr(selectedBranch.disbursement.amount)}`} icon={CheckCircle2} />
                    <KPICard title="Active Clients" value={fmtK(selectedBranch.clients.active)} subValue={`Loans: ${fmtK(selectedBranch.clients.loans)}`} icon={Users} />
                    <KPICard title="Attendance" value={`${selectedBranch.meetings.attendance}%`} subValue={`${selectedBranch.meetings.total} Meetings`} icon={Calendar}
                        className={selectedBranch.meetings.attendance < 90 ? "border-l-4 border-l-amber-500" : "border-l-4 border-l-emerald-500"} />
                </div>

                {/* KPI Grid 2: Financials & Collections */}
                <h3 className="text-lg font-semibold text-secondary-800 flex items-center gap-2">Financial Performance <span className="text-xs font-normal text-secondary-500">(MTD)</span></h3>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <KPICard title="Collection Eff." value={`${selectedBranch.collections.efficiency}%`}
                        subValue={`Due: ${fmtCr(selectedBranch.collections.due)}`} icon={TrendingUp}
                        className={selectedBranch.collections.efficiency >= 95.5 ? "text-emerald-600" : "text-amber-600"} />

                    <KPICard title="Collections Paid" value={fmtCr(selectedBranch.collections.paid)} trend="neutral" trendValue="MTD" icon={Banknote} />
                    <KPICard title="Overdue" value={fmtCr(selectedBranch.overdue)} trend="down" trendValue="Critical" icon={AlertCircle} className="text-rose-600" />
                    <KPICard title="Write-offs (YTD)" value={fmtCr(selectedBranch.writeOff)} icon={Banknote} />
                </div>

                {/* Field Staff Productivity (New Section) */}
                <div className="bg-white rounded-xl border border-secondary-200 shadow-sm overflow-hidden">
                    <div className="p-6 border-b border-secondary-200 bg-secondary-50 flex justify-between items-center">
                        <div className="flex items-center gap-2">
                            <Briefcase size={18} className="text-primary-600" />
                            <div>
                                <h3 className="font-bold text-secondary-900">Field Staff Productivity</h3>
                                <p className="text-xs text-secondary-500">Apportioned based on Total Staff/Branches (~{Math.round(COMPANY_METRICS.totalEmployees / COMPANY_METRICS.totalBranches)} officers)</p>
                            </div>
                        </div>
                        <button className="text-sm text-primary-600 font-medium hover:underline">View All Officers</button>
                    </div>
                    <div className="overflow-x-auto">
                        <table className="w-full text-left text-sm">
                            <thead className="bg-secondary-100 text-secondary-600 font-semibold border-b border-secondary-200">
                                <tr>
                                    <th className="px-6 py-3">Field Officer</th>
                                    <th className="px-6 py-3 text-right">Centers</th>
                                    <th className="px-6 py-3 text-right">Active Clients</th>
                                    <th className="px-6 py-3 text-right">Portfolio (Cr)</th>
                                    <th className="px-6 py-3 text-right">Coll. Eff %</th>
                                    <th className="px-6 py-3 text-right">PAR %</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-secondary-50">
                                {fieldOfficers.map((fo) => (
                                    <tr key={fo.id} className="hover:bg-secondary-50 transition-colors">
                                        <td className="px-6 py-4 font-medium text-secondary-900 flex items-center gap-2">
                                            {fo.rating >= 5 && <Star size={14} className="text-amber-500 fill-amber-500" />}
                                            {fo.name}
                                        </td>
                                        <td className="px-6 py-4 text-right text-secondary-600">{fo.centers}</td>
                                        <td className="px-6 py-4 text-right text-secondary-600">{fmtK(fo.clients)}</td>
                                        <td className="px-6 py-4 text-right font-medium">₹{fo.portfolio.toFixed(2)}</td>
                                        <td className={`px-6 py-4 text-right font-bold ${fo.efficiency >= 98 ? 'text-emerald-600' : 'text-amber-600'}`}>
                                            {fo.efficiency}%
                                        </td>
                                        <td className={`px-6 py-4 text-right ${fo.par < 2 ? 'text-emerald-600' : 'text-rose-600'}`}>
                                            {fo.par}%
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>

                {/* Risk & Operations Grids */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    {/* Geo-Fencing Stats */}
                    <div className="bg-white p-6 rounded-xl border border-secondary-200 shadow-sm">
                        <h4 className="font-semibold text-secondary-800 mb-4 flex justify-between">
                            <span>Centre Meeting Compliance</span>
                            <span className="text-sm font-normal text-secondary-500">Geo-Fence Validation</span>
                        </h4>
                        <div className="flex items-center gap-6">
                            <div className="relative w-32 h-32 flex items-center justify-center rounded-full border-8 border-emerald-100">
                                <span className="text-2xl font-bold text-emerald-600">{Math.round((selectedBranch.meetings.within / selectedBranch.meetings.total) * 100)}%</span>
                            </div>
                            <div className="space-y-3 flex-1">
                                <div className="flex justify-between items-center text-sm">
                                    <span className="text-secondary-600">Within Fence</span>
                                    <span className="font-bold text-emerald-600">{selectedBranch.meetings.within}</span>
                                </div>
                                <div className="w-full bg-secondary-100 h-2 rounded-full overflow-hidden">
                                    <div className="h-full bg-emerald-500" style={{ width: `${(selectedBranch.meetings.within / selectedBranch.meetings.total) * 100}%` }}></div>
                                </div>
                                <div className="flex justify-between items-center text-sm">
                                    <span className="text-secondary-600">Outside Fence</span>
                                    <span className="font-bold text-rose-600">{selectedBranch.meetings.outside}</span>
                                </div>
                                <div className="w-full bg-secondary-100 h-2 rounded-full overflow-hidden">
                                    <div className="h-full bg-rose-500" style={{ width: `${(selectedBranch.meetings.outside / selectedBranch.meetings.total) * 100}%` }}></div>
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* PAR & Digital Stats */}
                    <div className="bg-white p-6 rounded-xl border border-secondary-200 shadow-sm space-y-6">
                        <div>
                            <h4 className="font-semibold text-secondary-800 mb-3">Portfolio at Risk (PAR)</h4>
                            <div className="flex gap-4">
                                <div className="flex-1 p-3 bg-rose-50 rounded-lg border border-rose-100 text-center">
                                    <div className="text-xs text-rose-600 uppercase font-bold tracking-wider">PAR {'>'} 30</div>
                                    <div className="text-xl font-bold text-rose-700">{selectedBranch.par.par30}%</div>
                                </div>
                                <div className="flex-1 p-3 bg-rose-50 rounded-lg border border-rose-100 text-center">
                                    <div className="text-xs text-rose-600 uppercase font-bold tracking-wider">PAR {'>'} 90</div>
                                    <div className="text-xl font-bold text-rose-700">{selectedBranch.par.par90}%</div>
                                </div>
                            </div>
                        </div>

                        <div>
                            <h4 className="font-semibold text-secondary-800 mb-3">Repayment Mode</h4>
                            <div className="flex items-center gap-4">
                                <div className="flex items-center gap-2">
                                    <Smartphone className="text-primary-500" size={20} />
                                    <div>
                                        <div className="text-xs text-secondary-500">Digital</div>
                                        <div className="font-bold">{selectedBranch.digitalSplit.digital}%</div>
                                    </div>
                                </div>
                                <div className="flex-1 h-3 bg-secondary-100 rounded-full overflow-hidden flex">
                                    <div className="bg-primary-500 h-full" style={{ width: `${selectedBranch.digitalSplit.digital}%` }}></div>
                                    <div className="bg-emerald-500 h-full" style={{ width: `${selectedBranch.digitalSplit.cash}%` }}></div>
                                </div>
                                <div className="flex items-center gap-2">
                                    <Banknote className="text-emerald-500" size={20} />
                                    <div>
                                        <div className="text-xs text-secondary-500">Cash</div>
                                        <div className="font-bold">{selectedBranch.digitalSplit.cash}%</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default BranchDashboard;
