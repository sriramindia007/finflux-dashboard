const fs = require('fs');
const path = require('path');

const dir = path.join(__dirname, 'src', 'pages');
const files = fs.readdirSync(dir).filter(f => f.endsWith('Dashboard.tsx'));

files.forEach(file => {
    const filePath = path.join(dir, file);
    let content = fs.readFileSync(filePath, 'utf8');
    let modified = false;

    // 1. Add saveFile import if not already there
    if (!content.includes('import { saveFile }')) {
        const lines = content.split('\n');
        // Find last react import or lucide import
        let targetIndex = Object.values(lines).findLastIndex(l => l.includes("from 'lucide-react';"));
        if (targetIndex === -1) {
            targetIndex = Object.values(lines).findLastIndex(l => l.includes("from 'react'"));
        }

        if (targetIndex !== -1) {
            lines.splice(targetIndex + 1, 0, "import { saveFile } from '../lib/utils';");
            content = lines.join('\n');
            modified = true;
        }
    }

    // 2. Excel
    const excelTarget = "XLSX.writeFile(wb, getFilename('xlsx'));";
    if (content.includes(excelTarget)) {
        const excelReplacement = `const out = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
        saveFile(new Blob([out], { type: 'application/octet-stream' }), getFilename('xlsx'));`;
        content = content.replace(excelTarget, excelReplacement);
        modified = true;
    }

    // 3. PDF
    const pdfTarget = "pdf.save(getFilename('pdf'));";
    if (content.includes(pdfTarget)) {
        const pdfReplacement = "saveFile(pdf.output('blob'), getFilename('pdf'));";
        content = content.replace(pdfTarget, pdfReplacement);
        modified = true;
    }

    // 4. PPT (two possible formations)
    const pptTarget1 = 'pptx.writeFile({ fileName: getFilename(\'pptx\') }).catch((err: any) => console.error("PPT Error:", err));';
    if (content.includes(pptTarget1)) {
        const pptReplacement1 = `const blob = (await pptx.write('blob')) as Blob;
            saveFile(blob, getFilename('pptx'));`;
        content = content.replace(pptTarget1, pptReplacement1);
        modified = true;
    }

    const pptTarget2 = 'pptx.writeFile({ fileName: getFilename(\'pptx\') }).catch((err) => console.error("PPT Error:", err));';
    if (content.includes(pptTarget2)) {
        const pptReplacement2 = `const blob = (await pptx.write('blob')) as Blob;
            saveFile(blob, getFilename('pptx'));`;
        content = content.replace(pptTarget2, pptReplacement2);
        modified = true;
    }

    if (modified) {
        fs.writeFileSync(filePath, content, 'utf8');
        console.log(`Updated ${file}`);
    }
});
