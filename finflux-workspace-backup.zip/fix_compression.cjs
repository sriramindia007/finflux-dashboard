const fs = require('fs');
const path = require('path');
const dir = path.join(__dirname, 'src', 'pages');

const files = fs.readdirSync(dir).filter(f => f.endsWith('Dashboard.tsx'));
files.forEach(file => {
    let content = fs.readFileSync(path.join(dir, file), 'utf8');

    // Upgrade image compression across all manual toDataURL calls
    if (content.includes("'image/jpeg', 1.0")) {
        content = content.replace(/'image\/jpeg', 1\.0/g, "'image/jpeg', 0.80");
        fs.writeFileSync(path.join(dir, file), content, 'utf8');
        console.log("Compressed images in", file);
    }
});
