const fs=require('fs');
const c=fs.readFileSync('src/pages/PortfolioDashboard.tsx','utf8');
console.log('vintage found:', c.includes('vintage'));
console.log('regulatory found:', c.includes('regulatory'));
console.log('activeTab vintage found:', c.includes("activeTab === 'vintage'"));
console.log('tab entries:', (c.match(/key:/g)||[]).length);
console.log('total lines:', c.split('\n').length);
console.log('stateType:', c.includes("'portfolio' | 'audit' | 'vintage'"));
