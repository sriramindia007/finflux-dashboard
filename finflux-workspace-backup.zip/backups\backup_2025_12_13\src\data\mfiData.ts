/**
 * FINFLUX Analytics - Centralized Data Model
 * Updated with FY2025 Financials & Extended State Coverage
 */

export interface HistoricalYear {
    year: string;
    aum: number | string;
    disbursement: number | string;
    branches: number | string;
    borrowing: number | string;
    profit: number | string;
    assets: number | string;
    gnpa: string;
    car: string;
}

export const HISTORICAL_DATA: HistoricalYear[] = [
    { year: 'FY 2021', aum: '-', disbursement: '-', branches: 870, borrowing: 4569, profit: 193, assets: '-', gnpa: '3.04%', car: '-' },
    { year: 'FY 2022', aum: '-', disbursement: '-', branches: 984, borrowing: 5513, profit: 218, assets: '-', gnpa: '5.84%', car: '-' },
    { year: 'FY 2023', aum: '-', disbursement: '-', branches: 1183, borrowing: 6534, profit: 406, assets: '-', gnpa: '3.84%', car: '-' },
    { year: 'FY 2024', aum: '-', disbursement: '-', branches: 1379, borrowing: 6755, profit: 639, assets: '-', gnpa: '2.9%', car: '-' },
    { year: 'FY 2025', aum: 11034, disbursement: 8939, branches: 1636, borrowing: 6820, profit: 517, assets: 8946, gnpa: '2.7%', car: '29.61%' },
];

export const COMPANY_METRICS = {
    // Current Portfolio (FY 2025)
    currentGLP: 11034.0, // AUM in Crores
    totalAssets: 8946,
    borrowingOutstanding: 6820,

    // Performance
    ytdDisbursement: 8939,
    ytdCollection: 9200, // Estimated based on efficiency
    opProfit: 517.0,

    // Portfolio Quality
    gnpa: 2.7, // Gross NPA %
    car: 29.61, // Capital Adequacy %
    parOver30: 2.7, // Aligned with GNPA for dashboard consistency

    // Scale
    activeClients: 2900000,
    totalBranches: 1636, // Verified FY25
    newBranchesFY25: 180, // Approximate sum of new branches provided
    totalEmployees: 13668,
    totalDistricts: 110, // Expanded presence
    totalStates: 16,

    // Granular Portfolio Metrics (New)
    securedSplit: { secured: 64, unsecured: 36 },
    fundingProfile: {
        publicBanks: 46.49,
        privateBanks: 28.68,
        nbfcs: 13.28,
        others: 11.55 // Balancing figure
    },
    demographics: {
        general: 54.9,
        scSt: 37.0,
        minority: 8.1
    },
    collectionEfficiencyMsme: 91.28,

    // Impact & Operations (New)
    impactStats: {
        swasth: 45200, // Sanitation loans
        samarth: 12500, // Disability support
        solar: 8900    // Green energy
    },
    digitalAdoption: 74.2, // % Cashless
    concentrationShare: 52.5, // Top 3 States %
};

export interface StateMetrics {
    name: string;
    glp: number;
    branches: number;
    newBranchesFY25?: number; // New field
    msmeBranches?: number; // New field
    msmeGlp?: number; // New field
    districts: number;
    par30: number;
    riskNote?: string; // New field
    mfiPresence: boolean;
    coords: [number, number];
}

// State Data - GLP distributed to sum ~11,034 Cr
export const STATES_DATA: Record<string, StateMetrics> = {
    odisha: {
        name: 'Odisha',
        glp: 2800,
        branches: 350, // Est
        newBranchesFY25: 63,
        msmeBranches: 10,
        msmeGlp: 90.00,
        districts: 30,
        par30: 2.1,
        riskNote: 'Top 3 Concentration State',
        mfiPresence: true,
        coords: [20.9517, 85.0985]
    },
    bihar: {
        name: 'Bihar',
        glp: 1800,
        branches: 220, // Est
        newBranchesFY25: 63,
        msmeBranches: 5,
        msmeGlp: 48.65,
        districts: 15,
        par30: 3.2,
        riskNote: 'High Risk: 21-23% AUM Concentration',
        mfiPresence: true,
        coords: [25.0961, 85.3131]
    },
    madhyaPradesh: {
        name: 'Madhya Pradesh',
        glp: 1200,
        branches: 180, // Est
        msmeBranches: 15,
        msmeGlp: 103.57,
        districts: 12,
        par30: 2.4,
        riskNote: 'Top 3 Concentration State',
        mfiPresence: true,
        coords: [22.9734, 78.6569]
    },
    westBengal: {
        name: 'West Bengal',
        glp: 950,
        branches: 150, // Est
        msmeBranches: 37,
        msmeGlp: 332.31,
        districts: 10,
        par30: 2.6,
        riskNote: 'High MSME Volume',
        mfiPresence: true,
        coords: [22.9868, 87.8550]
    },
    gujarat: {
        name: 'Gujarat',
        glp: 850,
        branches: 209, // Verified
        msmeBranches: 24,
        msmeGlp: 182.25,
        districts: 15,
        par30: 1.9,
        mfiPresence: true,
        coords: [22.2587, 71.1924]
    },
    rajasthan: {
        name: 'Rajasthan',
        glp: 800,
        branches: 146, // Verified
        msmeBranches: 12,
        msmeGlp: 254.41,
        districts: 12,
        par30: 2.0,
        mfiPresence: true,
        coords: [27.0238, 74.2179]
    },
    telangana: {
        name: 'Telangana',
        glp: 600,
        branches: 90, // Est
        newBranchesFY25: 29,
        msmeBranches: 26,
        msmeGlp: 272.47,
        districts: 8,
        par30: 2.2,
        riskNote: 'High Growth Area',
        mfiPresence: true,
        coords: [18.1124, 79.0193]
    },
    maharashtra: {
        name: 'Maharashtra',
        glp: 550,
        branches: 110, // Est
        msmeBranches: 31,
        msmeGlp: 156.84,
        districts: 10,
        par30: 2.3,
        mfiPresence: true,
        coords: [19.7515, 75.7139]
    },
    karnataka: {
        name: 'Karnataka',
        glp: 500,
        branches: 80, // Est
        msmeBranches: 12,
        msmeGlp: 165.12,
        districts: 8,
        par30: 2.1,
        mfiPresence: true,
        coords: [15.3173, 75.7139]
    },
    uttarPradesh: {
        name: 'Uttar Pradesh',
        glp: 400,
        branches: 75, // Est
        newBranchesFY25: 22,
        msmeBranches: 3,
        msmeGlp: 22.77,
        districts: 10,
        par30: 2.8,
        riskNote: 'Growth Focus',
        mfiPresence: true,
        coords: [26.8467, 80.9462]
    },
    tamilNadu: {
        name: 'Tamil Nadu',
        glp: 350,
        branches: 60, // Est
        msmeBranches: 7,
        msmeGlp: 76.56,
        districts: 6,
        par30: 1.8,
        mfiPresence: true,
        coords: [11.1271, 78.6569]
    },
    chhattisgarh: {
        name: 'Chhattisgarh',
        glp: 300,
        branches: 50, // Est
        msmeBranches: 6,
        msmeGlp: 57.62,
        districts: 5,
        par30: 2.5,
        mfiPresence: true,
        coords: [21.2787, 81.8661]
    },
    punjab: {
        name: 'Punjab',
        glp: 200,
        branches: 47, // Verified
        msmeBranches: 0,
        msmeGlp: 0,
        districts: 5,
        par30: 2.2,
        mfiPresence: true,
        coords: [31.1471, 75.3412]
    },
    haryana: {
        name: 'Haryana',
        glp: 150,
        branches: 39, // Verified
        msmeBranches: 0,
        msmeGlp: 0,
        districts: 4,
        par30: 2.1,
        mfiPresence: true,
        coords: [29.0588, 76.0856]
    },
    andhra: {
        name: 'Andhra Pradesh',
        glp: 100,
        branches: 25, // Reduced presence?
        msmeBranches: 4,
        msmeGlp: 14.62,
        districts: 3,
        par30: 2.5,
        mfiPresence: true,
        coords: [15.9129, 79.7400]
    },
    himachal: {
        name: 'Himachal Pradesh',
        glp: 50,
        branches: 16, // Verified
        msmeBranches: 6,
        msmeGlp: 15.94,
        districts: 2,
        par30: 1.5,
        mfiPresence: true,
        coords: [31.1048, 77.1734]
    }
};

export const PRODUCTS_LIST = [
    { id: 'p1', name: 'Group Loans (SHG/JLG)', category: 'Microfinance', description: 'Livelihood support for rural women' },
    { id: 'p2', name: 'MSME Business Loan', category: 'MSME', description: 'Working capital for small enterprises' },
    { id: 'p3', name: 'Housing Loan', category: 'Housing', description: 'Construction, renovation, and purchase' },
    { id: 'p4', name: 'Samarth (Disability Support)', category: 'Special', description: 'Livelihood for differently-abled' },
    { id: 'p5', name: 'SWASTH (Water & Sanitation)', category: 'Development', description: 'Sanitation infrastructure loans' },
    { id: 'p6', name: 'Dairy Development', category: 'Agriculture', description: 'Cattle purchase and dairy infra' },
    { id: 'p7', name: 'Rooftop Solar', category: 'Green Energy', description: 'Solar installation financing' },
    { id: 'p8', name: 'Just in Time (JIT) Loan', category: 'Emergency', description: 'Quick access emergency credit' },
    { id: 'p9', name: 'Home Improvement', category: 'Housing', description: 'Repairs and extensions' },
    { id: 'p10', name: 'Education Loan (ASEL)', category: 'Education', description: 'Vocational training fee support' },
];

export const TOP_BRANCHES = [
    { name: 'Bhubaneswar Urban', state: 'Odisha', district: 'Bhubaneswar', glp: 50.0, activeLoans: 12000, par30: 1.8 },
    { name: 'Patna Central', state: 'Bihar', district: 'Patna', glp: 48.0, activeLoans: 11500, par30: 2.1 },
    { name: 'Indore Market', state: 'Madhya Pradesh', district: 'Indore', glp: 45.0, activeLoans: 10800, par30: 2.4 },
    { name: 'Jaipur Pink City', state: 'Rajasthan', district: 'Jaipur', glp: 42.0, activeLoans: 10000, par30: 1.9 },
    { name: 'Kolkata Metro', state: 'West Bengal', district: 'Kolkata', glp: 40.5, activeLoans: 9500, par30: 2.2 },
];
