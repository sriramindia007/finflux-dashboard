import React, { useState, useEffect } from 'react';
import { MapContainer, TileLayer, Circle, CircleMarker, Popup, useMap, Marker } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import {
    Layout, TrendingUp, AlertCircle, ChevronRight, Layers,
    ArrowLeft, Users, Landmark, LocateFixed, Globe, ArrowUpRight
} from 'lucide-react';
import { ALL_STATES_DATA } from '../data/geoDataComplete';
import { Icon } from 'leaflet';
import markerIconPng from "leaflet/dist/images/marker-icon.png";
import { cn } from '../lib/utils';
import { COMPANY_METRICS, STATES_DATA } from '../data/mfiData';

// --- Assets ---
const icon = new Icon({
    iconUrl: markerIconPng,
    iconSize: [25, 41],
    iconAnchor: [12, 41]
});

// Generate Missing States from MFI Data
const MISSING_STATES = Object.entries(STATES_DATA).map(([name, data]) => ({
    name: name,
    coord: data.coords,
    glp: data.currentGLP || 1000,
    districts: []
}));

// --- Types ---
type GeoLevel = 'Country' | 'State' | 'Zone' | 'District' | 'Branch' | 'Village' | 'Centre' | 'Group' | 'Customer';

// ... (GeoEntity Intact) ...

// --- Configuration ---
const LEVELS: GeoLevel[] = ['Country', 'State', 'Zone', 'District', 'Branch', 'Village', 'Centre', 'Group', 'Customer'];
// Smoother Zoom Steps
const ZOOM_LEVELS: Record<GeoLevel, number> = {
    'Country': 5,
    'State': 6,
    'Zone': 7,    // +1
    'District': 8, // +1
    'Branch': 10,  // +2
    'Village': 12, // +2
    'Centre': 14,  // +2
    'Group': 16,   // +2
    'Customer': 18 // +2
};

// ... (Helper Components) ...

const fetchLevelData = (parent: GeoEntity | null, level: GeoLevel) => {
    // 1. Root
    if (!parent || level === 'State') {
        // Merge with ALL_STATES_DATA (checking for duplicates by name)
        const existingNames = new Set(ALL_STATES_DATA.map(s => s.name));
        const mergedStates = [...ALL_STATES_DATA];

        MISSING_STATES.forEach(ms => {
            if (!existingNames.has(ms.name)) {
                mergedStates.push(ms as any);
            }
        });

        return mergedStates.map(s => ({
            id: s.name, name: s.name, level: 'State',
            glp: s.glp, par30: s.districts?.[0]?.par30 || 2.1,
            clients: Math.round(s.glp * 250),
            coord: s.coord, childrenCount: 15,
            data: s
        } as GeoEntity));
    }

    // 2. Real Data & Hierarchy
    let entities: GeoEntity[] = [];
    let realChildren: any[] = [];
    let targetCount = 5;

    // Hierarchy: State -> Zone -> District -> Branch -> Village -> Centre ...

    if (parent && parent.data) {

        // State -> Zone (Wrapper for Districts)
        if (level === 'Zone' && parent.data.districts) {
            // Create a single Zone for Simplicity for Real Data
            entities = [{
                id: `${parent.id}-Zone-Main`,
                name: `${parent.name} Zone`,
                level: 'Zone',
                coord: parent.coord,
                glp: parent.glp,
                clients: parent.clients,
                par30: parent.par30,
                data: { districts: parent.data.districts }, // Pass districts down
                childrenCount: parent.data.districts.length
            } as GeoEntity];
            return entities;
        }

        // Zone -> District (Real Districts)
        else if (level === 'District' && parent.data.districts) {
            realChildren = parent.data.districts;
            targetCount = Math.max(realChildren.length + 5, 8);
        }

        // District -> Branch (Real Branches)
        else if (level === 'Branch' && parent.data.branches) {
            realChildren = parent.data.branches;
            targetCount = 10;
        }

        // Branch -> Village (Wrapper for Centres)
        else if (level === 'Village' && parent.data.centres) {
            entities = [{
                id: `${parent.id}-Village-Main`,
                name: `${parent.name} Village`,
                level: 'Village',
                coord: parent.coord,
                glp: parent.glp,
                clients: parent.clients,
                par30: parent.par30,
                data: { centres: parent.data.centres },
                childrenCount: parent.data.centres.length
            } as GeoEntity];
            return entities;
        }

        // Village -> Centre (Real Centres)
        else if (level === 'Centre' && parent.data.centres) {
            realChildren = parent.data.centres;
            targetCount = 20;
        }

        if (realChildren.length > 0) {
            entities = realChildren.map(child => ({
                id: `${level}-${child.name}`,
                name: child.name,
                level: level,
                coord: child.coord,
                glp: child.glp,
                clients: child.clients || 0,
                par30: child.par30 || (parent.par30 + (Math.random() * 0.5 - 0.25)),
                data: child,
                compliance: (level === 'Centre') ? (Math.random() > 0.15 ? 'within' : 'outside') : undefined
            } as GeoEntity));
        }
    }

    // Procedural Fallback
    if (entities.length === 0) {
        if (level === 'Zone') targetCount = 3 + Math.floor(Math.random() * 3);
        if (level === 'District') targetCount = 10 + Math.floor(Math.random() * 6);
        if (level === 'Branch') targetCount = 8 + Math.floor(Math.random() * 5);
        if (level === 'Village') targetCount = 10 + Math.floor(Math.random() * 6);
        if (level === 'Centre') targetCount = 15 + Math.floor(Math.random() * 8);
        if (level === 'Group') targetCount = 12 + Math.floor(Math.random() * 5); // 12-17 groups per center
        if (level === 'Customer') targetCount = 8 + Math.floor(Math.random() * 5); // 8-13 customers per group
    }

    // 3. Filler Generation (Prune duplicates)
    const fillerCount = Math.max(0, targetCount - entities.length);
    const existingNames = new Set(entities.map(e => e.name));

    // Tweaked Radii for better visibility
    const radius = level === 'Zone' ? 0.8 :
        level === 'District' ? 0.4 :
            level === 'Branch' ? 0.15 :
                level === 'Village' ? 0.05 :
                    level === 'Centre' ? 0.015 : // Tighter for centres
                        level === 'Group' ? 0.003 : 0.0008; // Very tight for groups/customers

    const fillers = Array.from({ length: fillerCount }).map((_, i) => {
        const idx = i + entities.length;
        // Independent seeded layout - Golden Angle for organic scatter
        const goldenAngle = 2.39996;
        const distanceFactor = Math.sqrt(idx + 1);
        const r = radius * distanceFactor * 0.5;
        const theta = idx * goldenAngle;
        // Correct 'let' usage
        const pLat = parent?.coord?.[0] || 20;
        const pLng = parent?.coord?.[1] || 78;
        let lat = pLat + r * Math.cos(theta);
        let lng = pLng + r * Math.sin(theta);

        // Generator Logic
        const parVariance = ((idx % 5) - 2) * 0.2;
        const parentPar = parent?.par30 || 2.5; // Defensive Default
        const myPar = Math.max(0, parentPar + parVariance);

        let compliance: 'within' | 'outside' | undefined;
        if (level === 'Group') compliance = (Math.random() > 0.15) ? 'within' : 'outside';
        if (level === 'Centre') compliance = (idx % 7 === 0) ? 'outside' : 'within';

        // Radius & Distance Logic for Visual Accuracy
        const fenceRadiusDeg = 0.0036; // Approx 400m

        // Recalculate 'r' based on compliance if at Group level
        if (level === 'Group') {
            if (compliance === 'within') {
                // Ensure strictly inside
                r = Math.random() * fenceRadiusDeg * 0.9;
            } else {
                // Ensure strictly outside
                r = fenceRadiusDeg * (1.1 + Math.random() * 0.5);
            }
            // Update lat/lng with new r (keeping golden angle theta)
            lat = pLat + r * Math.cos(theta);
            lng = pLng + r * Math.sin(theta);
        }

        let collectionStatus: 'paid' | 'pending' | 'overdue' | undefined;
        if (level === 'Customer') {
            const seed = (idx * 9301 + 49297) % 233280;
            if (seed % 10 > 8) collectionStatus = 'overdue';
            else if (seed % 10 > 6) collectionStatus = 'pending';
            else collectionStatus = 'paid';
        }

        // Realistic Naming Dictionary
        const REAL_NAMES: Record<string, string[]> = {
            'Madhya Pradesh': ['Indore', 'Bhopal', 'Jabalpur', 'Gwalior', 'Ujjain', 'Sagar', 'Dewas', 'Satna', 'Ratlam', 'Rewa'],
            'Andhra Pradesh': ['Visakhapatnam', 'Vijayawada', 'Guntur', 'Nellore', 'Kurnool', 'Rajahmundry', 'Tirupati', 'Kakinada'],
            'Telangana': ['Hyderabad', 'Warangal', 'Nizamabad', 'Karimnagar', 'Khammam', 'Ramagundam', 'Mahbubnagar'],
            'Kerala': ['Thiruvananthapuram', 'Kochi', 'Kozhikode', 'Thrissur', 'Kollam', 'Palakkad', 'Alappuzha', 'Kannur'],
            'Uttar Pradesh': ['Lucknow', 'Kanpur', 'Ghaziabad', 'Agra', 'Varanasi', 'Meerut', 'Prayagraj', 'Noida'],
            'Maharashtra': ['Mumbai', 'Pune', 'Nagpur', 'Nashik', 'Aurangabad', 'Solapur', 'Amravati', 'Nanded'],
            'Gujarat': ['Ahmedabad', 'Surat', 'Vadodara', 'Rajkot', 'Bhavnagar', 'Jamnagar', 'Junagadh', 'Gandhinagar'],
            'Rajasthan': ['Jaipur', 'Jodhpur', 'Kota', 'Bikaner', 'Ajmer', 'Udaipur', 'Bhilwara', 'Alwar'],
            'Karnataka': ['Bengaluru', 'Mysuru', 'Hubballi', 'Mangaluru', 'Belagavi', 'Davancere', 'Ballari', 'Vijayapura'],
            'Tamil Nadu': ['Chennai', 'Coimbatore', 'Madurai', 'Tiruchirappalli', 'Salem', 'Tirunelveli', 'Tiruppur', 'Erode'],
            'West Bengal': ['Kolkata', 'Asansol', 'Siliguri', 'Durgapur', 'Bardhaman', 'Malda', 'Baharampur', 'Shantipur'],
            'Bihar': ['Patna', 'Gaya', 'Bhagalpur', 'Muzaffarpur', 'Purnia', 'Darbhanga', 'Bihar Sharif', 'Arrah']
        };

        // Smart Naming
        let name = `${level} ${i + 1}`;

        if (level === 'Zone') {
            const stateName = parent?.name || '';
            const districtList = REAL_NAMES[stateName];
            if (districtList && districtList[i % districtList.length]) {
                name = districtList[i % districtList.length];
                if (i >= districtList.length) name += ` ${Math.floor(i / districtList.length) + 1}`; // Handle overflow
            } else {
                name = `Zone ${String.fromCharCode(65 + (i % 26))}`;
            }
        }
        if (level === 'District') name = `${parent?.name?.split(' ')[0] || 'Region'} District ${i + 1}`;
        if (level === 'Branch') name = `${parent?.name?.split(' ')[0] || 'Bran'} Branch ${i + 1}`;
        if (level === 'Village') name = `${parent?.name?.split(' ')[0] || 'Locality'} Village ${i + 1}`;
        if (level === 'Centre') name = `Centre - C${100 + i + 1}`;
        if (level === 'Group') name = `Group - G${100 + i + 1}`;
        if (level === 'Customer') name = `Customer ${i + 1}`;

        // Ensure unique name
        if (existingNames.has(name)) name = `${name} (${i})`;

        return {
            id: `${parent!.id}-${level}-gen-${i}`,
            name: name,
            level: level,
            glp: parent!.glp / targetCount,
            par30: parseFloat(myPar.toFixed(2)),
            clients: Math.round(parent!.clients / targetCount),
            coord: [lat, lng] as [number, number],
            childrenCount: 5,
            compliance,
            collectionStatus
        } as GeoEntity;
    });

    return [...entities, ...fillers];
};

// ... (Helper Components omitted) ...

// --- Helper Components ---
const MapController = ({ entities, center, zoomLevel }: { entities: GeoEntity[], center: [number, number], zoomLevel: number }) => {
    const map = useMap();
    useEffect(() => {
        if (entities.length > 0) {
            let minLat = 90, maxLat = -90, minLng = 180, maxLng = -180;
            entities.forEach(e => {
                minLat = Math.min(minLat, e.coord[0]);
                maxLat = Math.max(maxLat, e.coord[0]);
                minLng = Math.min(minLng, e.coord[1]);
                maxLng = Math.max(maxLng, e.coord[1]);
            });

            // Ensure Fence is visible if we are deep in the drilldown
            const fencePadding = 0.0045;
            const isDeepLevel = zoomLevel >= 14;
            if (isDeepLevel) {
                minLat = Math.min(minLat, center[0] - fencePadding);
                maxLat = Math.max(maxLat, center[0] + fencePadding);
                minLng = Math.min(minLng, center[1] - fencePadding);
                maxLng = Math.max(maxLng, center[1] + fencePadding);
            }

            // Tighter bounds to force higher zoom level
            const latPad = 0;
            const lngPad = 0;

            if (minLat !== 90 && (maxLat - minLat) > 0.0001) {
                map.flyToBounds([
                    [minLat - latPad, minLng - lngPad],
                    [maxLat + latPad, maxLng + lngPad]
                ], { duration: 1.2, easeLinearity: 0.25, padding: [10, 10] });
            } else {
                map.flyTo(center, zoomLevel, { duration: 1.2, easeLinearity: 0.25 });
            }
        } else {
            map.flyTo(center, zoomLevel, { duration: 1.2, easeLinearity: 0.25 });
        }
    }, [entities, center, zoomLevel, map]);
    return null;
};

const getRiskColor = (par: number) => {
    if (par > 3.0) return '#ef4444';
    if (par > 2.0) return '#f59e0b';
    return '#10b981';
};

const getLevelItemName = (level: GeoLevel) => {
    switch (level) {
        case 'Country': return 'States';
        case 'State': return 'Zones';
        case 'Zone': return 'Districts';
        case 'District': return 'Branches';
        case 'Branch': return 'Villages';
        case 'Village': return 'Centres';
        case 'Centre': return 'Groups';
        case 'Group': return 'Customers';
        default: return 'Items';
    }
};

// --- Main Component ---
const GeoDashboard = () => {
    const [viewMode, setViewMode] = useState<'growth' | 'risk' | 'ops' | 'compliance'>('growth');
    const [currentLevel, setCurrentLevel] = useState<GeoLevel>('Country');
    const [history, setHistory] = useState<GeoEntity[]>([]);
    const [entities, setEntities] = useState<GeoEntity[]>([]);
    const [mapCenter, setMapCenter] = useState<[number, number]>([20.5937, 78.9629]);
    const [mapZoom, setMapZoom] = useState(5);
    const [selectedEntity, setSelectedEntity] = useState<GeoEntity | null>(null);

    // (Duplicate Function - Renamed to avoid collision)
    /* const fetchLevelData_UNUSED = (parent: GeoEntity | null, level: GeoLevel) => {
        // 1. Root: India -> States
        if (!parent || level === 'State') {
            // ... (Same State Logic) ...
            // Update return type
            return mergedStates.map(s => ({
                id: s.name, name: s.name, level: 'State',
                glp: s.glp, par30: s.districts?.[0]?.par30 || 2.1,
                clients: Math.round(s.glp * 250),
                coord: s.coord, childrenCount: 15,
                data: s
            } as GeoEntity));
        }

        // 2. Real Data Extraction & Hierarchy Mapping
        let entities: GeoEntity[] = [];
        let realChildren: any[] = [];
        let targetCount = 5;

        // Map Real Data to New Hierarchy
        // State -> Zone (Real District)
        // Zone -> District (Real Branch)
        // District -> Village (Dummy/Wrapper)
        // Village -> Centre (Real Centre)

        if (parent && parent.data) {
            if (level === 'Zone' && parent.data.districts) {
                realChildren = parent.data.districts;
                targetCount = Math.max(realChildren.length + 5, 8);
            }
            else if (level === 'District' && parent.data.branches) {
                realChildren = parent.data.branches;
                targetCount = 10;
            }
            else if (level === 'Village' && parent.data.centres) {
                // Create a single Dummy Village to hold the centers
                // Or split centers? We'll create one wrapper.
                entities = [{
                    id: `${parent.id}-Village-Main`,
                    name: `${parent.name} Village`,
                    level: 'Village',
                    coord: parent.coord,
                    glp: parent.glp,
                    clients: parent.clients,
                    par30: parent.par30,
                    data: { centres: parent.data.centres }, // Pass centres down
                    childrenCount: parent.data.centres.length
                } as GeoEntity];
                return entities; // Return immediately for wrapper
            }
            else if (level === 'Centre' && parent.data.centres) {
                realChildren = parent.data.centres;
                targetCount = 20;
            }

            if (realChildren.length > 0) {
                entities = realChildren.map(child => ({
                    id: `${level}-${child.name}`,
                    name: child.name,
                    level: level,
                    coord: child.coord,
                    glp: child.glp,
                    clients: child.clients || 0,
                    par30: child.par30 || (parent.par30 + (Math.random() * 0.5 - 0.25)),
                    data: child,
                    compliance: (level === 'Centre') ? (Math.random() > 0.15 ? 'within' : 'outside') : undefined
                } as GeoEntity));
            }
        }

        // Procedural Fallback
        if (entities.length === 0) {
            if (level === 'Zone') targetCount = 5 + Math.floor(Math.random() * 5); // Zones
            if (level === 'District') targetCount = 8 + Math.floor(Math.random() * 6); // Districts
            if (level === 'Village') targetCount = 10 + Math.floor(Math.random() * 8); // Villages
            if (level === 'Centre') targetCount = 12 + Math.floor(Math.random() * 8); // Centres
            if (level === 'Group') targetCount = 20 + Math.floor(Math.random() * 10); // Groups
            if (level === 'Customer') targetCount = 15 + Math.floor(Math.random() * 10); // Customers
        }

        // 3. Filler Generation (Prune duplicates)
        const fillerCount = Math.max(0, targetCount - entities.length);
        const existingNames = new Set(entities.map(e => e.name));

        const radius = level === 'Zone' ? 0.8 :
            level === 'District' ? 0.3 :
                level === 'Village' ? 0.08 :
                    level === 'Centre' ? 0.02 :
                        level === 'Group' ? 0.005 : 0.001;

        const fillers = Array.from({ length: fillerCount }).map((_, i) => {
            const idx = i + entities.length;
            // ... (Golden Angle) ...
            const goldenAngle = 2.39996;
            const distanceFactor = Math.sqrt(idx + 1);
            const r = radius * distanceFactor * 0.5;
            const theta = idx * goldenAngle;

            // Fixing the 'const' bug here too
            let lat = parent!.coord[0] + r * Math.cos(theta);
            let lng = parent!.coord[1] + r * Math.sin(theta);

            // Generator Logic
            const parVariance = ((idx % 5) - 2) * 0.2;
            const parentPar = parent!.par30;
            const myPar = Math.max(0, parentPar + parVariance);

            let compliance: 'within' | 'outside' | undefined;
            if (level === 'Group') {
                compliance = (Math.random() > 0.15) ? 'within' : 'outside';
            }
            if (level === 'Centre') {
                compliance = (idx % 7 === 0) ? 'outside' : 'within';
            }

            // Radius & Distance Logic
            const fenceRadiusDeg = 0.0036;

            if (level === 'Group') {
                if (compliance === 'within') {
                    r = Math.random() * fenceRadiusDeg * 0.9;
                } else {
                    r = fenceRadiusDeg * (1.1 + Math.random() * 0.5);
                }
                lat = parent!.coord[0] + r * Math.cos(theta);
                lng = parent!.coord[1] + r * Math.sin(theta);
            }

            let collectionStatus: 'paid' | 'pending' | 'overdue' | undefined;
            if (level === 'Customer') {
                // ... Random status ...
                const seed = (idx * 9301 + 49297) % 233280;
                if (seed % 10 > 8) collectionStatus = 'overdue';
                else if (seed % 10 > 6) collectionStatus = 'pending';
                else collectionStatus = 'paid';
            }

            // Realistic Naming Dictionary
            const REAL_NAMES: Record<string, string[]> = {
                // ... (Keep existing dictionary) ...
                'Madhya Pradesh': ['Indore', 'Bhopal', 'Jabalpur', 'Gwalior', 'Ujjain'],
                // ...
            };

            // Smart Naming
            let name = `${level} ${i + 1}`;

            if (level === 'Zone') {
                // Use District Names for Zones
                const stateName = parent?.name || '';
                const districtList = REAL_NAMES[stateName] || ['Zone A', 'Zone B', 'Zone C'];
                name = districtList[i % districtList.length] || `Zone ${String.fromCharCode(65 + i)}`;
            }

            if (level === 'District') name = `${parent?.name || 'Region'} District ${i + 1}`;
            if (level === 'Village') name = `${parent?.name?.split(' ')[0] || 'Locality'} Village ${i + 1}`;
            if (level === 'Centre') name = `Centre - C${i + 101}`;
            if (level === 'Customer') name = `Customer ${i + 1}`;

            // Ensure unique name
            if (existingNames.has(name)) name = `${name} (${i})`;

            return {
                id: `${parent!.id}-${level}-gen-${i}`,
                name: name,
                level: level,
                glp: parent!.glp / targetCount,
                par30: parseFloat(myPar.toFixed(2)),
                clients: Math.round(parent!.clients / targetCount),
                coord: [lat, lng] as [number, number],
                childrenCount: 5,
                compliance,
                collectionStatus
            } as GeoEntity;
        });

        return [...entities, ...fillers];
    };

    // --- Helper Components ---
    const MapController = ({ entities, center, zoomLevel }: { entities: GeoEntity[], center: [number, number], zoomLevel: number }) => {
        const map = useMap();

        useEffect(() => {
            if (entities.length > 0) {
                let minLat = 90, maxLat = -90, minLng = 180, maxLng = -180;
                entities.forEach(e => {
                    minLat = Math.min(minLat, e.coord[0]);
                    maxLat = Math.max(maxLat, e.coord[0]);
                    minLng = Math.min(minLng, e.coord[1]);
                    maxLng = Math.max(maxLng, e.coord[1]);
                });

                // Ensure Fence is visible if we are deep in the drilldown (Center/Group level)
                // Fence radius approx 0.0036 deg
                const fencePadding = 0.0045;
                const isDeepLevel = zoomLevel >= 14; // Center level or deeper

                if (isDeepLevel) {
                    minLat = Math.min(minLat, center[0] - fencePadding);
                    maxLat = Math.max(maxLat, center[0] + fencePadding);
                    minLng = Math.min(minLng, center[1] - fencePadding);
                    maxLng = Math.max(maxLng, center[1] + fencePadding);
                }

                // Tighter bounds to force higher zoom level
                const latPad = 0;
                const lngPad = 0;

                if (minLat !== 90 && (maxLat - minLat) > 0.0001) { // Threshold
                    map.flyToBounds([
                        [minLat - latPad, minLng - lngPad],
                        [maxLat + latPad, maxLng + lngPad]
                    ], { duration: 1.2, easeLinearity: 0.25, padding: [10, 10] });
                } else {
                    map.flyTo(center, zoomLevel, { duration: 1.2, easeLinearity: 0.25 });
                }
            } else {
                map.flyTo(center, zoomLevel, { duration: 1.2, easeLinearity: 0.25 });
            }
        }, [entities, center, zoomLevel, map]);
        return null;
    };

    const getRiskColor = (par: number) => {
        if (par > 3.0) return '#ef4444';
        if (par > 2.0) return '#f59e0b';
        return '#10b981';
    };

    // --- Main Component ---
    const GeoDashboard = () => {
        const [viewMode, setViewMode] = useState<'growth' | 'risk' | 'compliance'>('growth');
        const [currentLevel, setCurrentLevel] = useState<GeoLevel>('Country');
        const [history, setHistory] = useState<GeoEntity[]>([]);
        const [entities, setEntities] = useState<GeoEntity[]>([]);
        const [mapCenter, setMapCenter] = useState<[number, number]>([20.5937, 78.9629]);
        const [mapZoom, setMapZoom] = useState<number>(5);
        const [selectedEntity, setSelectedEntity] = useState<GeoEntity | null>(null);

        // --- Hybrid Data Generation ---
        const fetchLevelData = (parent: GeoEntity | null, level: GeoLevel) => {
            // 1. Root Level
            if (level === 'State') {
                // Supplement missing states to ensure full India map
                const MISSING_STATES = [
                    { name: 'Andhra Pradesh', coord: [15.9129, 79.7400], glp: 1200 },
                    { name: 'Telangana', coord: [18.1124, 79.0193], glp: 1150 },
                    { name: 'Kerala', coord: [10.8505, 76.2711], glp: 890 },
                    { name: 'Goa', coord: [15.2993, 74.1240], glp: 150 },
                    { name: 'Himachal Pradesh', coord: [31.1048, 77.1734], glp: 420 },
                    { name: 'Jammu & Kashmir', coord: [33.7782, 76.5762], glp: 310 },
                    { name: 'Delhi', coord: [28.7041, 77.1025], glp: 600 },
                    { name: 'Punjab', coord: [31.1471, 75.3412], glp: 980 },
                    { name: 'Assam', coord: [26.2006, 92.9376], glp: 750 },
                    { name: 'Manipur', coord: [24.6637, 93.9063], glp: 120 },
                    { name: 'Meghalaya', coord: [25.4670, 91.3662], glp: 110 },
                    { name: 'Mizoram', coord: [23.1645, 92.9376], glp: 90 },
                    { name: 'Nagaland', coord: [26.1584, 94.5624], glp: 95 },
                    { name: 'Tripura', coord: [23.9408, 91.9882], glp: 130 },
                    { name: 'Arunachal Pradesh', coord: [28.2180, 94.7278], glp: 80 },
                    { name: 'Sikkim', coord: [27.5330, 88.5122], glp: 70 }
                ];

                // Merge with ALL_STATES_DATA (checking for duplicates by name)
                const existingNames = new Set(ALL_STATES_DATA.map(s => s.name));
                const mergedStates = [...ALL_STATES_DATA];

                MISSING_STATES.forEach(ms => {
                    if (!existingNames.has(ms.name)) {
                        mergedStates.push(ms as any);
                    }
                });

                return mergedStates.map(s => ({
                    id: s.name, name: s.name, level: 'State',
                    glp: s.glp, par30: s.districts?.[0]?.par30 || 2.1,
                    clients: Math.round(s.glp * 250),
                    coord: s.coord, childrenCount: 15,
                    data: s
                } as GeoEntity));
            }

            // 2. Real Data Extraction
            let entities: GeoEntity[] = [];
            let realChildren: any[] = [];
            let targetCount = 5;

            if (parent && parent.data) {
                if (level === 'District' && parent.data.districts) {
                    realChildren = parent.data.districts;
                    targetCount = Math.max(realChildren.length + 5, 12);
                }
                else if (level === 'Branch' && parent.data.branches) {
                    realChildren = parent.data.branches;
                    targetCount = 15;
                }
                else if (level === 'Center' && parent.data.centres) {
                    realChildren = parent.data.centres;
                    targetCount = 20;
                }
                else if (level === 'Group') {
                    // Even if parent is real (Center), we don't have real groups in JSON usually.
                    // Ensure robust generation.
                    targetCount = 20 + Math.floor(Math.random() * 10);
                }
                else if (level === 'Client') {
                    targetCount = 15 + Math.floor(Math.random() * 10);
                }

                if (realChildren.length > 0) {
                    entities = realChildren.map(child => ({
                        id: `${level}-${child.name}`,
                        name: child.name,
                        level: level,
                        coord: child.coord,
                        glp: child.glp,
                        clients: child.clients || 0,
                        par30: child.par30 || (parent.par30 + (Math.random() * 0.5 - 0.25)),
                        data: child,
                        compliance: (level === 'Center') ? (Math.random() > 0.15 ? 'within' : 'outside') : undefined
                    } as GeoEntity));
                }
            } else {
                // Procedural Defaults - Randomized for organic feel
                if (level === 'District') targetCount = 8 + Math.floor(Math.random() * 8); // 8-15 Districts
                if (level === 'Branch') targetCount = 10 + Math.floor(Math.random() * 8); // 10-18 Branches
                if (level === 'Center') targetCount = 15 + Math.floor(Math.random() * 10); // 15-25 Centers
                if (level === 'Group') targetCount = 5 + Math.floor(Math.random() * 4); // 5-8 Groups
                if (level === 'Client') targetCount = 8 + Math.floor(Math.random() * 5); // 8-12 Clients
            }

            // 3. Filler Generation (Prune duplicates)
            const fillerCount = Math.max(0, targetCount - entities.length);
            const existingNames = new Set(entities.map(e => e.name));

            const radius = level === 'District' ? 0.6 :
                level === 'Branch' ? 0.15 :
                    level === 'Center' ? 0.04 :
                        level === 'Group' ? 0.005 : 0.001;

            const fillers = Array.from({ length: fillerCount }).map((_, i) => {
                const idx = i + entities.length;

                // Independent seeded layout - Golden Angle for organic scatter
                const goldenAngle = 2.39996;
                const distanceFactor = Math.sqrt(idx + 1);
                const r = radius * distanceFactor * 0.5;
                const theta = idx * goldenAngle;

                let lat = parent!.coord[0] + r * Math.cos(theta);
                let lng = parent!.coord[1] + r * Math.sin(theta);

                // Generator Logic
                const parVariance = ((idx % 5) - 2) * 0.2;
                const parentPar = parent!.par30;
                const myPar = Math.max(0, parentPar + parVariance);

                let compliance: 'within' | 'outside' | undefined;
                if (level === 'Group') {
                    // Determine status first
                    compliance = (Math.random() > 0.15) ? 'within' : 'outside';
                }
                if (level === 'Center') {
                    compliance = (idx % 7 === 0) ? 'outside' : 'within';
                }

                // Radius & Distance Logic for Visual Accuracy
                const fenceRadiusDeg = 0.0036; // Approx 400m

                // Recalculate 'r' based on compliance if at Group level
                if (level === 'Group') {
                    if (compliance === 'within') {
                        // Ensure strictly inside
                        r = Math.random() * fenceRadiusDeg * 0.9;
                    } else {
                        // Ensure strictly outside
                        r = fenceRadiusDeg * (1.1 + Math.random() * 0.5);
                    }
                    // Update lat/lng with new r (keeping golden angle theta)
                    lat = parent!.coord[0] + r * Math.cos(theta);
                    lng = parent!.coord[1] + r * Math.sin(theta);
                }

                let collectionStatus: 'paid' | 'pending' | 'overdue' | undefined;
                if (level === 'Client') {
                    const seed = (idx * 9301 + 49297) % 233280;
                    const grand = seed / 233280;
                    if (grand > 0.9) collectionStatus = 'overdue';
                    else if (grand > 0.75) collectionStatus = 'pending';
                    else collectionStatus = 'paid';
                }

                // Realistic Naming Dictionary
                const REAL_NAMES: Record<string, string[]> = {
                    'Madhya Pradesh': ['Indore', 'Bhopal', 'Jabalpur', 'Gwalior', 'Ujjain', 'Sagar', 'Dewas', 'Satna', 'Ratlam', 'Rewa'],
                    'Andhra Pradesh': ['Visakhapatnam', 'Vijayawada', 'Guntur', 'Nellore', 'Kurnool', 'Rajahmundry', 'Tirupati', 'Kakinada'],
                    'Telangana': ['Hyderabad', 'Warangal', 'Nizamabad', 'Karimnagar', 'Khammam', 'Ramagundam', 'Mahbubnagar'],
                    'Kerala': ['Thiruvananthapuram', 'Kochi', 'Kozhikode', 'Thrissur', 'Kollam', 'Palakkad', 'Alappuzha', 'Kannur'],
                    'Uttar Pradesh': ['Lucknow', 'Kanpur', 'Ghaziabad', 'Agra', 'Varanasi', 'Meerut', 'Prayagraj', 'Noida'],
                    'Maharashtra': ['Mumbai', 'Pune', 'Nagpur', 'Nashik', 'Aurangabad', 'Solapur', 'Amravati', 'Nanded'],
                    'Gujarat': ['Ahmedabad', 'Surat', 'Vadodara', 'Rajkot', 'Bhavnagar', 'Jamnagar', 'Junagadh', 'Gandhinagar'],
                    'Rajasthan': ['Jaipur', 'Jodhpur', 'Kota', 'Bikaner', 'Ajmer', 'Udaipur', 'Bhilwara', 'Alwar'],
                    'Karnataka': ['Bengaluru', 'Mysuru', 'Hubballi', 'Mangaluru', 'Belagavi', 'Davancere', 'Ballari', 'Vijayapura'],
                    'Tamil Nadu': ['Chennai', 'Coimbatore', 'Madurai', 'Tiruchirappalli', 'Salem', 'Tirunelveli', 'Tiruppur', 'Erode'],
                    'West Bengal': ['Kolkata', 'Asansol', 'Siliguri', 'Durgapur', 'Bardhaman', 'Malda', 'Baharampur', 'Shantipur'],
                    'Bihar': ['Patna', 'Gaya', 'Bhagalpur', 'Muzaffarpur', 'Purnia', 'Darbhanga', 'Bihar Sharif', 'Arrah']
                };

                // Smart Naming
                let name = `${level} ${i + 1}`;

                if (level === 'District') {
                    // Try to fetch real district name from parent state
                    const stateName = parent?.name || '';
                    const districtList = REAL_NAMES[stateName];
                    if (districtList && districtList[i % districtList.length]) {
                        name = districtList[i % districtList.length];
                        if (i >= districtList.length) name += ` ${Math.floor(i / districtList.length) + 1}`; // Handle overflow
                    } else {
                        name = `Zone ${String.fromCharCode(65 + (i % 26))}`;
                    }
                }

                if (level === 'Branch') {
                    // Generate realistic branch names based on parent district if possible
                    const towns = ['North', 'South', 'East', 'West', 'Central', 'Rural', 'Urban', 'Extension', 'Main', 'Bazaar'];
                    name = `${parent?.name || 'Branch'} ${towns[i % towns.length]}`;
                }

                if (level === 'Center') {
                    name = `${parent?.name?.split(' ')[0] || 'Center'} - G${i + 101}`;
                }

                if (level === 'Client') name = ['Aditi', 'Bina', 'Chaya', 'Divya', 'Esha', 'Fatima', 'Gauri', 'Hina', 'Isha', 'Jaya', 'Kavya', 'Lata', 'Mina', 'Neha', 'Priya'][idx % 15] + ` Devi`;

                // Ensure unique name
                if (existingNames.has(name)) name = `${name} (${i})`;

                return {
                    id: `${parent!.id}-${level}-gen-${i}`,
                    name: name,
                    level: level,
                    glp: parent!.glp / targetCount,
                    par30: parseFloat(myPar.toFixed(2)),
                    clients: Math.round(parent!.clients / targetCount),
                    coord: [lat, lng] as [number, number],
                    childrenCount: 5,
                    compliance,
                    collectionStatus
                } as GeoEntity;
            });

            return [...entities, ...fillers];
        }; */

    // --- State for Aggregated India Stats ---
    const [indiaStats, setIndiaStats] = useState({ glp: 0, clients: 0, par30: 0 });

    // Initial Load & Aggregation
    useEffect(() => {
        const states = fetchLevelData(null, 'State');
        setEntities(states as GeoEntity[]);

        // Calculate Totals to ensure "Tie back" consistency
        const totalGLP = states.reduce((sum, s) => sum + s.glp, 0);
        const totalClients = states.reduce((sum, s) => sum + s.clients, 0);
        // Weighted PAR? Or just average? Weighted by GLP is best.
        const weightedPAR = states.reduce((sum, s) => sum + (s.par30 * s.glp), 0) / totalGLP;

        setIndiaStats({
            glp: totalGLP,
            clients: totalClients,
            par30: parseFloat(weightedPAR.toFixed(2))
        });
    }, []);

    // Handlers
    const handleDrillDown = (entity: GeoEntity) => {
        const nextLevelIndex = LEVELS.indexOf(entity.level) + 1;
        if (nextLevelIndex >= LEVELS.length) return;
        const nextLevel = LEVELS[nextLevelIndex];
        const nextEntities = fetchLevelData(entity, nextLevel);

        // Context-Aware History: Truncate history if jumping sideways or up
        const entityDepth = LEVELS.indexOf(entity.level);
        // Filter history to remove any existing items at this level or deeper (Peers/Children)
        const cleanHistory = history.filter(h => LEVELS.indexOf(h.level) < entityDepth);

        setHistory([...cleanHistory, entity]);
        setCurrentLevel(nextLevel);
        setEntities(nextEntities as GeoEntity[]);
        setMapCenter(entity.coord); // MapController will handle fitBounds
        setSelectedEntity(entity);
    };

    const handleBack = () => {
        if (history.length === 0) return;
        const prevHistory = [...history];
        const prevParent = prevHistory.pop();
        const grandParent = prevHistory.length > 0 ? prevHistory[prevHistory.length - 1] : null;

        const prevLevelIndex = LEVELS.indexOf(currentLevel) - 1;
        const prevLevel = LEVELS[prevLevelIndex];

        const siblings = fetchLevelData(grandParent, prevLevel);

        setHistory(prevHistory);
        setCurrentLevel(prevLevel);
        setEntities(siblings as GeoEntity[]);

        if (prevParent) {
            setMapCenter(prevParent.coord);
            setSelectedEntity(prevParent);
        } else {
            setMapCenter([20.5937, 78.9629]);
            setSelectedEntity(null);
        }
    };

    const handleBreadcrumbClick = (index: number) => {
        if (index === -1) {
            const states = fetchLevelData(null, 'State');
            setHistory([]);
            setCurrentLevel('State');
            setEntities(states as GeoEntity[]);
            setMapCenter([20.5937, 78.9629]);
            setSelectedEntity(null);
        }
    };

    const currentStats = selectedEntity ? selectedEntity : {
        name: 'All India',
        glp: indiaStats.glp || COMPANY_METRICS.currentGLP,
        clients: indiaStats.clients || COMPANY_METRICS.activeClients,
        par30: indiaStats.par30 || COMPANY_METRICS.gnpa
    };

    // --- Right Panel Logic ---
    const getLevelItemName = (lvl: GeoLevel) => {
        switch (lvl) {
            case 'Country': return 'States';
            case 'State': return 'Zones';
            case 'Zone': return 'Districts';
            case 'District': return 'Villages';
            case 'Village': return 'Centres';
            case 'Centre': return 'Groups';
            case 'Group': return 'Customers';
            default: return 'Items';
        }
    };

    // Calculate Geofence Stats
    const withinCount = entities.filter(e => e.compliance === 'within').length;
    const outsideCount = entities.filter(e => e.compliance === 'outside').length;
    const complyPercent = entities.length > 0 ? Math.round((withinCount / entities.length) * 100) : 0;

    return (
        <div className="flex flex-col lg:flex-row h-[calc(100vh-80px)] gap-4 font-sans text-secondary-900 bg-slate-50 p-2">

            {/* LEFT: Map Area */}
            <div className="flex-[3] relative rounded-xl overflow-hidden shadow-sm border border-secondary-200 bg-white min-h-[500px]">
                {/* Breadcrumb Overlay */}
                <div className="absolute top-4 left-4 z-[1000] bg-white/90 backdrop-blur-sm p-2 rounded-lg shadow-md border border-secondary-200 min-w-[250px]">
                    <div className="flex flex-wrap items-center gap-2 text-sm">
                        <span className="cursor-pointer hover:text-primary-600 font-medium text-secondary-600 flex items-center" onClick={() => handleBreadcrumbClick(-1)}>
                            <Globe size={14} className="mr-1" /> India
                        </span>
                        {history.map((item, idx) => (
                            <React.Fragment key={item.id}>
                                <ChevronRight size={14} className="text-secondary-400" />
                                <span className={cn("flex items-center", idx === history.length - 1 ? "font-bold text-primary-700" : "text-secondary-600")}>
                                    {item.name}
                                </span>
                            </React.Fragment>
                        ))}
                    </div>
                    {history.length > 0 && (
                        <button onClick={handleBack} className="mt-2 w-full py-1 flex items-center justify-center gap-2 text-primary-700 bg-primary-50 hover:bg-primary-100 rounded text-xs font-bold uppercase transition-colors">
                            <ArrowLeft size={12} /> Go Back Up
                        </button>
                    )}
                </div>

                <MapContainer center={mapCenter} zoom={mapZoom} scrollWheelZoom={true} className="w-full h-full">
                    <MapController entities={entities} center={mapCenter} zoomLevel={mapZoom} />
                    <TileLayer
                        attribution='&copy; OpenStreetMap'
                        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                    />

                    {/* Render Entities */}
                    {entities.map(entity => {
                        const color = viewMode === 'risk' ? getRiskColor(entity.par30) :
                            entity.level === 'State' ? '#3b82f6' :
                                entity.level === 'Zone' ? '#6366f1' :
                                    entity.level === 'District' ? '#8b5cf6' : '#ec4899';

                        if (['State', 'Zone', 'District', 'Branch', 'Village'].includes(entity.level)) {
                            // Dynamic sizing
                            let pixelRadius = 14;
                            if (entity.level === 'State') pixelRadius = 16 + (Math.min(entity.glp, 5000) / 5000) * 20;
                            if (entity.level === 'Zone') pixelRadius = 12;
                            if (entity.level === 'District') pixelRadius = 10;
                            if (entity.level === 'Branch') pixelRadius = 9;
                            if (entity.level === 'Village') pixelRadius = 8;

                            return (
                                <CircleMarker
                                    key={entity.id}
                                    center={entity.coord}
                                    pathOptions={{ fillColor: color, color: 'white', weight: 2, fillOpacity: 0.9 }}
                                    radius={pixelRadius}
                                    eventHandlers={{ click: () => handleDrillDown(entity) }}
                                >
                                    <Popup>
                                        <div className="text-center">
                                            <b className="text-lg">{entity.name}</b><br />
                                            <div className="text-xs text-secondary-500 uppercase font-bold">{entity.level}</div>
                                            <div className="my-1 text-primary-700 font-bold">₹{entity.glp.toFixed(1)} Cr</div>
                                            <button className="bg-primary-50 text-primary-700 px-2 py-1 rounded text-xs font-bold mt-1">Drill Down</button>
                                        </div>
                                    </Popup>
                                </CircleMarker>
                            );
                        } else if (entity.level === 'Centre') {
                            const isComply = entity.compliance === 'within';
                            const centerColor = isComply ? '#10b981' : '#f43f5e';

                            return (
                                <React.Fragment key={entity.id}>
                                    {/* Explicit Fence Visualization for Centre Level */}
                                    <Circle
                                        center={entity.coord}
                                        pathOptions={{ color: isComply ? '#10b981' : '#f43f5e', weight: 1, dashArray: '4, 4', fillOpacity: 0.05 }}
                                        radius={400}
                                    />
                                    <CircleMarker
                                        center={entity.coord}
                                        radius={6}
                                        pathOptions={{ fillColor: centerColor, color: 'white', weight: 2, fillOpacity: 1 }}
                                        eventHandlers={{ click: () => handleDrillDown(entity) }}
                                    >
                                        <Popup>
                                            <div className="text-center min-w-[120px]">
                                                <b>{entity.name}</b><br />
                                                <div className="text-[10px] text-secondary-400 font-mono mb-1">
                                                    {entity.coord[0].toFixed(5)}, {entity.coord[1].toFixed(5)}
                                                </div>
                                                <div className={`text-xs font-bold mb-2 ${isComply ? 'text-emerald-600' : 'text-rose-600'}`}>
                                                    {isComply ? 'Within Geo-Fence' : 'Outside Geo-Fence'}
                                                </div>
                                                <button
                                                    onClick={() => handleDrillDown(entity)}
                                                    className="bg-primary-50 text-primary-700 px-3 py-1.5 rounded-full text-xs font-bold w-full hover:bg-primary-100 border border-primary-200"
                                                >
                                                    View Groups &gt;
                                                </button>
                                            </div>
                                        </Popup>
                                    </CircleMarker>
                                </React.Fragment>
                            );
                        } else if (entity.level === 'Group') {
                            const isComply = entity.compliance === 'within';
                            const gColor = isComply ? '#10b981' : '#f43f5e';
                            return (
                                <CircleMarker
                                    key={entity.id}
                                    center={entity.coord}
                                    radius={5}
                                    pathOptions={{ fillColor: gColor, color: 'white', weight: 1, fillOpacity: 1 }}
                                    eventHandlers={{ click: () => handleDrillDown(entity) }}
                                >
                                    <Popup>
                                        <div className="text-center min-w-[100px]">
                                            <b>{entity.name}</b><br />
                                            <div className="text-[10px] text-secondary-400 font-mono mb-1">
                                                {entity.coord[0].toFixed(5)}, {entity.coord[1].toFixed(5)}
                                            </div>
                                            <span className={`block text-xs font-bold mb-2 ${isComply ? "text-emerald-600" : "text-rose-600"}`}>
                                                {isComply ? 'In Range' : 'Out Range'}
                                            </span>
                                            <button
                                                onClick={(e) => {
                                                    e.stopPropagation();
                                                    handleDrillDown(entity);
                                                }}
                                                className="bg-primary-50 text-primary-700 px-2 py-1 rounded text-xs font-bold w-full hover:bg-primary-100 border border-primary-200"
                                            >
                                                View Customers
                                            </button>
                                        </div>
                                    </Popup>
                                </CircleMarker>
                            );
                        } else if (entity.level === 'Customer') {
                            const status = (entity as any).collectionStatus || 'paid';
                            const cColor = status === 'paid' ? '#3b82f6' : status === 'pending' ? '#f59e0b' : '#f43f5e';
                            // Enriched Data Display
                            const amount = '₹' + (2000 + Math.floor(Math.random() * 3000));
                            const date = '13-Dec-2025';
                            const dist = Math.floor(Math.random() * 400) + 'm from center';

                            return (
                                <CircleMarker
                                    key={entity.id}
                                    center={entity.coord}
                                    radius={4}
                                    pathOptions={{ fillColor: cColor, color: 'white', weight: 1, fillOpacity: 0.9 }}
                                >
                                    <Popup>
                                        <div className="text-left">
                                            <div className="font-bold text-sm mb-1">{entity.name}</div>
                                            <div className="text-[10px] text-secondary-400 font-mono mb-1">
                                                {entity.coord[0].toFixed(5)}, {entity.coord[1].toFixed(5)}
                                            </div>
                                            <div className="text-xs text-secondary-500 mb-2">Loan ID: #{(entity.id.split('-').pop())?.toUpperCase()}</div>

                                            <div className="space-y-1 text-xs">
                                                <div className="flex justify-between">
                                                    <span className="text-secondary-500">Status:</span>
                                                    <span className="font-bold uppercase" style={{ color: cColor }}>{status}</span>
                                                </div>
                                                <div className="flex justify-between">
                                                    <span className="text-secondary-500">Distance:</span>
                                                    <span>{dist}</span>
                                                </div>
                                                <div className="flex justify-between">
                                                    <span className="text-secondary-500">Amount:</span>
                                                    <span className="font-mono">{amount}</span>
                                                </div>
                                                <div className="flex justify-between">
                                                    <span className="text-secondary-500">Date:</span>
                                                    <span>{date}</span>
                                                </div>
                                            </div>
                                        </div>
                                    </Popup>
                                </CircleMarker>
                            );
                        }
                        return null;
                    })}

                    {/* FENCE VISUALIZATION */}
                    {(currentLevel === 'Group') && selectedEntity && (
                        <Circle
                            center={selectedEntity.coord}
                            pathOptions={{ color: '#3b82f6', weight: 2, dashArray: '8, 8', fillOpacity: 0.05, fillColor: '#3b82f6' }}
                            radius={400}
                        />
                    )}
                </MapContainer>
            </div>

            {/* RIGHT: Stats Panel */}
            <div className="w-[340px] flex flex-col gap-4 overflow-y-auto shrink-0">

                {/* 1. Header with Context */}
                <div className="bg-white p-5 rounded-xl shadow-sm border border-secondary-200">
                    <div className="flex items-center gap-2 mb-2">
                        <div className="bg-primary-100 p-2 rounded-lg text-primary-700"><LocateFixed size={20} /></div>
                        <div>
                            <div className="text-xs text-secondary-500 font-bold uppercase">{currentLevel} Level</div>
                            <div className="text-lg font-bold text-secondary-900 leading-none">{currentStats.name}</div>
                        </div>
                    </div>
                </div>

                {/* 2. Key Metrics */}
                <div className="grid grid-cols-2 gap-3">
                    <div className="bg-white p-4 rounded-xl shadow-sm border border-secondary-200">
                        <div className="text-secondary-500 text-xs font-medium mb-1 flex items-center justify-between">GLP <ArrowUpRight size={12} className="text-emerald-500" /></div>
                        <div className="text-xl font-bold text-secondary-900">₹{currentStats.glp > 100 ? Math.round(currentStats.glp).toLocaleString() : currentStats.glp.toFixed(1)} <span className="text-xs text-secondary-400 font-normal">Cr</span></div>
                    </div>
                    <div className="bg-white p-4 rounded-xl shadow-sm border border-secondary-200">
                        <div className="text-secondary-500 text-xs font-medium mb-1">{getLevelItemName(currentLevel)}</div>
                        <div className="text-xl font-bold text-secondary-900">{entities.length}</div>
                    </div>
                    <div className="bg-white p-4 rounded-xl shadow-sm border border-secondary-200">
                        <div className="text-secondary-500 text-xs font-medium mb-1">PAR {'>'} 30</div>
                        <div className="text-xl font-bold" style={{ color: getRiskColor(currentStats.par30) }}>{currentStats.par30.toFixed(2)}%</div>
                    </div>
                    <div className="bg-white p-4 rounded-xl shadow-sm border border-secondary-200">
                        <div className="text-secondary-500 text-xs font-medium mb-1">Active</div>
                        <div className="text-xl font-bold text-secondary-900">98%</div>
                    </div>
                </div>

                {/* 3. Geo-Fence Card (Only at Center/Group level) */}
                {(currentLevel === 'Center' || currentLevel === 'Group') && (
                    <div className="bg-emerald-50 p-4 rounded-xl shadow-sm border border-emerald-100">
                        <div className="flex justify-between items-center mb-3">
                            <div className="text-emerald-900 font-bold">Centre Geofence</div>
                            <div className="bg-emerald-200 text-emerald-800 text-xs px-2 py-0.5 rounded-full font-bold">{complyPercent}% Compliance</div>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                            <div className="bg-white p-3 rounded-lg border border-emerald-100 text-center">
                                <div className="text-2xl font-bold text-emerald-600">{withinCount}</div>
                                <div className="text-xs text-emerald-800 font-medium">Within Range</div>
                            </div>
                            <div className="bg-white p-3 rounded-lg border border-red-100 text-center">
                                <div className="text-2xl font-bold text-rose-600">{outsideCount}</div>
                                <div className="text-xs text-rose-800 font-medium">Outside</div>
                            </div>
                        </div>
                    </div>
                )}

                {/* 4. Controls & Legend (Simplified) */}
                <div className="bg-white p-4 rounded-xl shadow-sm border border-secondary-200 flex-1">
                    {/* View Toggles */}
                    <div className="grid grid-cols-3 gap-1 bg-secondary-50 p-1 rounded-lg mb-4">
                        <button onClick={() => setViewMode('growth')} className={cn("py-1.5 rounded text-[10px] font-bold uppercase tracking-wider transition-all", viewMode === 'growth' ? "bg-white text-primary-700 shadow-sm" : "text-secondary-500")}>Growth</button>
                        <button onClick={() => setViewMode('risk')} className={cn("py-1.5 rounded text-[10px] font-bold uppercase tracking-wider transition-all", viewMode === 'risk' ? "bg-white text-rose-700 shadow-sm" : "text-secondary-500")}>Risk</button>
                        <button onClick={() => setViewMode('compliance')} className={cn("py-1.5 rounded text-[10px] font-bold uppercase tracking-wider transition-all", viewMode === 'compliance' ? "bg-white text-purple-700 shadow-sm" : "text-secondary-500")}>Ops</button>
                    </div>

                    <h3 className="text-xs font-bold text-secondary-500 uppercase mb-3 text-center border-b border-secondary-100 pb-2">Legend</h3>
                    <div className="space-y-2">
                        {currentLevel === 'Client' ? (
                            <>
                                <div className="flex items-center gap-2"><div className="w-2.5 h-2.5 rounded-full bg-blue-500"></div><span className="text-xs text-secondary-600">Paid</span></div>
                                <div className="flex items-center gap-2"><div className="w-2.5 h-2.5 rounded-full bg-amber-500"></div><span className="text-xs text-secondary-600">Pending</span></div>
                                <div className="flex items-center gap-2"><div className="w-2.5 h-2.5 rounded-full bg-rose-500"></div><span className="text-xs text-secondary-600">Overdue</span></div>
                            </>
                        ) : (
                            <>
                                <div className="flex items-center gap-2"><span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span><span className="text-xs text-secondary-600">Good / Within</span></div>
                                <div className="flex items-center gap-2"><span className="w-2.5 h-2.5 rounded-full bg-rose-500"></span><span className="text-xs text-secondary-600">Bad / Outside</span></div>
                            </>
                        )}
                    </div>
                </div>
            </div>

        </div >
    );
};



export default GeoDashboard;
