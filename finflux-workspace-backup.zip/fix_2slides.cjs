const fs = require('fs');
const path = require('path');
const dir = path.join(__dirname, 'src', 'pages');

const files = fs.readdirSync(dir).filter(f => f.endsWith('Dashboard.tsx'));
files.forEach(file => {
    let content = fs.readFileSync(path.join(dir, file), 'utf8');

    if (file === 'HomeDashboard.tsx') {
        content = content.replace(/const slices = sliceCanvas\(canvas, 1080\);/g, "const slices = sliceCanvas(canvas, canvas.height + 10);");
        content = content.replace(/const slices = sliceCanvas\(canvas, 810\);/g, "const slices = sliceCanvas(canvas, canvas.height + 10);");

        content = content.replace(/format: \[1440, 1080\]/g, "format: [1440, slice.h]");
        content = content.replace(/pdf!\.addPage\(\[1440, 1080\]/g, "pdf!.addPage([1440, slice.h]");

        content = content.replace(/h:\s*`\$\{\(slice\.h \/ 810\) \* 100\}%`/g, "h: '100%'");
    } else {
        const pdfRegex = /const slices = sliceCanvas\(canvas, 1080\);\s*const pdf = new jsPDF\(\{ orientation: 'portrait', unit: 'px', format: \[1440, 1080\] \}\);\s*slices\.forEach\(\(slice, i\) => \{\s*if \(i > 0\) pdf\.addPage\(\[1440, 1080\], 'portrait'\);\s*pdf\.addImage\(slice\.data, 'JPEG', 0, 0, slice\.w, slice\.h\);\s*\}\);/g;

        const newPdf = `const slices = sliceCanvas(canvas, Math.ceil(canvas.height / 2));
            const pdf = new jsPDF({ orientation: 'portrait', unit: 'px', format: [canvas.width, slices[0].h] });
            slices.forEach((slice, i) => {
                if (i > 0) pdf.addPage([canvas.width, slice.h], 'portrait');
                pdf.addImage(slice.data, 'JPEG', 0, 0, slice.w, slice.h);
            });`;

        content = content.replace(pdfRegex, newPdf);

        const pptRegex = /const slices = sliceCanvas\(canvas, 810\);\s*slices\.forEach\(\(slice\) => \{\s*const slide = pptx\.addSlide\(\);\s*slide\.addImage\(\{ data: slice\.data, x: 0, y: 0, w: '100%', h: ('.*?'|`.*?`), sizing: \{ type: 'contain', w: '100%', h: '100%' \} \}\);\s*\}\);/g;

        const newPpt = `const slices = sliceCanvas(canvas, Math.ceil(canvas.height / 2));
            slices.forEach((slice) => {
                const slide = pptx.addSlide();
                slide.addImage({ data: slice.data, x: 0, y: 0, w: '100%', h: '100%', sizing: { type: 'contain', w: '100%', h: '100%' } });
            });`;

        content = content.replace(pptRegex, newPpt);
    }

    fs.writeFileSync(path.join(dir, file), content, 'utf8');
    console.log("Updated", file);
});
