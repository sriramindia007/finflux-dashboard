const fs = require('fs');
const f = 'src/pages/TrendsDashboard.tsx';
let c = fs.readFileSync(f, 'utf8');

// The problem: line 202 has `const [showExport, setShowExport] = useState(false);`
// then line 204 has the JSX div WITHOUT a `return (` before it
// Fix: add `return (` before the JSX div, and move showExport state to before handleExportPPT

// Step 1: Move showExport state up to be with other state declarations
// Find: `const [showExport, setShowExport] = useState(false);\n\n        <div ref={exportRef}`
// Replace with: `return (\n        <div ref={exportRef}`
// And add the state earlier

// Remove the erroneous placement of showExport
c = c.replace(
    /(\n    const \[showExport, setShowExport\] = useState\(false\);\n\n)(    <div ref=\{exportRef\})/,
    '\n    return (\n        $2'
);

// Now add showExport state before the existing state declarations  
// Find the existing state: `const [frequency, setFrequency]`
c = c.replace(
    "    const [frequency, setFrequency] = useState<'Monthly' | 'Quarterly'>('Monthly');",
    "    const [frequency, setFrequency] = useState<'Monthly' | 'Quarterly'>('Monthly');\n    const [showExport, setShowExport] = useState(false);"
);

// Verify the return is there
const hasReturn = c.match(/return \(\n\s+<div ref=\{exportRef\}/);
console.log('return ( before JSX:', !!hasReturn);
const hasShowExportState = (c.match(/const \[showExport/g) || []).length;
console.log('showExport state count:', hasShowExportState);

fs.writeFileSync(f, c, 'utf8');
