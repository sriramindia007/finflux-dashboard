const fs = require('fs');
const path = require('path');

const dir = path.join(__dirname, 'src', 'pages');
const files = fs.readdirSync(dir).filter(f => f.endsWith('Dashboard.tsx') && f !== 'HomeDashboard.tsx' && f !== 'GeoDashboard.tsx');

files.forEach(file => {
    let content = fs.readFileSync(path.join(dir, file), 'utf8');

    // Add sliceCanvas import
    if (content.includes('import { saveFile }') && !content.includes('sliceCanvas')) {
        content = content.replace("import { saveFile }", "import { saveFile, sliceCanvas }");
    }

    // PDF 
    const pdfRegex = /const canvas = await captureSlide\(exportRef\);\s*const imgData = canvas\.toDataURL\('image\/jpeg', 1\.0\);[\s\S]*?pdf\.addImage\([\s\S]*?\);\s*saveFile\(pdf\.output\('blob'\), getFilename\('pdf'\)\);/;

    const newPdf = `const canvas = await captureSlide(exportRef);
            const slices = sliceCanvas(canvas, 1080);
            const pdf = new jsPDF({ orientation: 'portrait', unit: 'px', format: [1440, 1080] });
            slices.forEach((slice, i) => {
                if (i > 0) pdf.addPage([1440, 1080], 'portrait');
                pdf.addImage(slice.data, 'JPEG', 0, 0, slice.w, slice.h);
            });
            saveFile(pdf.output('blob'), getFilename('pdf'));`;

    content = content.replace(pdfRegex, newPdf);

    // PPT
    const pptRegex = /const canvas = await captureSlide\(exportRef\);\s*const imgData = canvas\.toDataURL\('image\/jpeg', 1\.0\);\s*const slide = pptx\.addSlide\(\);\s*slide\.addImage\(\{[\s\S]*?\}\);/;

    const newPpt = `const canvas = await captureSlide(exportRef);
            const slices = sliceCanvas(canvas, 810);
            slices.forEach((slice) => {
                const slide = pptx.addSlide();
                slide.addImage({ data: slice.data, x: 0, y: 0, w: '100%', h: \`\${(slice.h / 810) * 100}%\`, sizing: { type: 'contain', w: '100%', h: '100%' } });
            });`;

    content = content.replace(pptRegex, newPpt);

    fs.writeFileSync(path.join(dir, file), content, 'utf8');
    console.log("Updated", file);
});
