import { useState, useMemo } from 'react';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, ComposedChart, Area } from 'recharts';
import { TrendingUp, Users, Wallet, TrendingDown } from 'lucide-react';
import { COMPANY_HISTORY, COMPANY_METRICS } from '../data/mfiData';
import { getGlobalStats } from '../data/geoDataComplete';

// Simulated last year data (20% less for illustration)
const lastYearHistory = COMPANY_HISTORY.map(m => ({
    ...m,
    glp: m.glp * 0.85,
    disbursement: m.disbursement * 0.82,
    collection: m.collection * 0.83,
    activeClients: Math.floor(m.activeClients * 0.88),
    par30: m.par30 * 1.15, // Higher PAR last year
    par90: m.par90 * 1.18
}));

// Map Central History to Chart Format with YoY comparison
const trendsData = COMPANY_HISTORY.map((m, idx) => ({
    month: m.month,
    newCustomers: Math.floor(m.activeClients / 2000), // Simulated scale

    // PAR Metrics (different buckets)
    par30: m.par30,
    par60: m.par60 || parseFloat((m.par30 * 0.65).toFixed(2)),
    par90: m.par90,
    par180: m.par180 || (m.par90 * 0.4),

    // Portfolio
    glp: m.glp,
    glpYoY: lastYearHistory[idx].glp,

    // Operations
    disb: m.disbursement,
    disbYoY: lastYearHistory[idx].disbursement,

    // NPA for comparison
    npa: m.par90,

    // Attrition (simulated trend - declining over year)
    attrition: 16.5 - (idx * 0.15), // Starts at 16.5%, declines to ~14.7%

    branches: 185
}));

const getQuarterlyData = (data: typeof trendsData) => {
    const quarters = [
        { name: 'Q1 (Jan-Mar)', months: [0, 1, 2] },
        { name: 'Q2 (Apr-Jun)', months: [3, 4, 5] },
        { name: 'Q3 (Jul-Sep)', months: [6, 7, 8] },
        { name: 'Q4 (Oct-Dec)', months: [9, 10, 11] }
    ];

    return quarters.map(q => {
        const subset = data.filter((_, i) => q.months.includes(i));
        const last = subset[subset.length - 1] || subset[0];

        return {
            month: q.name,
            newCustomers: subset.reduce((sum, m) => sum + m.newCustomers, 0),
            par30: last.par30,
            par60: last.par60,
            par90: last.par90,
            par180: last.par180,
            glp: last.glp,
            glpYoY: last.glpYoY,
            disb: subset.reduce((sum, m) => sum + m.disb, 0),
            disbYoY: subset.reduce((sum, m) => sum + m.disbYoY, 0),
            npa: last.npa,
            attrition: last.attrition,
            branches: last.branches
        };
    });
};

const TrendsDashboard = () => {
    const [frequency, setFrequency] = useState<'Monthly' | 'Quarterly'>('Monthly');
    const globalStats = getGlobalStats();

    const chartData = useMemo(() => {
        return frequency === 'Monthly' ? trendsData : getQuarterlyData(trendsData);
    }, [frequency]);

    // Calculate YoY growth
    const glpGrowth = ((trendsData[11].glp - trendsData[11].glpYoY) / trendsData[11].glpYoY * 100).toFixed(1);
    const clientGrowth = ((trendsData[11].newCustomers - trendsData[0].newCustomers) / trendsData[0].newCustomers * 100).toFixed(1);

    return (
        <div className="space-y-6">
            <div className="flex items-center justify-between">
                <div>
                    <h2 className="text-2xl font-bold text-secondary-900">Performance Trends</h2>
                    <p className="text-secondary-500">Year-over-year and monthly trend analysis (2025)</p>
                </div>
                <div className="flex gap-4">
                    {/* Frequency Toggle */}
                    <div className="bg-secondary-100 p-1 rounded-lg flex text-sm font-medium">
                        <button
                            onClick={() => setFrequency('Monthly')}
                            className={`px-3 py-1.5 rounded-md transition-all ${frequency === 'Monthly' ? 'bg-white text-primary-600 shadow-sm' : 'text-secondary-500 hover:text-secondary-900'}`}
                        >
                            Monthly
                        </button>
                        <button
                            onClick={() => setFrequency('Quarterly')}
                            className={`px-3 py-1.5 rounded-md transition-all ${frequency === 'Quarterly' ? 'bg-white text-primary-600 shadow-sm' : 'text-secondary-500 hover:text-secondary-900'}`}
                        >
                            Quarterly
                        </button>
                    </div>

                    <select className="bg-white border border-secondary-300 rounded-lg px-3 py-2 text-sm text-secondary-700 outline-none focus:ring-2 focus:ring-primary-500">
                        <option>2025 (Current)</option>
                        <option>2024</option>
                        <option>2023</option>
                    </select>
                </div>
            </div>

            {/* Summary Cards with YoY */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="bg-gradient-to-br from-primary-500 to-primary-600 p-6 rounded-xl text-white shadow-lg">
                    <div className="flex items-center justify-between mb-2">
                        <Wallet size={24} />
                        <span className="text-xs bg-white/20 px-2 py-1 rounded-full">YoY</span>
                    </div>
                    <div className="text-3xl font-bold">₹{COMPANY_METRICS.currentGLP.toFixed(0)} Cr</div>
                    <div className="text-sm opacity-90">Portfolio (GLP)</div>
                    <div className="mt-2 text-xs flex items-center gap-1">
                        <TrendingUp size={14} />
                        +{glpGrowth}% vs Last Year
                    </div>
                </div>

                <div className="bg-gradient-to-br from-emerald-500 to-emerald-600 p-6 rounded-xl text-white shadow-lg">
                    <div className="flex items-center justify-between mb-2">
                        <Users size={24} />
                        <span className="text-xs bg-white/20 px-2 py-1 rounded-full">YTD</span>
                    </div>
                    <div className="text-3xl font-bold">{(trendsData[11].newCustomers).toFixed(1)}k</div>
                    <div className="text-sm opacity-90">New Customers</div>
                    <div className="mt-2 text-xs flex items-center gap-1">
                        <TrendingUp size={14} />
                        +{clientGrowth}% vs Jan
                    </div>
                </div>

                <div className="bg-gradient-to-br from-rose-500 to-rose-600 p-6 rounded-xl text-white shadow-lg">
                    <div className="flex items-center justify-between mb-2">
                        <TrendingDown size={24} />
                        <span className="text-xs bg-white/20 px-2 py-1 rounded-full">Current</span>
                    </div>
                    <div className="text-3xl font-bold">{COMPANY_METRICS.parOver30}%</div>
                    <div className="text-sm opacity-90">PAR 30+</div>
                    <div className="mt-2 text-xs">{(trendsData[11].par30 - trendsData[0].par30).toFixed(2)}% vs Jan</div>
                </div>

                <div className="bg-gradient-to-br from-amber-500 to-amber-600 p-6 rounded-xl text-white shadow-lg">
                    <div className="flex items-center justify-between mb-2">
                        <Users size={24} />
                        <span className="text-xs bg-white/20 px-2 py-1 rounded-full">Dec</span>
                    </div>
                    <div className="text-3xl font-bold">{trendsData[11].attrition.toFixed(2)}%</div>
                    <div className="text-sm opacity-90">Staff Attrition</div>
                    <div className="mt-2 text-xs flex items-center gap-1">
                        <TrendingDown size={14} />
                        {(trendsData[0].attrition - trendsData[11].attrition).toFixed(2)}% improvement YTD
                    </div>
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Portfolio Growth with YoY */}
                <div className="bg-white p-6 rounded-xl border border-secondary-200 shadow-sm">
                    <h3 className="text-lg font-semibold text-secondary-800 mb-4">Portfolio Growth (YoY Comparison)</h3>
                    <ResponsiveContainer width="100%" height={300}>
                        <LineChart data={chartData}>
                            <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                            <XAxis dataKey="month" stroke="#6b7280" />
                            <YAxis stroke="#6b7280" />
                            <Tooltip
                                contentStyle={{ backgroundColor: '#fff', border: '1px solid #e5e7eb', borderRadius: '8px' }}
                                formatter={(value) => `₹${value} Cr`}
                            />
                            <Legend />
                            <Line type="monotone" dataKey="glp" stroke="#0ea5e9" strokeWidth={3} name="2025 GLP" dot={{ fill: '#0ea5e9', r: 4 }} />
                            <Line type="monotone" dataKey="glpYoY" stroke="#94a3b8" strokeWidth={2} name="2024 GLP" strokeDasharray="5 5" dot={{ fill: '#94a3b8', r: 3 }} />
                        </LineChart>
                    </ResponsiveContainer>
                </div>

                {/* Disbursement vs NPA */}
                <div className="bg-white p-6 rounded-xl border border-secondary-200 shadow-sm">
                    <h3 className="text-lg font-semibold text-secondary-800 mb-4">Disbursement vs NPA Trend</h3>
                    <ResponsiveContainer width="100%" height={300}>
                        <ComposedChart data={chartData}>
                            <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                            <XAxis dataKey="month" stroke="#6b7280" />
                            <YAxis yAxisId="left" stroke="#6b7280" label={{ value: 'Disbursement (Cr)', angle: -90, position: 'insideLeft' }} />
                            <YAxis yAxisId="right" orientation="right" stroke="#ef4444" label={{ value: 'NPA (%)', angle: 90, position: 'insideRight' }} />
                            <Tooltip
                                contentStyle={{ backgroundColor: '#fff', border: '1px solid #e5e7eb', borderRadius: '8px' }}
                            />
                            <Legend />
                            <Bar yAxisId="left" dataKey="disb" fill="#10b981" name="Disbursement (Cr)" radius={[8, 8, 0, 0]} />
                            <Line yAxisId="right" type="monotone" dataKey="npa" stroke="#ef4444" strokeWidth={3} name="NPA 90+ (%)" dot={{ fill: '#ef4444', r: 4 }} />
                        </ComposedChart>
                    </ResponsiveContainer>
                </div>
            </div>

            {/* PAR Breakdown with Different Colors */}
            <div className="bg-white p-6 rounded-xl border border-secondary-200 shadow-sm">
                <h3 className="text-lg font-semibold text-secondary-800 mb-4">Portfolio at Risk (PAR) Breakdown - Multi-Bucket Trend</h3>
                <ResponsiveContainer width="100%" height={350}>
                    <LineChart data={chartData}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                        <XAxis dataKey="month" stroke="#6b7280" />
                        <YAxis stroke="#6b7280" label={{ value: 'PAR %', angle: -90, position: 'insideLeft' }} />
                        <Tooltip
                            contentStyle={{ backgroundColor: '#fff', border: '1px solid #e5e7eb', borderRadius: '8px' }}
                            formatter={(value) => `${value}%`}
                        />
                        <Legend />
                        <Line type="monotone" dataKey="par30" stroke="#f59e0b" strokeWidth={3} name="PAR 30+ (%)" dot={{ fill: '#f59e0b', r: 5 }} />
                        <Line type="monotone" dataKey="par60" stroke="#f97316" strokeWidth={3} name="PAR 60+ (%)" dot={{ fill: '#f97316', r: 4 }} />
                        <Line type="monotone" dataKey="par90" stroke="#dc2626" strokeWidth={3} name="PAR 90+ (%)" dot={{ fill: '#dc2626', r: 5 }} />
                        <Line type="monotone" dataKey="par180" stroke="#7e22ce" strokeWidth={3} name="PAR 180+ (%)" dot={{ fill: '#7e22ce', r: 5 }} />
                    </LineChart>
                </ResponsiveContainer>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Disbursement YoY Comparison */}
                <div className="bg-white p-6 rounded-xl border border-secondary-200 shadow-sm">
                    <h3 className="text-lg font-semibold text-secondary-800 mb-4">Disbursement YoY Comparison</h3>
                    <ResponsiveContainer width="100%" height={300}>
                        <BarChart data={chartData}>
                            <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                            <XAxis dataKey="month" stroke="#6b7280" />
                            <YAxis stroke="#6b7280" />
                            <Tooltip
                                contentStyle={{ backgroundColor: '#fff', border: '1px solid #e5e7eb', borderRadius: '8px' }}
                                formatter={(value) => `₹${value} Cr`}
                            />
                            <Legend />
                            <Bar dataKey="disb" fill="#10b981" name="2025 Disbursement" radius={[8, 8, 0, 0]} />
                            <Bar dataKey="disbYoY" fill="#94a3b8" name="2024 Disbursement" radius={[8, 8, 0, 0]} />
                        </BarChart>
                    </ResponsiveContainer>
                </div>

                {/* Attrition Trend */}
                <div className="bg-white p-6 rounded-xl border border-secondary-200 shadow-sm">
                    <h3 className="text-lg font-semibold text-secondary-800 mb-4">Staff Attrition Trend</h3>
                    <ResponsiveContainer width="100%" height={300}>
                        <ComposedChart data={chartData}>
                            <defs>
                                <linearGradient id="attritionGradient" x1="0" y1="0" x2="0" y2="1">
                                    <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.3} />
                                    <stop offset="95%" stopColor="#f59e0b" stopOpacity={0} />
                                </linearGradient>
                            </defs>
                            <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                            <XAxis dataKey="month" stroke="#6b7280" />
                            <YAxis stroke="#6b7280" label={{ value: 'Attrition %', angle: -90, position: 'insideLeft' }} />
                            <Tooltip
                                contentStyle={{ backgroundColor: '#fff', border: '1px solid #e5e7eb', borderRadius: '8px' }}
                                formatter={(value) => `${Number(value).toFixed(2)}%`}
                            />
                            <Legend />
                            <Area type="monotone" dataKey="attrition" stroke="#f59e0b" strokeWidth={2} fill="url(#attritionGradient)" name="Attrition Rate (%)" />
                        </ComposedChart>
                    </ResponsiveContainer>
                </div>
            </div>

            {/* Customer Acquisition */}
            <div className="bg-white p-6 rounded-xl border border-secondary-200 shadow-sm">
                <h3 className="text-lg font-semibold text-secondary-800 mb-4">New Customer Acquisition (in Thousands)</h3>
                <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={chartData}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                        <XAxis dataKey="month" stroke="#6b7280" />
                        <YAxis stroke="#6b7280" />
                        <Tooltip
                            contentStyle={{ backgroundColor: '#fff', border: '1px solid #e5e7eb', borderRadius: '8px' }}
                            formatter={(value) => `${value}k`}
                        />
                        <Legend />
                        <Bar dataKey="newCustomers" fill="#6366f1" name="New Customers" radius={[8, 8, 0, 0]} />
                    </BarChart>
                </ResponsiveContainer>
            </div>
        </div>
    );
};

export default TrendsDashboard;
