const fs = require('fs');
const path = require('path');
const file = path.join(__dirname, 'src', 'pages', 'HomeDashboard.tsx');
let c = fs.readFileSync(file, 'utf8');

// 1. Add TOTAL_WRITEOFF to geo import
c = c.replace(
    "import { ALL_STATES_DATA, TOTAL_BRANCHES_COUNT } from '../data/geoDataComplete';",
    "import { ALL_STATES_DATA, TOTAL_BRANCHES_COUNT, TOTAL_WRITEOFF } from '../data/geoDataComplete';"
);
c = c.replace(
    "import { CURRENT_FINANCIALS } from '../data/financeData';  // NIM/ROA/OER/CRAR only",
    "import { CURRENT_FINANCIALS } from '../data/financeData';  // portfolio yield from contracts"
);

// 2. Replace C-Suite badge comment block + badge array with LMS-defensible MFI lending metrics
const badgeOld = [
    "    // ── C-Suite badge row",
    "    // NIM/ROA/OER/CRAR: CURRENT_FINANCIALS",
    "    // PAR: COMPANY_HISTORY last month",
    "    // Coll Eff: mtdEff computed above",
    "    const badges = [",
    "        { label: 'NIM'",
    "        { label: 'ROA'",
    "        { label: 'CRAR'",
    "        { label: 'Coll. Eff.'",
    "        { label: 'PAR 30+'",
    "        { label: 'OER'",
    "    ];"
].join('\n');

// Find by line pattern matching
const lines = c.split('\n');
let startIdx = -1, endIdx = -1;
for (let i = 0; i < lines.length; i++) {
    if (lines[i].includes('C-Suite badge row')) startIdx = i;
    if (startIdx > 0 && i > startIdx && lines[i].trim() === '];') { endIdx = i; break; }
}

if (startIdx >= 0 && endIdx >= 0) {
    const newBadgeLines = [
        "    // ── MFI Lending Badge Row — ALL computable from FINFLUX LMS (lending side) ──────────────",
        "    const portfolioYield = sn(CURRENT_FINANCIALS.yieldOnPortfolio, 22.5);        // from loan contract rates",
        "    const loanAtRiskCr = parseFloat((currentGLP * currentPAR / 100).toFixed(0)); // PAR% × GLP = ₹ exposure",
        "    const writeoffRate = TOTAL_WRITEOFF > 0 ? ((TOTAL_WRITEOFF / currentGLP) * 100) : 0.18;",
        "    const disbAchievement = (ytdDisb / (COMPANY_METRICS.ytdDisbursementTarget || 18500)) * 100;",
        "    const avgTicketK = currentClientsCount > 0",
        "        ? parseFloat(((currentGLP * 10000) / currentClientsCount).toFixed(1)) : 18.0; // ₹k per borrower",
        "    const badges = [",
        "        { label: 'Portfolio Yield', value: fp(portfolioYield, 1), bench: 'Contract rates', ok: portfolioYield <= 24 },",
        "        { label: 'Loan at Risk', value: `₹${loanAtRiskCr} Cr`, bench: `PAR ${fp(currentPAR, 1)} of GLP`, ok: currentPAR <= 3.6 },",
        "        { label: 'Coll. Efficiency', value: fp(mtdEff), bench: 'Target 99%', ok: mtdEff >= 97 },",
        "        { label: 'Write-off Rate', value: fp(writeoffRate, 2), bench: '% of GLP', ok: writeoffRate <= 0.5 },",
        "        { label: 'Disb. Achievement', value: fp(disbAchievement, 1), bench: 'vs FY Target', ok: disbAchievement >= 80 },",
        "        { label: 'Avg Ticket Size', value: `₹${avgTicketK}k`, bench: 'Per borrower', ok: true },",
        "    ];"
    ];
    lines.splice(startIdx, endIdx - startIdx + 1, ...newBadgeLines);
    c = lines.join('\n');
    console.log(`Replaced badge block (lines ${startIdx}-${endIdx})`);
} else {
    console.log('Badge block not found, startIdx:', startIdx, 'endIdx:', endIdx);
}

// 3. Fix bottom quick row — CRAR/CoF → Write-off Rate / Portfolio Yield
c = c.replace("'CRAR', value: fp(sn(CURRENT_FINANCIALS.crar), 1), ok: sn(CURRENT_FINANCIALS.crar) >= 15, sub: 'Min 15%'",
    "'Write-off Rate', value: fp(writeoffRate, 2), ok: writeoffRate <= 0.5, sub: '% of GLP (LMS)'");
c = c.replace("'Cost of Funds', value: fp(sn(CURRENT_FINANCIALS.costOfFunds), 1), ok: true, sub: 'Annualised'",
    "'Portfolio Yield', value: fp(portfolioYield, 1), ok: portfolioYield <= 24, sub: 'vs RBI 24% cap'");
c = c.replace("{/* Quick financial row */}", "{/* MFI lending quick metrics */}");

// 4. Fix deep-dive nav - replace /financial with /trends, update portfolio label
c = c.replace(
    "{ to: '/financial', label: 'P&L \u00b7 Ratios \u00b7 Funding', sub: 'Income, expenses, ROA, NIM', color: 'bg-indigo-50 border-indigo-200 hover:border-indigo-400' },",
    "{ to: '/trends', label: 'Performance Trends', sub: 'GLP YoY, disbursement, PAR trend', color: 'bg-indigo-50 border-indigo-200 hover:border-indigo-400' },"
);
c = c.replace(
    "{ to: '/portfolio', label: 'Risk & Compliance', sub: 'PAR, GNPA, audit control',",
    "{ to: '/portfolio', label: 'Risk & Portfolio', sub: 'PAR, vintage, audit, regulatory',"
);

// 5. Fix Excel export rows - use LMS metrics instead of NIM/ROA/CRAR
c = c.replace(
    "['NIM (ann.%) ', fp(sn(CURRENT_FINANCIALS.nim) * 12)],",
    "['Portfolio Yield (%)', fp(portfolioYield, 1)],"
);
c = c.replace(
    "['ROA (ann.%)', fp(sn(CURRENT_FINANCIALS.roa) * 12, 2)],",
    "['Loan at Risk (Cr)', `₹${loanAtRiskCr}`],"
);
c = c.replace(
    "['CRAR (%)', fp(sn(CURRENT_FINANCIALS.crar), 1)],",
    "['Write-off Rate (%)', fp(writeoffRate, 2)],"
);

fs.writeFileSync(file, c, 'utf8');
console.log('HomeDashboard.tsx patched successfully!');
