import { LucideIcon } from 'lucide-react';
import { cn } from '../lib/utils';

interface KPICardProps {
    title: string;
    value: string | number;
    subValue?: string;
    trend?: 'up' | 'down' | 'neutral';
    trendValue?: string;
    icon?: LucideIcon;
    className?: string;
}

const KPICard = ({ title, value, subValue, trend, trendValue, icon: Icon, className }: KPICardProps) => {
    return (
        <div className={cn("bg-white p-5 rounded-xl border border-secondary-200 shadow-sm hover:shadow-md transition-shadow", className)}>
            <div className="flex items-start justify-between mb-4">
                <h3 className="text-secondary-500 text-sm font-medium">{title}</h3>
                {Icon && (
                    <div className="p-2 bg-primary-50 text-primary-600 rounded-lg">
                        <Icon size={18} />
                    </div>
                )}
            </div>
            <div className="flex items-baseline gap-2">
                <span className="text-2xl font-bold text-secondary-900">{value}</span>
                {subValue && <span className="text-sm text-secondary-400">{subValue}</span>}
            </div>
            {trendValue && (
                <div className={cn("flex items-center gap-1 mt-2 text-xs font-medium",
                    trend === 'up' ? "text-success" : trend === 'down' ? "text-danger" : "text-secondary-500"
                )}>
                    <span>{trend === 'up' ? '↑' : trend === 'down' ? '↓' : '→'}</span>
                    <span>{trendValue}</span>
                    <span className="text-secondary-400 font-normal ml-1">vs last month</span>
                </div>
            )}
        </div>
    );
};

export default KPICard;
