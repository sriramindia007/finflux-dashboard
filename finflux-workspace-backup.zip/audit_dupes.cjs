const fs = require('fs');
const dashboards = [
    'src/pages/HomeDashboard.tsx',
    'src/pages/CollectionsDashboard.tsx',
    'src/pages/PortfolioDashboard.tsx',
    'src/pages/TrendsDashboard.tsx',
    'src/pages/BranchDashboard.tsx',
    'src/pages/ProductDashboard.tsx',
    'src/pages/OriginationDashboard.tsx',
];

const metrics = [
    'Collection Efficiency', 'PAR 30', 'GLP', 'Disbursement',
    'Write-off', 'GNPA', 'Digital', 'Overdue',
    'Active Clients', 'Portfolio Yield', 'Portfolio at Risk'
];

console.log('\n=== DUPLICATE KPI AUDIT ===\n');
dashboards.forEach(d => {
    const c = fs.readFileSync(d, 'utf8');
    const name = d.split('/').pop();
    const found = [];
    metrics.forEach(m => {
        // count how many times label appears as a visible string (in JSX text / label string, not imports)
        const matches = c.match(new RegExp("'" + m + "'|\"" + m + "\"|>" + m + "<", 'g')) || [];
        if (matches.length > 1) found.push(m + ' x' + matches.length);
    });
    if (found.length) console.log('[DUPES] ' + name + ': ' + found.join(' | '));
    else console.log('[OK   ] ' + name);
});
