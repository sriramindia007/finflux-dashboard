const fs = require('fs');
const text = fs.readFileSync('src/pages/HomeDashboard.tsx', 'utf8');

// replace all escaped backticks with something else
const unescaped = text.replace(/\\`/g, '');
const lines = unescaped.split('\n');

lines.forEach((l, i) => {
    let count = (l.match(/`/g) || []).length;
    if (count % 2 !== 0) {
        console.log(`Line ${i + 1}: ${l.trim()}`);
    }
});
