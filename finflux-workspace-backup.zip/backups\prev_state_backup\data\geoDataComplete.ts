/**
 * Complete Geographic Data with Branches and Centres
 * Hierarchy: Country → State → District → Branch → Centre
 */

import { STATES_DATA, COMPANY_METRICS } from './mfiData';

// ==================== BRANCH & CENTRE DATA STRUCTURE ====================

export interface Centre {
    name: string;
    coord: [number, number];
    clients: number;
    glp: number; // in Lakhs
    activeLoans: number;
    par30: number;
    writeOff?: number; // in Lakhs
}

export interface Branch {
    name: string;
    coord: [number, number];
    glp: number; // in Crores
    clients: number;
    centres: Centre[];
    writeOff?: number; // in Crores
}

export interface District {
    name: string;
    coord: [number, number];
    glp: number; // in Crores
    branches: Branch[];
    writeOff?: number; // in Crores
}

export interface State {
    name: string;
    coord: [number, number];
    glp: number; // in Crores
    color: string;
    districts: District[];
    writeOff?: number; // in Crores
}

// ==================== ODISHA STATE DATA ====================

const odishaData: State = {
    name: 'Odisha',
    coord: [20.9517, 85.0985],
    glp: STATES_DATA['odisha'].glp,
    color: '#0ea5e9',
    districts: [
        {
            name: 'Khordha',
            coord: [20.1815, 85.6200],
            glp: 920,
            branches: [
                {
                    name: 'Bagheitangi',
                    coord: [20.1622, 85.6771],
                    glp: 45,
                    clients: 2450,
                    centres: [
                        { name: 'Mundel Centre 1', coord: [20.1549, 85.6868], clients: 450, glp: 8.5, activeLoans: 420, par30: 1.2 },
                        { name: 'Mundel Centre 2', coord: [20.1575, 85.6647], clients: 480, glp: 9.2, activeLoans: 460, par30: 1.5 },
                        { name: 'Bhagbanpur Centre', coord: [20.1700, 85.6892], clients: 420, glp: 7.8, activeLoans: 400, par30: 1.8 },
                        { name: 'Haripur Centre', coord: [20.1733, 85.6733], clients: 510, glp: 10.1, activeLoans: 490, par30: 1.1 },
                        { name: 'Balakati Centre', coord: [20.1582, 85.6755], clients: 590, glp: 9.4, activeLoans: 570, par30: 0.9 },
                    ]
                },
                {
                    name: 'Tangi',
                    coord: [19.9267, 85.3955],
                    glp: 47.5,
                    clients: 2580,
                    centres: [
                        { name: 'Tangi Bazaar Centre', coord: [19.9331, 85.3886], clients: 520, glp: 9.8, activeLoans: 500, par30: 1.3 },
                        { name: 'Kalapathar Centre', coord: [19.9275, 85.3916], clients: 490, glp: 9.1, activeLoans: 470, par30: 1.6 },
                        { name: 'Balipatna Centre', coord: [19.9265, 85.3919], clients: 550, glp: 10.5, activeLoans: 530, par30: 1.0 },
                        { name: 'Jankia Centre', coord: [19.9342, 85.3961], clients: 510, glp: 9.6, activeLoans: 490, par30: 1.4 },
                        { name: 'Nuasahi Centre', coord: [19.9292, 85.3925], clients: 510, glp: 8.5, activeLoans: 490, par30: 1.7 },
                    ]
                },
                {
                    name: 'Jatni',
                    coord: [20.1598, 85.7074],
                    glp: 42,
                    clients: 2280,
                    centres: [
                        { name: 'Jatni Main Centre', coord: [20.1519, 85.6996], clients: 460, glp: 8.5, activeLoans: 440, par30: 1.5 },
                        { name: 'Bankuala Centre', coord: [20.1570, 85.7198], clients: 450, glp: 8.2, activeLoans: 430, par30: 1.8 },
                        { name: 'Kantabad Centre', coord: [20.1676, 85.7186], clients: 470, glp: 8.7, activeLoans: 450, par30: 1.2 },
                        { name: 'Sisupalgarh Centre', coord: [20.1621, 85.6980], clients: 450, glp: 8.1, activeLoans: 430, par30: 1.4 },
                        { name: 'Govindpur Centre', coord: [20.1674, 85.7040], clients: 450, glp: 8.5, activeLoans: 430, par30: 1.6 },
                    ]
                },
            ]
        },
        {
            name: 'Bhubaneswar',
            coord: [20.2961, 85.8245],
            glp: 765,
            branches: [
                {
                    name: 'Bhubaneswar Urban',
                    coord: [20.2972, 85.8665],
                    glp: 50,
                    clients: 2720,
                    centres: [
                        { name: 'Old Town Centre 1', coord: [20.3076, 85.8576], clients: 550, glp: 10.5, activeLoans: 530, par30: 0.9 },
                        { name: 'Old Town Centre 2', coord: [20.2899, 85.8673], clients: 540, glp: 10.2, activeLoans: 520, par30: 1.1 },
                        { name: 'Rasulgarh Centre', coord: [20.2951, 85.8752], clients: 530, glp: 9.8, activeLoans: 510, par30: 1.3 },
                        { name: 'Mancheswar Centre', coord: [20.2963, 85.8749], clients: 550, glp: 10.0, activeLoans: 530, par30: 1.0 },
                        { name: 'Chandrasekharpur Centre', coord: [20.3065, 85.8698], clients: 550, glp: 9.5, activeLoans: 530, par30: 1.2 },
                    ]
                },
                {
                    name: 'Patia',
                    coord: [20.3533, 85.8266],
                    glp: 38,
                    clients: 2050,
                    centres: [
                        { name: 'Patia Market Centre', coord: [20.3528, 85.8141], clients: 410, glp: 7.8, activeLoans: 390, par30: 1.5 },
                        { name: 'Jaydev Vihar Centre', coord: [20.3633, 85.8150], clients: 410, glp: 7.5, activeLoans: 390, par30: 1.7 },
                        { name: 'Nandankanan Road Centre', coord: [20.3536, 85.8347], clients: 420, glp: 7.9, activeLoans: 400, par30: 1.4 },
                        { name: 'Sailashree Vihar Centre', coord: [20.3636, 85.8176], clients: 400, glp: 7.2, activeLoans: 380, par30: 1.8 },
                        { name: 'Sundarpada Centre', coord: [20.3587, 85.8312], clients: 410, glp: 7.6, activeLoans: 390, par30: 1.6 },
                    ]
                },
            ]
        },
        {
            name: 'Cuttack',
            coord: [20.4625, 85.8828],
            glp: 720,
            branches: [
                {
                    name: 'Cuttack Central',
                    coord: [20.4577, 85.8829],
                    glp: 40,
                    clients: 2170,
                    centres: [
                        { name: 'Buxi Bazaar Centre', coord: [20.4463, 85.8828], clients: 440, glp: 8.2, activeLoans: 420, par30: 1.6 },
                        { name: 'Dargha Bazaar Centre', coord: [20.4507, 85.8937], clients: 430, glp: 7.9, activeLoans: 410, par30: 1.8 },
                        { name: 'Mangalabag Centre', coord: [20.4453, 85.8745], clients: 440, glp: 8.3, activeLoans: 420, par30: 1.5 },
                        { name: 'Badambadi Centre', coord: [20.4688, 85.8711], clients: 430, glp: 7.8, activeLoans: 410, par30: 1.7 },
                        { name: 'Telengabazar Centre', coord: [20.4683, 85.8838], clients: 430, glp: 7.8, activeLoans: 410, par30: 1.9 },
                    ]
                },
                {
                    name: 'Jagatpur',
                    coord: [20.493, 85.923],
                    glp: 35,
                    clients: 1900,
                    centres: [
                        { name: 'Jagatpur Main Centre', coord: [20.4885, 85.9172], clients: 380, glp: 7.1, activeLoans: 360, par30: 1.8 },
                        { name: 'Nuapatna Centre', coord: [20.4963, 85.9125], clients: 380, glp: 6.9, activeLoans: 360, par30: 2.0 },
                        { name: 'Mathasahi Centre', coord: [20.4806, 85.9191], clients: 390, glp: 7.2, activeLoans: 370, par30: 1.7 },
                        { name: 'Satichaura Centre', coord: [20.5007, 85.9120], clients: 370, glp: 6.8, activeLoans: 350, par30: 2.1 },
                        { name: 'Jobra Centre', coord: [20.4967, 85.9148], clients: 380, glp: 7.0, activeLoans: 360, par30: 1.9 },
                    ]
                },
            ]
        },
        {
            name: 'Puri',
            coord: [19.8134, 85.8312],
            glp: 540,
            branches: [
                {
                    name: 'Puri Town',
                    coord: [19.8, 85.82],
                    glp: 32,
                    clients: 1740,
                    centres: [
                        { name: 'Swargadwar Centre', coord: [19.7917, 85.8170], clients: 350, glp: 6.5, activeLoans: 330, par30: 2.0 },
                        { name: 'Grand Road Centre', coord: [19.7962, 85.8149], clients: 340, glp: 6.2, activeLoans: 320, par30: 2.2 },
                        { name: 'Baseli Sahi Centre', coord: [19.8006, 85.8238], clients: 360, glp: 6.7, activeLoans: 340, par30: 1.9 },
                        { name: 'Markandeswar Centre', coord: [19.7980, 85.8079], clients: 340, glp: 6.3, activeLoans: 320, par30: 2.1 },
                        { name: 'Penthakata Centre', coord: [19.7955, 85.8116], clients: 350, glp: 6.3, activeLoans: 330, par30: 2.0 },
                    ]
                },
                {
                    name: 'Konark Road',
                    coord: [19.885, 86.095],
                    glp: 28,
                    clients: 1520,
                    centres: [
                        { name: 'Baliguali Centre', coord: [19.8789, 86.0973], clients: 300, glp: 5.5, activeLoans: 280, par30: 2.3 },
                        { name: 'Kakatpur Centre', coord: [19.8959, 86.0904], clients: 310, glp: 5.7, activeLoans: 290, par30: 2.1 },
                        { name: 'Gopinathpur Centre', coord: [19.8966, 86.0831], clients: 300, glp: 5.4, activeLoans: 280, par30: 2.4 },
                        { name: 'Belapur Centre', coord: [19.8872, 86.0900], clients: 310, glp: 5.8, activeLoans: 290, par30: 2.2 },
                        { name: 'Charichhak Centre', coord: [19.8811, 86.0876], clients: 300, glp: 5.6, activeLoans: 280, par30: 2.3 },
                    ]
                },
            ]
        },
        {
            name: 'Balasore',
            coord: [21.4934, 86.9135],
            glp: 455,
            branches: [
                {
                    name: 'Balasore Main',
                    coord: [21.494, 86.925],
                    glp: 30,
                    clients: 1630,
                    centres: [
                        { name: 'Motiganj Centre', coord: [21.5049, 86.9237], clients: 330, glp: 6.1, activeLoans: 310, par30: 2.4 },
                        { name: 'Fakirmohan Centre', coord: [21.4977, 86.9127], clients: 320, glp: 5.8, activeLoans: 300, par30: 2.6 },
                        { name: 'Sahadevkhunta Centre', coord: [21.5024, 86.9269], clients: 330, glp: 6.2, activeLoans: 310, par30: 2.3 },
                        { name: 'Old Court Centre', coord: [21.4858, 86.9125], clients: 320, glp: 5.9, activeLoans: 300, par30: 2.5 },
                        { name: 'Gopalgaon Centre', coord: [21.5054, 86.9132], clients: 330, glp: 6.0, activeLoans: 310, par30: 2.4 },
                    ]
                },
                {
                    name: 'Soro',
                    coord: [21.288, 86.688],
                    glp: 25,
                    clients: 1360,
                    centres: [
                        { name: 'Soro Bazaar Centre', coord: [21.2952, 86.6834], clients: 270, glp: 4.9, activeLoans: 250, par30: 2.7 },
                        { name: 'Dahisara Centre', coord: [21.2768, 86.6847], clients: 280, glp: 5.1, activeLoans: 260, par30: 2.5 },
                        { name: 'Simulia Centre', coord: [21.2997, 86.7002], clients: 270, glp: 4.8, activeLoans: 250, par30: 2.8 },
                        { name: 'Olaver Centre', coord: [21.2921, 86.6840], clients: 270, glp: 5.0, activeLoans: 250, par30: 2.6 },
                        { name: 'Singla Centre', coord: [21.2834, 86.6867], clients: 270, glp: 5.2, activeLoans: 250, par30: 2.5 },
                    ]
                },
            ]
        },
    ]
};

// ==================== KARNATAKA STATE DATA ====================

const karnatakaData: State = {
    name: 'Karnataka',
    coord: [15.3173, 75.7139],
    glp: STATES_DATA['karnataka'].glp,
    color: '#8b5cf6',
    districts: [
        {
            name: 'Bangalore Urban',
            coord: [12.9716, 77.5946],
            glp: 580,
            branches: [
                {
                    name: 'Yeshwanthpur',
                    coord: [13.028, 77.5409],
                    glp: 35,
                    clients: 1900,
                    centres: [
                        { name: 'Yeshwanthpur Main', coord: [13.0247, 77.5430], clients: 380, glp: 7.0, activeLoans: 360, par30: 1.9 },
                        { name: 'Goraguntepalya Centre', coord: [13.0254, 77.5386], clients: 390, glp: 7.2, activeLoans: 370, par30: 1.8 },
                        { name: 'RMC Yard Centre', coord: [13.0285, 77.5340], clients: 380, glp: 6.9, activeLoans: 360, par30: 2.0 },
                        { name: 'Sanjay Nagar Centre', coord: [13.0331, 77.5522], clients: 370, glp: 6.8, activeLoans: 350, par30: 2.1 },
                        { name: 'Mathikere Centre', coord: [13.0290, 77.5370], clients: 380, glp: 7.1, activeLoans: 360, par30: 1.9 },
                    ]
                },
                {
                    name: 'Electronic City',
                    coord: [12.8407, 77.6764],
                    glp: 32,
                    clients: 1740,
                    centres: [
                        { name: 'Electronic City Phase 1', coord: [12.8345, 77.6725], clients: 350, glp: 6.5, activeLoans: 330, par30: 2.0 },
                        { name: 'Bommasandra Centre', coord: [12.8335, 77.6850], clients: 340, glp: 6.2, activeLoans: 320, par30: 2.2 },
                        { name: 'Hebbagodi Centre', coord: [12.8436, 77.6746], clients: 360, glp: 6.7, activeLoans: 340, par30: 1.9 },
                        { name: 'Attibele Centre', coord: [12.8333, 77.6790], clients: 340, glp: 6.3, activeLoans: 320, par30: 2.1 },
                        { name: 'Chandapura Centre', coord: [12.8290, 77.6648], clients: 350, glp: 6.3, activeLoans: 330, par30: 2.0 },
                    ]
                },
            ]
        },
        {
            name: 'Mysore',
            coord: [12.2958, 76.6394],
            glp: 420,
            branches: [
                {
                    name: 'Mysore Main',
                    coord: [12.3109, 76.652],
                    glp: 28,
                    clients: 1520,
                    centres: [
                        { name: 'Devaraja Market Centre', coord: [12.3004, 76.6428], clients: 300, glp: 5.5, activeLoans: 280, par30: 2.1 },
                        { name: 'Shivarampet Centre', coord: [12.3100, 76.6643], clients: 310, glp: 5.7, activeLoans: 290, par30: 2.0 },
                        { name: 'Mandi Mohalla Centre', coord: [12.3205, 76.6573], clients: 300, glp: 5.4, activeLoans: 280, par30: 2.2 },
                        { name: 'Udayagiri Centre', coord: [12.3203, 76.6398], clients: 310, glp: 5.8, activeLoans: 290, par30: 2.0 },
                        { name: 'Chamarajapuram Centre', coord: [12.3055, 76.6568], clients: 300, glp: 5.6, activeLoans: 280, par30: 2.1 },
                    ]
                },
            ]
        },
    ]
};

// ==================== ANDHRA PRADESH STATE DATA ====================

const andhraData: State = {
    name: 'Andhra Pradesh',
    coord: [15.9129, 79.7400],
    glp: STATES_DATA['andhra'].glp,
    color: '#ec4899',
    districts: [
        {
            name: 'Vijayawada',
            coord: [16.5062, 80.6480],
            glp: 480,
            branches: [
                {
                    name: 'Benz Circle',
                    coord: [16.4997, 80.6561],
                    glp: 30,
                    clients: 1630,
                    centres: [
                        { name: 'Governorpet Centre', coord: [16.4967, 80.6623], clients: 330, glp: 6.1, activeLoans: 310, par30: 2.2 },
                        { name: 'Patamata Centre', coord: [16.4950, 80.6523], clients: 320, glp: 5.8, activeLoans: 300, par30: 2.4 },
                        { name: 'Bhavanipuram Centre', coord: [16.5107, 80.6462], clients: 330, glp: 6.2, activeLoans: 310, par30: 2.1 },
                        { name: 'Machavaram Centre', coord: [16.4914, 80.6684], clients: 320, glp: 5.9, activeLoans: 300, par30: 2.3 },
                        { name: 'Gunadala Centre', coord: [16.5107, 80.6481], clients: 330, glp: 6.0, activeLoans: 310, par30: 2.2 },
                    ]
                },
                {
                    name: 'Gannavaram',
                    coord: [16.5386, 80.7982],
                    glp: 26,
                    clients: 1410,
                    centres: [
                        { name: 'Gannavaram Main', coord: [16.5409, 80.8048], clients: 280, glp: 5.1, activeLoans: 260, par30: 2.5 },
                        { name: 'Nidamanuru Centre', coord: [16.5304, 80.8011], clients: 290, glp: 5.3, activeLoans: 270, par30: 2.3 },
                        { name: 'Kesarapalli Centre', coord: [16.5361, 80.7912], clients: 280, glp: 5.0, activeLoans: 260, par30: 2.6 },
                        { name: 'Mylavaram Centre', coord: [16.5286, 80.7969], clients: 280, glp: 5.2, activeLoans: 260, par30: 2.4 },
                        { name: 'Vissannapeta Centre', coord: [16.5373, 80.7984], clients: 280, glp: 5.4, activeLoans: 260, par30: 2.3 },
                    ]
                },
            ]
        },
        {
            name: 'Visakhapatnam',
            coord: [17.6868, 83.2185],
            glp: 420,
            branches: [
                {
                    name: 'MVP Colony',
                    coord: [17.7414, 83.3387],
                    glp: 28,
                    clients: 1520,
                    centres: [
                        { name: 'MVP Sector 1', coord: [17.7396, 83.3379], clients: 300, glp: 5.5, activeLoans: 280, par30: 2.3 },
                        { name: 'MVP Sector 2', coord: [17.7536, 83.3431], clients: 310, glp: 5.7, activeLoans: 290, par30: 2.2 },
                        { name: 'Gajuwaka Centre', coord: [17.7357, 83.3372], clients: 300, glp: 5.4, activeLoans: 280, par30: 2.4 },
                        { name: 'Pedagantyada Centre', coord: [17.7490, 83.3363], clients: 310, glp: 5.8, activeLoans: 290, par30: 2.2 },
                        { name: 'Madhurawada Centre', coord: [17.7432, 83.3501], clients: 300, glp: 5.6, activeLoans: 280, par30: 2.3 },
                    ]
                },
            ]
        },
    ]
};

// ==================== MADHYA PRADESH STATE DATA ====================

const madhyaPradeshData: State = {
    name: 'Madhya Pradesh',
    coord: [22.9734, 78.6569],
    glp: STATES_DATA['madhyaPradesh'].glp,
    color: '#f59e0b',
    districts: [
        {
            name: 'Indore',
            coord: [22.7196, 75.8577],
            glp: 240,
            branches: [
                {
                    name: 'Rajwada',
                    coord: [22.7184, 75.8552],
                    glp: 25,
                    clients: 1360,
                    centres: [
                        { name: 'Rajwada Main', coord: [22.7265, 75.8469], clients: 270, glp: 4.9, activeLoans: 250, par30: 2.6 },
                        { name: 'Sarafa Bazaar Centre', coord: [22.7075, 75.8666], clients: 280, glp: 5.1, activeLoans: 260, par30: 2.5 },
                        { name: 'Khajuri Bazaar Centre', coord: [22.7099, 75.8442], clients: 270, glp: 4.8, activeLoans: 250, par30: 2.7 },
                        { name: 'Chhawni Centre', coord: [22.7270, 75.8523], clients: 270, glp: 5.0, activeLoans: 250, par30: 2.6 },
                        { name: 'Juni Indore Centre', coord: [22.7199, 75.8660], clients: 270, glp: 5.2, activeLoans: 250, par30: 2.5 },
                    ]
                },
            ]
        },
        {
            name: 'Bhopal',
            coord: [23.2599, 77.4126],
            glp: 200,
            branches: [
                {
                    name: 'MP Nagar',
                    coord: [23.2332, 77.4343],
                    glp: 22,
                    clients: 1195,
                    centres: [
                        { name: 'Zone 1 Centre', coord: [23.2400, 77.4420], clients: 240, glp: 4.4, activeLoans: 220, par30: 2.8 },
                        { name: 'Zone 2 Centre', coord: [23.2231, 77.4270], clients: 240, glp: 4.5, activeLoans: 220, par30: 2.7 },
                        { name: 'Koh-e-Fiza Centre', coord: [23.2264, 77.4261], clients: 235, glp: 4.3, activeLoans: 215, par30: 2.9 },
                        { name: 'Arera Colony Centre', coord: [23.2373, 77.4308], clients: 240, glp: 4.4, activeLoans: 220, par30: 2.8 },
                        { name: 'Shahpura Centre', coord: [23.2396, 77.4347], clients: 240, glp: 4.4, activeLoans: 220, par30: 2.7 },
                    ]
                },
            ]
        },
    ]
};

// ==================== TAMIL NADU STATE DATA ====================

const tamilNaduData: State = {
    name: 'Tamil Nadu',
    coord: [11.1271, 78.6569],
    glp: STATES_DATA['tamilNadu'].glp,
    color: '#10b981',
    districts: [
        {
            name: 'Chennai',
            coord: [13.0827, 80.2707],
            glp: 150,
            branches: [
                {
                    name: 'Royapettah',
                    coord: [13.0539, 80.2641],
                    glp: 20,
                    clients: 1085,
                    centres: [
                        { name: 'Royapettah Main', coord: [13.0526, 80.2573], clients: 220, glp: 4.1, activeLoans: 200, par30: 1.9 },
                        { name: 'Teynampet Centre', coord: [13.0536, 80.2632], clients: 215, glp: 3.9, activeLoans: 195, par30: 2.0 },
                        { name: 'Alwarpet Centre', coord: [13.0631, 80.2715], clients: 220, glp: 4.2, activeLoans: 200, par30: 1.8 },
                        { name: 'Mandaveli Centre', coord: [13.0587, 80.2733], clients: 215, glp: 3.9, activeLoans: 195, par30: 2.0 },
                        { name: 'Mylapore Centre', coord: [13.0415, 80.2740], clients: 215, glp: 3.9, activeLoans: 195, par30: 1.9 },
                    ]
                },
            ]
        },
        {
            name: 'Coimbatore',
            coord: [11.0168, 76.9558],
            glp: 110,
            branches: [
                {
                    name: 'Gandhipuram',
                    coord: [11.0205, 76.9667],
                    glp: 18,
                    clients: 975,
                    centres: [
                        { name: 'Gandhipuram Main', coord: [11.0274, 76.9573], clients: 195, glp: 3.6, activeLoans: 175, par30: 2.0 },
                        { name: 'RS Puram Centre', coord: [11.0304, 76.9765], clients: 195, glp: 3.5, activeLoans: 175, par30: 2.1 },
                        { name: 'Saibaba Colony Centre', coord: [11.0166, 76.9633], clients: 200, glp: 3.7, activeLoans: 180, par30: 1.9 },
                        { name: 'Peelamedu Centre', coord: [11.0111, 76.9592], clients: 190, glp: 3.5, activeLoans: 170, par30: 2.1 },
                        { name: 'Ganapathy Centre', coord: [11.0271, 76.9763], clients: 195, glp: 3.7, activeLoans: 175, par30: 2.0 },
                    ]
                },
            ]
        },
    ]
};

// ==================== EXPORT COMPLETE HIERARCHY ====================

export const ALL_STATES_DATA: State[] = [
    odishaData,
    karnatakaData,
    andhraData,
    madhyaPradeshData,
    tamilNaduData,
];

// ==================== HELPER FUNCTIONS ====================

export const getStateData = (stateName: string): State | undefined => {
    return ALL_STATES_DATA.find(s => s.name === stateName);
};

export const getDistrictData = (stateName: string, districtName: string): District | undefined => {
    const state = getStateData(stateName);
    return state?.districts.find(d => d.name === districtName);
};

export const getBranchData = (stateName: string, districtName: string, branchName: string): Branch | undefined => {
    const district = getDistrictData(stateName, districtName);
    return district?.branches.find(b => b.name === branchName);
};

export const getCentreData = (stateName: string, districtName: string, branchName: string, centreName: string): Centre | undefined => {
    const branch = getBranchData(stateName, districtName, branchName);
    return branch?.centres.find(c => c.name === centreName);
};

// ==================== LEGACY SUPPORT (for existing code) ====================

export const COORDINATES = {
    // Country
    INDIA: [20.5937, 78.9629] as [number, number],

    // States
    ODISHA: odishaData.coord,
    KARNATAKA: karnatakaData.coord,
    ANDHRA: [15.9129, 79.7400] as [number, number],
    MADHYA_PRADESH: [22.9734, 78.6569] as [number, number],
    TAMIL_NADU: [11.1271, 78.6569] as [number, number],

    // Odisha Districts
    ODISHA_KHORDHA: odishaData.districts[0].coord,
    ODISHA_BHUBANESWAR: odishaData.districts[1].coord,
    ODISHA_CUTTACK: odishaData.districts[2].coord,
    ODISHA_PURI: odishaData.districts[3].coord,
    ODISHA_BALASORE: odishaData.districts[4].coord,

    // Karnataka Districts
    KARNATAKA_BANGALORE: karnatakaData.districts[0].coord,
    KARNATAKA_MYSORE: karnatakaData.districts[1].coord,
    KARNATAKA_BELGAUM: [15.8497, 74.4977] as [number, number],
    KARNATAKA_HUBLI: [15.3647, 75.1240] as [number, number],
    KARNATAKA_MANGALORE: [12.9141, 74.8560] as [number, number],

    // Other districts (legacy)
    ANDHRA_VIJAYAWADA: [16.5062, 80.6480] as [number, number],
    ANDHRA_VISAKHAPATNAM: [17.6868, 83.2185] as [number, number],
    ANDHRA_GUNTUR: [16.3067, 80.4365] as [number, number],
    ANDHRA_TIRUPATI: [13.6288, 79.4192] as [number, number],
    ANDHRA_KAKINADA: [16.9891, 82.2475] as [number, number],
    MP_INDORE: [22.7196, 75.8577] as [number, number],
    MP_BHOPAL: [23.2599, 77.4126] as [number, number],
    MP_JABALPUR: [23.1815, 79.9864] as [number, number],
    MP_GWALIOR: [26.2183, 78.1828] as [number, number],
    MP_UJJAIN: [23.1765, 75.7885] as [number, number],
    TN_CHENNAI: [13.0827, 80.2707] as [number, number],
    TN_COIMBATORE: [11.0168, 76.9558] as [number, number],
    TN_MADURAI: [9.9252, 78.1198] as [number, number],
    TN_SALEM: [11.6643, 78.1460] as [number, number],
    TN_TRICHY: [10.7905, 78.7047] as [number, number],
};

export interface GeoHierarchy {
    level: 'Country' | 'State' | 'District' | 'Branch' | 'Centre';
    label: string;
    glp: number;
    branches?: number | string;
    par30: number;
    digitalPercentage: number;
    meetings?: { total: number; within: number };
    writeOff?: number; // Calculated aggregated write-off
}

// ==================== DATA ENRICHMENT (WRITE-OFF ROLLUP) ====================

let TOTAL_WRITEOFF = 0;

const enrichWriteOff = () => {
    let countrySum = 0;
    ALL_STATES_DATA.forEach(state => {
        let stateWriteOff = 0;
        state.districts.forEach(district => {
            let districtWriteOff = 0;
            district.branches.forEach(branch => {
                let branchWriteOff = 0;
                branch.centres.forEach(centre => {
                    // Generate random write-off if missing (0.01 - 0.1 Lakhs per centre)
                    if (centre.writeOff === undefined) {
                        centre.writeOff = parseFloat((Math.random() * 0.09 + 0.01).toFixed(3));
                    }
                    branchWriteOff += centre.writeOff;
                });
                // Branch writeOff: Convert Sum of Lakhs to Crores
                branch.writeOff = parseFloat((branchWriteOff / 100).toFixed(4));
                districtWriteOff += branch.writeOff;
            });
            district.writeOff = parseFloat(districtWriteOff.toFixed(4));
            stateWriteOff += district.writeOff;
        });
        state.writeOff = parseFloat(stateWriteOff.toFixed(4));
        countrySum += state.writeOff;
    });
    TOTAL_WRITEOFF = parseFloat(countrySum.toFixed(4));
};

// Execute enrichment immediately
enrichWriteOff();

export const getGeoStats = (level: string, parent?: string, label?: string): GeoHierarchy => {
    if (level === 'Country') {
        return {
            level: 'Country',
            label: 'India',
            glp: COMPANY_METRICS.currentGLP, // Link to Central Math
            branches: 3520,
            par30: COMPANY_METRICS.parOver30, // Link to Central Math
            digitalPercentage: 65,
            meetings: { total: 4500, within: 4100 },
            writeOff: TOTAL_WRITEOFF, // Rolled up from centres
        };
    }

    if (level === 'State') {
        // Map label to key dynamically
        let key = (label || 'Odisha').toLowerCase().replace(/\s/g, '');
        if (key === 'andhrapradesh') key = 'andhra';
        if (key === 'madhyapradesh') key = 'madhyaPradesh';
        if (key === 'tamilnadu') key = 'tamilNadu';

        const data = ALL_STATES_DATA.find(s => s.name === label) || STATES_DATA['odisha'];
        // Fallback for logic if ALL_STATES_DATA find fails (which relies on exact label match)
        // Use the proper State data if found, else fallback to generic mfiData metrics but we prefer the enriched one
        const enrichedState = ALL_STATES_DATA.find(s => s.name === (label || 'Odisha'));

        return {
            level: 'State',
            label: label || 'Odisha',
            glp: enrichedState ? enrichedState.glp : data.glp,
            branches: enrichedState ? enrichedState.districts.reduce((sum, d) => sum + d.branches.length, 0) : data.branches,
            par30: data.par30, // Keep PAR from mfiData as it is time-series accurate
            digitalPercentage: 65,
            meetings: { total: 1200, within: 1120 },
            writeOff: enrichedState ? enrichedState.writeOff : 0,
        };
    }

    // For other levels, return sensible defaults
    return {
        level: 'Country',
        label: 'India',
        glp: 8500,
        branches: 3520,
        par30: 3.2,
        digitalPercentage: 65,
        meetings: { total: 4500, within: 4100 },
        writeOff: TOTAL_WRITEOFF
    };
};
