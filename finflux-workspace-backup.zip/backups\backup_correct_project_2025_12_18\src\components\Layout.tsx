import { useNavigate, useLocation, Outlet, NavLink } from 'react-router-dom';
import { LayoutDashboard, Map, TrendingUp, LogOut, Menu, Building2, PieChart, Package, FileText, Users, ShieldAlert } from 'lucide-react';
import { cn } from '../lib/utils';
import { useState, useRef, useEffect } from 'react';

const Layout = () => {
    // Default open on desktop, closed on mobile? 
    // We'll trust the user to toggle, but defaulting to true is fine for desktop.
    const [sidebarOpen, setSidebarOpen] = useState(true);
    const [isMobile, setIsMobile] = useState(window.innerWidth < 768);
    const navigate = useNavigate();
    const location = useLocation();

    // Handle Resize
    useEffect(() => { // Changed from useState to useEffect for side effect
        const handleResize = () => setIsMobile(window.innerWidth < 768);
        window.addEventListener('resize', handleResize);
        return () => window.removeEventListener('resize', handleResize);
    }, []); // Empty dependency array to run once on mount

    // Scroll To Top Logic
    const scrollRef = useRef<HTMLDivElement>(null);
    useEffect(() => {
        if (scrollRef.current) {
            scrollRef.current.scrollTo(0, 0);
        }
    }, [location.pathname]);

    const navItems = [
        { path: '/home', icon: LayoutDashboard, label: 'Executive Dashboard' },
        { path: '/branch', icon: Building2, label: 'Branch View' },
        { path: '/centre', icon: Users, label: 'Centre & Workforce' },
        { path: '/portfolio', icon: PieChart, label: 'Portfolio Quality' },
        { path: '/origination', icon: FileText, label: 'Loans Origination' },
        { path: '/products', icon: Package, label: 'Product Analytics' },
        { path: '/trends', icon: TrendingUp, label: 'Trends' },
        { path: '/geo', icon: Map, label: 'Geo Drill' },
        { path: '/audit', icon: ShieldAlert, label: 'Audit & Risk Control' },
    ];

    return (
        <div className="flex h-screen bg-secondary-50 text-secondary-900 overflow-hidden relative">

            {/* Mobile Overlay */}
            {isMobile && sidebarOpen && (
                <div
                    className="fixed inset-0 bg-black/50 z-30 transition-opacity"
                    onClick={() => setSidebarOpen(false)}
                />
            )}

            {/* Sidebar */}
            <aside
                className={cn(
                    "bg-white border-r border-secondary-200 transition-all duration-300 flex flex-col z-40",
                    isMobile ? "fixed inset-y-0 left-0 h-full shadow-xl" : "relative",
                    sidebarOpen ? "w-64" : (isMobile ? "w-0 -translate-x-full" : "w-20"), // On mobile: 0 width/translate if closed
                    isMobile && !sidebarOpen && "-translate-x-full" // Extra safety for mobile hide
                )}
            >
                <div className="p-4 border-b border-secondary-200 flex items-center justify-between h-16 shrink-0">
                    {sidebarOpen ? (
                        <div className="font-bold text-xl text-primary-600 tracking-tight">FINFLUX</div>
                    ) : (
                        <div className="text-xl font-bold text-primary-600 mx-auto">F</div>
                    )}

                    {/* Only show toggle on desktop or if open on mobile */}
                    <button onClick={() => setSidebarOpen(!sidebarOpen)} className="p-1 hover:bg-secondary-100 rounded-md text-secondary-500">
                        <Menu size={20} />
                    </button>
                </div>

                <nav className="flex-1 p-4 space-y-2 overflow-y-auto">
                    {navItems.map((item) => (
                        <NavLink
                            key={item.path}
                            to={item.path}
                            onClick={() => isMobile && setSidebarOpen(false)} // Auto-close on mobile
                            className={({ isActive }) => cn(
                                "flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all duration-200 group whitespace-nowrap",
                                isActive
                                    ? "bg-primary-50 text-primary-700 shadow-sm ring-1 ring-primary-200/50"
                                    : "text-secondary-600 hover:bg-secondary-100 hover:text-secondary-900"
                            )}
                        >
                            <item.icon size={22} className={cn("shrink-0 transition-colors", location.pathname === item.path ? "text-primary-600" : "text-secondary-400 group-hover:text-secondary-600")} />
                            {sidebarOpen && <span className="font-medium">{item.label}</span>}
                        </NavLink>
                    ))}
                </nav>
            </aside>

            {/* Main Content */}
            <main className="flex-1 flex flex-col min-w-0 overflow-hidden">
                {/* Header */}
                <header className="h-16 bg-white border-b border-secondary-200 flex items-center justify-between px-4 sm:px-6 shrink-0 gap-4">
                    <div className="flex items-center gap-3">
                        {/* Mobile Menu Button (Visible only when sidebar closed on mobile) */}
                        {isMobile && !sidebarOpen && (
                            <button onClick={() => setSidebarOpen(true)} className="p-2 -ml-2 text-secondary-600 hover:bg-secondary-100 rounded-lg">
                                <Menu size={20} />
                            </button>
                        )}
                        <h1 className="text-lg font-semibold text-secondary-800 truncate">
                            {navItems.find(i => i.path === location.pathname)?.label || 'Dashboard'}
                        </h1>
                    </div>

                    <div className="flex items-center gap-4">
                        <div className="text-sm text-right hidden sm:block">
                            <div className="font-medium text-secondary-900">Sriram (Admin)</div>
                            <div className="text-xs text-secondary-500">Head Office</div>
                        </div>
                        <div className="w-8 h-8 sm:w-9 sm:h-9 bg-primary-100 text-primary-700 rounded-full flex items-center justify-center font-bold text-sm">
                            SR
                        </div>
                    </div>
                </header>

                {/* Content Scroll Area */}
                <div ref={scrollRef} className="flex-1 overflow-auto p-4 sm:p-6 scroll-smooth">
                    <Outlet />
                </div>
            </main>
        </div>
    );
};

export default Layout;
