import { Suspense, lazy } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import Layout from './components/Layout';


// Lazy load dashboard pages to reduce initial bundle size
const HomeDashboard = lazy(() => import('./pages/HomeDashboard'));
const GeoDashboard = lazy(() => import('./pages/GeoDashboard'));
const TrendsDashboard = lazy(() => import('./pages/TrendsDashboard'));
const BranchDashboard = lazy(() => import('./pages/BranchDashboard'));
const PortfolioDashboard = lazy(() => import('./pages/PortfolioDashboard'));
const ProductDashboard = lazy(() => import('./pages/ProductDashboard'));
const OriginationDashboard = lazy(() => import('./pages/OriginationDashboard'));
const AuditDashboard = lazy(() => import('./pages/AuditDashboard'));
const CentreDashboard = lazy(() => import('./pages/CentreDashboard'));

// Simple Loading Component
const LoadingFallback = () => (
    <div className="flex items-center justify-center h-screen bg-slate-50">
        <div className="flex flex-col items-center gap-4">
            <div className="w-12 h-12 border-4 border-primary-200 border-t-primary-600 rounded-full animate-spin"></div>
            <span className="text-secondary-500 font-medium">Loading Dashboard...</span>
        </div>
    </div>
);

function App() {
    return (
        <BrowserRouter>
            <Suspense fallback={<LoadingFallback />}>
                <Routes>

                    <Route path="/" element={<Layout />}>
                        <Route index element={<Navigate to="/home" replace />} />
                        <Route path="home" element={<HomeDashboard />} />
                        <Route path="geo" element={<GeoDashboard />} />
                        <Route path="trends" element={<TrendsDashboard />} />
                        <Route path="branch" element={<BranchDashboard />} />
                        <Route path="products" element={<ProductDashboard />} />
                        <Route path="portfolio" element={<PortfolioDashboard />} />
                        <Route path="origination" element={<OriginationDashboard />} />
                        <Route path="audit" element={<AuditDashboard />} />
                        <Route path="centre" element={<CentreDashboard />} />
                    </Route>
                </Routes>
            </Suspense>
        </BrowserRouter>
    );
}

export default App;
