const fs = require('fs');
const path = require('path');
const dir = path.join(__dirname, 'src', 'pages');

const files = fs.readdirSync(dir).filter(f => f.endsWith('Dashboard.tsx') && f !== 'GeoDashboard.tsx');
files.forEach(file => {
    let content = fs.readFileSync(path.join(dir, file), 'utf8');

    if (file === 'HomeDashboard.tsx') {
        const homeRegexPdf = /const handleExportPDF = async \(\) => \{[\s\S]*?if \(pdf\) saveFile\(pdf\.output\('blob'\), getFilename\('pdf'\)\);\s*\} catch \(e\) \{/g;
        const newHomePdf = `const handleExportPDF = async () => {
        if (!slide1Ref.current || !slide2Ref.current) return;
        try {
            const { jsPDF } = await import('jspdf');

            let pdf: any = null;

            for (let i = 0; i < 2; i++) {
                const canvas = await captureSlide(i === 0 ? slide1Ref : slide2Ref);
                const imgData = canvas.toDataURL('image/jpeg', 1.0);

                if (i === 0) {
                    pdf = new jsPDF({
                        orientation: canvas.width > canvas.height ? 'landscape' : 'portrait',
                        unit: 'px',
                        format: [canvas.width, canvas.height]
                    });
                    pdf.addImage(imgData, 'JPEG', 0, 0, canvas.width, canvas.height);
                } else {
                    pdf!.addPage([canvas.width, canvas.height], canvas.width > canvas.height ? 'landscape' : 'portrait');
                    pdf!.setPage(i + 1);
                    pdf!.addImage(imgData, 'JPEG', 0, 0, canvas.width, canvas.height);
                }
            }

            if (pdf) saveFile(pdf.output('blob'), getFilename('pdf'));
        } catch (e) {`;

        content = content.replace(homeRegexPdf, newHomePdf);

        const homeRegexPpt = /const handleExportPPT = async \(\) => \{[\s\S]*?const blob = \(await pptx\.write\('blob' as any\)\) as Blob;\s*saveFile\(blob, getFilename\('pptx'\)\);\s*\} catch \(e\) \{/g;
        const newHomePpt = `const handleExportPPT = async () => {
        if (!slide1Ref.current || !slide2Ref.current) return;
        try {
            const pptxgen = (await import('pptxgenjs')).default;
            const pptx = new pptxgen();
            pptx.layout = 'LAYOUT_16x9';

            for (let i = 0; i < 2; i++) {
                const canvas = await captureSlide(i === 0 ? slide1Ref : slide2Ref);
                const imgData = canvas.toDataURL('image/jpeg', 1.0);
                const slide = pptx.addSlide();
                slide.addImage({ data: imgData, x: 0, y: 0, w: '100%', h: '100%', sizing: { type: 'contain', w: '100%', h: '100%' } });
            }

            const blob = (await pptx.write('blob' as any)) as Blob;
            saveFile(blob, getFilename('pptx'));
        } catch (e) {`;

        content = content.replace(homeRegexPpt, newHomePpt);

    } else {
        const pdfRegex = /const handleExportPDF = async \(\) => \{[\s\S]*?saveFile\(.*?pdf.*?getFilename\('pdf'\)\);\s*\} catch \(e\) \{/g;
        const newPdf = `const handleExportPDF = async () => {
        if (!exportRef.current) return;
        try {
            const { jsPDF } = await import('jspdf');
            const canvas = await captureSlide(exportRef);
            const imgData = canvas.toDataURL('image/jpeg', 1.0);
            const pdf = new jsPDF({ orientation: canvas.width > canvas.height ? 'landscape' : 'portrait', unit: 'px', format: [canvas.width, canvas.height] });
            pdf.addImage(imgData, 'JPEG', 0, 0, canvas.width, canvas.height);
            saveFile(pdf.output('blob'), getFilename('pdf'));
        } catch (e) {`;

        content = content.replace(pdfRegex, newPdf);

        const pptRegex = /const handleExportPPT = async \(\) => \{[\s\S]*?const blob = \(await pptx\.write\('blob' as any\)\) as Blob;\s*saveFile\(blob, getFilename\('pptx'\)\);\s*\} catch \(e\) \{/g;
        const newPpt = `const handleExportPPT = async () => {
        if (!exportRef.current) return;
        try {
            const pptxgen = (await import('pptxgenjs')).default;
            const pptx = new pptxgen();
            pptx.layout = 'LAYOUT_16x9';
            const canvas = await captureSlide(exportRef);
            
            if (canvas.height > 1200) {
                const slices = sliceCanvas(canvas, Math.ceil(canvas.height / 2));
                slices.forEach((slice) => {
                    const slide = pptx.addSlide();
                    slide.addImage({ data: slice.data, x: 0, y: 0, w: '100%', h: '100%', sizing: { type: 'contain', w: '100%', h: '100%' } });
                });
            } else {
                const imgData = canvas.toDataURL('image/jpeg', 1.0);
                const slide = pptx.addSlide();
                slide.addImage({ data: imgData, x: 0, y: 0, w: '100%', h: '100%', sizing: { type: 'contain', w: '100%', h: '100%' } });
            }

            const blob = (await pptx.write('blob' as any)) as Blob;
            saveFile(blob, getFilename('pptx'));
        } catch (e) {`;

        content = content.replace(pptRegex, newPpt);
    }

    fs.writeFileSync(path.join(dir, file), content, 'utf8');
    console.log("Updated", file);
});
