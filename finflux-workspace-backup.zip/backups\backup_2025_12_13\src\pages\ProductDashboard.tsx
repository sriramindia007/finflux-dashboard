import React, { useState } from 'react';
import { Package, Users, Leaf, Heart, Sun, Droplet, ArrowUpRight, Filter } from 'lucide-react';
import KPICard from '../components/KPICard';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { COMPANY_METRICS, PRODUCTS_LIST } from '../data/mfiData';

const ProductDashboard = () => {
    // Mock Product Performance Data
    const productPerformance = [
        { name: 'Group Loans', category: 'Microfinance', ticketSize: 35000, glpShare: 64, growth: 12 },
        { name: 'MSME Business', category: 'MSME', ticketSize: 150000, glpShare: 15, growth: 25 },
        { name: 'Housing Loan', category: 'Housing', ticketSize: 450000, glpShare: 12, growth: 18 },
        { name: 'SWASTH (Water)', category: 'Development', ticketSize: 25000, glpShare: 4, growth: 8 },
        { name: 'Samarth', category: 'Special', ticketSize: 20000, glpShare: 2, growth: 15 },
        { name: 'Dairy Dev', category: 'Agriculture', ticketSize: 40000, glpShare: 3, growth: 10 },
    ];

    const demographicsData = [
        { name: 'General', value: COMPANY_METRICS.demographics.general, color: '#6366f1' },
        { name: 'SC/ST', value: COMPANY_METRICS.demographics.scSt, color: '#8b5cf6' },
        { name: 'Minority', value: COMPANY_METRICS.demographics.minority, color: '#f43f5e' },
    ];

    const portfolioMix = [
        { name: 'Secured (MSME/Housing)', value: COMPANY_METRICS.securedSplit.secured, color: '#10b981' },
        { name: 'Unsecured (MFI/JLG)', value: COMPANY_METRICS.securedSplit.unsecured, color: '#3b82f6' },
    ];

    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                <div>
                    <h1 className="text-2xl font-bold text-secondary-900">Products & Impact</h1>
                    <p className="text-secondary-500">Portfolio segmentation and social outreach analytics</p>
                </div>
                <button className="bg-white border border-secondary-300 px-4 py-2 rounded-lg text-secondary-700 font-medium hover:bg-secondary-50 flex items-center gap-2">
                    <Filter size={16} /> Filter View
                </button>
            </div>

            {/* Top KPIs */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <KPICard title="Product Types" value={PRODUCTS_LIST.length.toString()} icon={Package} trend="neutral" trendValue="Diverse Portfolio" />
                <KPICard title="Avg Ticket Size" value="₹38,500" icon={ArrowUpRight} trend="up" trendValue="8% YoY" />
                <KPICard title="Impact Lives" value={(COMPANY_METRICS.impactStats.swasth + COMPANY_METRICS.impactStats.samarth).toLocaleString()} icon={Heart} className="text-rose-600" />
                <KPICard title="Green Units" value={COMPANY_METRICS.impactStats.solar.toLocaleString()} icon={Leaf} className="text-emerald-600" />
            </div>

            {/* Charts Row */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Mix */}
                <div className="bg-white p-6 rounded-xl border border-secondary-200 shadow-sm">
                    <h3 className="text-lg font-semibold text-secondary-800 mb-4">Portfolio Product Mix</h3>
                    <div className="h-72 flex items-center justify-center">
                        <ResponsiveContainer width="100%" height="100%">
                            <PieChart>
                                <Pie
                                    data={productPerformance}
                                    dataKey="glpShare"
                                    nameKey="name"
                                    cx="50%"
                                    cy="50%"
                                    innerRadius={60}
                                    outerRadius={100}
                                    paddingAngle={5}
                                >
                                    {productPerformance.map((entry, index) => (
                                        <Cell key={`cell-${index}`} fill={['#3b82f6', '#10b981', '#f59e0b', '#ec4899', '#8b5cf6', '#06b6d4'][index % 6]} />
                                    ))}
                                </Pie>
                                <Tooltip formatter={(val) => `${val}%`} />
                                <Legend layout="vertical" align="right" verticalAlign="middle" />
                            </PieChart>
                        </ResponsiveContainer>
                    </div>
                </div>

                {/* Demographics */}
                <div className="bg-white p-6 rounded-xl border border-secondary-200 shadow-sm">
                    <h3 className="text-lg font-semibold text-secondary-800 mb-4">Borrower Demographics</h3>
                    <div className="h-72">
                        <ResponsiveContainer width="100%" height="100%">
                            <BarChart data={demographicsData} layout="vertical" margin={{ left: 20 }}>
                                <CartesianGrid strokeDasharray="3 3" horizontal={false} />
                                <XAxis type="number" hide />
                                <YAxis dataKey="name" type="category" width={80} tick={{ fontSize: 12 }} />
                                <Tooltip cursor={{ fill: 'transparent' }} />
                                <Bar dataKey="value" radius={[0, 4, 4, 0]} barSize={40}>
                                    {demographicsData.map((entry, index) => (
                                        <Cell key={`cell-${index}`} fill={entry.color} />
                                    ))}
                                </Bar>
                            </BarChart>
                        </ResponsiveContainer>
                    </div>
                    <div className="grid grid-cols-3 gap-2 mt-4 text-center border-t pt-4 border-secondary-100">
                        {demographicsData.map((item) => (
                            <div key={item.name}>
                                <div className="text-lg font-bold" style={{ color: item.color }}>{item.value}%</div>
                                <div className="text-xs text-secondary-500">{item.name}</div>
                            </div>
                        ))}
                    </div>
                </div>
            </div>

            {/* Detailed Performance Table */}
            <div className="bg-white rounded-xl border border-secondary-200 shadow-sm overflow-hidden">
                <div className="p-6 border-b border-secondary-200 bg-secondary-50">
                    <h3 className="font-bold text-secondary-900">Product Performance Matrix</h3>
                </div>
                <div className="overflow-x-auto">
                    <table className="w-full text-left text-sm">
                        <thead className="bg-secondary-100 text-secondary-600 font-semibold border-b border-secondary-200">
                            <tr>
                                <th className="px-6 py-4">Product Name</th>
                                <th className="px-6 py-4">Category</th>
                                <th className="px-6 py-4 text-right">Avg Ticket Size</th>
                                <th className="px-6 py-4 text-right">Portfolio Share</th>
                                <th className="px-6 py-4 text-right">YoY Growth</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-secondary-100">
                            {productPerformance.map((product, idx) => (
                                <tr key={idx} className="hover:bg-secondary-50 transition-colors">
                                    <td className="px-6 py-4 font-medium text-secondary-900">{product.name}</td>
                                    <td className="px-6 py-4">
                                        <span className={`px-2 py-1 rounded text-xs font-semibold ${product.category === 'Development' ? 'bg-rose-100 text-rose-700' :
                                                product.category === 'MSME' ? 'bg-emerald-100 text-emerald-700' :
                                                    'bg-blue-100 text-blue-700'
                                            }`}>
                                            {product.category}
                                        </span>
                                    </td>
                                    <td className="px-6 py-4 text-right">₹{product.ticketSize.toLocaleString()}</td>
                                    <td className="px-6 py-4 text-right font-medium">{product.glpShare}%</td>
                                    <td className="px-6 py-4 text-right text-emerald-600 font-bold">+{product.growth}%</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>

            {/* Impact Highlights */}
            <h3 className="text-lg font-semibold text-secondary-800 pt-4">Strategic Impact Initiatives</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-gradient-to-br from-cyan-500 to-blue-600 rounded-xl p-6 text-white shadow-lg relative overflow-hidden">
                    <div className="relative z-10">
                        <div className="flex items-center gap-2 mb-2">
                            <Droplet className="text-white/80" />
                            <span className="font-bold opacity-90">SWASTH (WASH)</span>
                        </div>
                        <div className="text-3xl font-bold mb-1">{COMPANY_METRICS.impactStats.swasth.toLocaleString()}</div>
                        <div className="text-sm opacity-80">Sanitation Facilities Financed</div>
                    </div>
                </div>
                <div className="bg-gradient-to-br from-fuchsia-500 to-purple-600 rounded-xl p-6 text-white shadow-lg relative overflow-hidden">
                    <div className="relative z-10">
                        <div className="flex items-center gap-2 mb-2">
                            <Heart className="text-white/80" />
                            <span className="font-bold opacity-90">Samarth (Inclusion)</span>
                        </div>
                        <div className="text-3xl font-bold mb-1">{COMPANY_METRICS.impactStats.samarth.toLocaleString()}</div>
                        <div className="text-sm opacity-80">Differently-abled Beneficiaries</div>
                    </div>
                </div>
                <div className="bg-gradient-to-br from-amber-400 to-orange-500 rounded-xl p-6 text-white shadow-lg relative overflow-hidden">
                    <div className="relative z-10">
                        <div className="flex items-center gap-2 mb-2">
                            <Sun className="text-white/80" />
                            <span className="font-bold opacity-90">Green Energy</span>
                        </div>
                        <div className="text-3xl font-bold mb-1">{COMPANY_METRICS.impactStats.solar.toLocaleString()}</div>
                        <div className="text-sm opacity-80">Solar Units Installed</div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default ProductDashboard;
