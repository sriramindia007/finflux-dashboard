import React, { useState } from 'react';
import { AlertTriangle, TrendingDown, CheckCircle, Smartphone, Wallet, Building2, Landmark, PieChart as PieIcon, ShieldAlert } from 'lucide-react';
import KPICard from '../components/KPICard';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { COMPANY_METRICS, STATES_DATA } from '../data/mfiData';

// Mock trend data for charts
const portfolioTrend = [
    { month: 'Jul', par30: 2.1, par90: 0.8, writeOff: 0.1 },
    { month: 'Aug', par30: 2.2, par90: 0.9, writeOff: 0.1 },
    { month: 'Sep', par30: 2.3, par90: 1.0, writeOff: 0.2 },
    { month: 'Oct', par30: 2.4, par90: 1.1, writeOff: 0.2 },
    { month: 'Nov', par30: 2.5, par90: 1.2, writeOff: 0.3 },
    { month: 'Dec', par30: 2.1, par90: 1.3, writeOff: 0.4 }, // Sharp improvement in PAR30
];

const PortfolioQualityDashboard = () => {
    const [selectedState, setSelectedState] = useState('All States');

    const fundingData = [
        { name: 'Public Banks', value: COMPANY_METRICS.fundingProfile.publicBanks, color: '#3b82f6' },
        { name: 'Private Banks', value: COMPANY_METRICS.fundingProfile.privateBanks, color: '#10b981' },
        { name: 'NBFCs', value: COMPANY_METRICS.fundingProfile.nbfcs, color: '#f59e0b' },
        { name: 'Other Sources', value: COMPANY_METRICS.fundingProfile.others, color: '#64748b' },
    ];

    const collectionEffData = [
        { name: 'Current', value: 98.5, target: 99 },
        { name: '1-30 Days', value: 85.0, target: 90 },
        { name: '31-60 Days', value: 65.0, target: 75 },
        { name: '61-90 Days', value: 45.0, target: 50 },
        { name: 'MSME', value: COMPANY_METRICS.collectionEfficiencyMsme, target: 95 }, // Added MSME
    ];

    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                <div>
                    <h1 className="text-2xl font-bold text-secondary-900">Portfolio Quality (Risk Radar)</h1>
                    <p className="text-secondary-500">Credit risk, concentration, and asset health</p>
                </div>
                <div className="flex gap-2">
                    <select
                        value={selectedState}
                        onChange={(e) => setSelectedState(e.target.value)}
                        className="bg-white border border-secondary-300 rounded-lg px-3 py-2 text-sm text-secondary-700 outline-none focus:ring-2 focus:ring-primary-500"
                    >
                        <option>All States</option>
                        {Object.values(STATES_DATA).map(state => (
                            <option key={state.name}>{state.name}</option>
                        ))}
                    </select>
                    <button className="bg-white border border-secondary-300 rounded-lg px-3 py-2 text-sm text-secondary-700 hover:bg-secondary-50">
                        Export Report
                    </button>
                </div>
            </div>

            {/* KPI Cards including Risk Radar metrics */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <KPICard
                    title="Portfolio at Risk (>30)"
                    value={`${COMPANY_METRICS.parOver30}%`}
                    trend="down"
                    trendValue="0.4%"
                    icon={AlertTriangle}
                    className="border-l-4 border-l-amber-500"
                />
                <KPICard
                    title="Concentration Risk (Top 3)"
                    value={`${COMPANY_METRICS.concentrationShare}%`}
                    trend="neutral"
                    trendValue="Threshold > 50%"
                    icon={ShieldAlert}
                    className="border-l-4 border-l-rose-500"
                />
                <KPICard
                    title="Gross NPA (Mar '25)"
                    value={`${COMPANY_METRICS.gnpa}%`}
                    trend="up"
                    trendValue="Improved from 2.9%"
                    icon={TrendingDown}
                />
                <KPICard
                    title="Collection Efficiency"
                    value="96.5%"
                    subValue={`Digital: ${COMPANY_METRICS.digitalAdoption}%`}
                    trend="neutral"
                    trendValue="Stable"
                    icon={Smartphone}
                />
            </div>

            {/* Main Charts Row */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2 bg-white p-6 rounded-xl border border-secondary-200 shadow-sm">
                    <h3 className="text-lg font-semibold text-secondary-800 mb-4">PAR Trend Analysis</h3>
                    <div className="h-72">
                        <ResponsiveContainer width="100%" height="100%">
                            <LineChart data={portfolioTrend}>
                                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                                <XAxis dataKey="month" />
                                <YAxis />
                                <Tooltip />
                                <Legend />
                                <Line type="monotone" dataKey="par30" stroke="#f59e0b" strokeWidth={3} name="PAR > 30" />
                                <Line type="monotone" dataKey="par90" stroke="#ef4444" strokeWidth={3} name="PAR > 90" />
                                <Line type="monotone" dataKey="writeOff" stroke="#64748b" strokeWidth={2} strokeDasharray="5 5" name="Write-off" />
                            </LineChart>
                        </ResponsiveContainer>
                    </div>
                </div>

                <div className="bg-white p-6 rounded-xl border border-secondary-200 shadow-sm">
                    <h3 className="text-lg font-semibold text-secondary-800 mb-4">State-wise PAR Comparison</h3>
                    <div className="h-72">
                        <ResponsiveContainer width="100%" height="100%">
                            <BarChart data={Object.values(STATES_DATA)} layout="vertical" margin={{ left: 20 }}>
                                <CartesianGrid strokeDasharray="3 3" horizontal={false} />
                                <XAxis type="number" hide />
                                <YAxis dataKey="name" type="category" width={80} tick={{ fontSize: 10 }} />
                                <Tooltip />
                                <Bar dataKey="par30" name="PAR %" radius={[0, 4, 4, 0]}>
                                    {Object.values(STATES_DATA).map((entry, index) => (
                                        <Cell key={`cell-${index}`} fill={entry.par30 > 2.5 ? '#ef4444' : '#10b981'} />
                                    ))}
                                </Bar>
                            </BarChart>
                        </ResponsiveContainer>
                    </div>
                </div>
            </div>

            {/* Lower Charts Row: Funding & Collection */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">

                {/* Funding Profile */}
                <div className="bg-white p-6 rounded-xl border border-secondary-200 shadow-sm">
                    <h3 className="text-lg font-semibold text-secondary-800 mb-4 flex items-center gap-2">
                        <Landmark size={20} className="text-primary-600" /> Funding Profile
                    </h3>
                    <div className="h-64 relative">
                        <ResponsiveContainer width="100%" height="100%">
                            <PieChart>
                                <Pie
                                    data={fundingData}
                                    cx="50%"
                                    cy="50%"
                                    innerRadius={60}
                                    outerRadius={80}
                                    paddingAngle={5}
                                    dataKey="value"
                                >
                                    {fundingData.map((entry, index) => (
                                        <Cell key={`cell-${index}`} fill={entry.color} />
                                    ))}
                                </Pie>
                                <Tooltip formatter={(val) => `${val}%`} />
                                <Legend layout="vertical" align="right" verticalAlign="middle" />
                            </PieChart>
                        </ResponsiveContainer>
                        <div className="absolute inset-0 flex items-center justify-center pointer-events-none pr-20">
                            <div className="text-center">
                                <div className="text-sm text-secondary-500">Debt Mix</div>
                                <div className="text-xl font-bold text-secondary-900">100%</div>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Collection Efficiency Breakdown */}
                <div className="lg:col-span-2 bg-white p-6 rounded-xl border border-secondary-200 shadow-sm">
                    <h3 className="text-lg font-semibold text-secondary-800 mb-4">Collection Efficiency by Bucket</h3>
                    <div className="h-64">
                        <ResponsiveContainer width="100%" height="100%">
                            <BarChart data={collectionEffData}>
                                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                                <XAxis dataKey="name" />
                                <YAxis domain={[0, 100]} />
                                <Tooltip cursor={{ fill: 'transparent' }} />
                                <Legend />
                                <Bar dataKey="value" fill="#10b981" name="Actual %" radius={[4, 4, 0, 0]} barSize={40} />
                                <Bar dataKey="target" fill="#e2e8f0" name="Target %" radius={[4, 4, 0, 0]} barSize={40} />
                            </BarChart>
                        </ResponsiveContainer>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default PortfolioQualityDashboard;
