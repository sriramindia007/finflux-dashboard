import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell, AreaChart, Area } from 'recharts';
import { AlertTriangle, TrendingDown, ShieldAlert, BadgePercent, AlertCircle, ArrowUpRight, ArrowDownRight } from 'lucide-react';
import { COMPANY_METRICS, STATES_DATA, COMPANY_HISTORY } from '../data/mfiData';

// Trend data adjusted to end at current company metrics (PAR ~3.2%)
const portfolioTrendData = COMPANY_HISTORY.slice(-6).map(m => ({ // Last 6 months
    month: m.month,
    par30: m.par30,
    par90: m.par90,
    npa: m.par90, // Assuming NPA tracks with PAR90 for this view
    collectionEff: (m.collection / m.collectionDue * 100)
}));

const riskBuckets = [
    { name: 'Regular', value: 92.5, color: '#10b981' }, // 100 - (3.2 + 4.3ish)
    { name: 'SMA 0 (1-30)', value: 4.3, color: '#f59e0b' },
    { name: 'SMA 1 (31-60)', value: 2.0, color: '#f97316' },
    { name: 'SMA 2 (61-90)', value: 0.4, color: '#ef4444' },
    { name: 'NPA (90+)', value: 0.8, color: '#7f1d1d' }, // Matches assumed GNPA
];

// Transform STATES_DATA into array for table
const stateWiseRisk = Object.values(STATES_DATA).map(state => ({
    state: state.name,
    par: state.par30,
    glp: state.glp,
    risk: state.par30 > 3.5 ? 'Critical' : state.par30 > 3.0 ? 'High' : state.par30 > 2.5 ? 'Medium' : 'Low'
})).sort((a, b) => b.par - a.par); // Sort by risk (high to low)

const PortfolioDashboard = () => {
    // Calculate real-time efficiencies
    const mtdEfficiency = (COMPANY_METRICS.mtdCollection / COMPANY_METRICS.mtdCollectionDue * 100).toFixed(1);
    const writeOffVal = COMPANY_METRICS.ytdWriteoff;

    return (
        <div className="space-y-6">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                    <h2 className="text-2xl font-bold text-secondary-900">Portfolio Quality</h2>
                    <p className="text-secondary-500">Risk monitoring and asset quality analysis (Real-time)</p>
                </div>
                <div className="flex items-center gap-3">
                    <span className="text-sm font-medium text-secondary-600">As of:</span>
                    <select className="bg-white border border-secondary-300 rounded-lg px-3 py-2 text-sm text-secondary-700 font-medium shadow-sm">
                        <option>Dec 2025</option>
                        <option>Nov 2025</option>
                    </select>
                </div>
            </div>

            {/* Top Level Risk Metrics - Synced with mfiData.ts */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                {[
                    { title: 'Portfolio at Risk (PAR 30+)', value: `${COMPANY_METRICS.parOver30}%`, change: '+0.3%', trend: 'up', icon: AlertTriangle, color: 'text-amber-600', bg: 'bg-amber-50' },
                    { title: 'GNPA (90+)', value: '0.8%', change: '+0.1%', trend: 'up', icon: ShieldAlert, color: 'text-rose-600', bg: 'bg-rose-50' },
                    { title: 'Collection Efficiency', value: `${mtdEfficiency}%`, change: '-0.3%', trend: 'down', icon: BadgePercent, color: 'text-blue-600', bg: 'bg-blue-50' },
                    { title: 'Write-offs (YTD)', value: `₹${writeOffVal} Cr`, change: '0%', trend: 'flat', icon: TrendingDown, color: 'text-slate-600', bg: 'bg-slate-50' },
                ].map((metric, idx) => (
                    <div key={idx} className="bg-white p-5 rounded-xl border border-secondary-200 shadow-sm hover:shadow-md transition-shadow">
                        <div className="flex justify-between items-start mb-4">
                            <div className={`p-2.5 rounded-lg ${metric.bg} ${metric.color}`}>
                                <metric.icon size={20} />
                            </div>
                            <div className={`flex items-center text-xs font-bold px-2 py-1 rounded-full ${metric.trend === 'down' && metric.title.includes('Efficiency') ? 'bg-rose-100 text-rose-700' :
                                metric.trend === 'up' && !metric.title.includes('Efficiency') ? 'bg-rose-100 text-rose-700' :
                                    'bg-emerald-100 text-emerald-700'
                                }`}>
                                {metric.change}
                                {metric.trend === 'up' ? <ArrowUpRight size={14} /> : <ArrowDownRight size={14} />}
                            </div>
                        </div>
                        <div className="text-secondary-500 text-sm font-medium">{metric.title}</div>
                        <div className="text-2xl font-bold text-secondary-900 mt-1">{metric.value}</div>
                    </div>
                ))}
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* PAR Movement Trend */}
                <div className="lg:col-span-2 bg-white p-6 rounded-xl border border-secondary-200 shadow-sm">
                    <h3 className="text-lg font-bold text-secondary-900 mb-6 flex items-center gap-2">
                        <TrendingDown className="text-primary-600" size={20} />
                        Asset Quality Trend (Last 6 Months)
                    </h3>
                    <div className="h-[300px]">
                        <ResponsiveContainer width="100%" height="100%">
                            <AreaChart data={portfolioTrendData}>
                                <defs>
                                    <linearGradient id="colorPar30" x1="0" y1="0" x2="0" y2="1">
                                        <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.1} />
                                        <stop offset="95%" stopColor="#f59e0b" stopOpacity={0} />
                                    </linearGradient>
                                    <linearGradient id="colorNpa" x1="0" y1="0" x2="0" y2="1">
                                        <stop offset="5%" stopColor="#ef4444" stopOpacity={0.1} />
                                        <stop offset="95%" stopColor="#ef4444" stopOpacity={0} />
                                    </linearGradient>
                                </defs>
                                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                                <XAxis dataKey="month" axisLine={false} tickLine={false} tick={{ fill: '#64748b' }} dy={10} />
                                <YAxis axisLine={false} tickLine={false} tick={{ fill: '#64748b' }} />
                                <Tooltip
                                    contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                                />
                                <Legend />
                                <Area type="monotone" dataKey="par30" name="PAR 30+ (%)" stroke="#f59e0b" fillOpacity={1} fill="url(#colorPar30)" strokeWidth={3} />
                                <Area type="monotone" dataKey="npa" name="NPA 90+ (%)" stroke="#ef4444" fillOpacity={1} fill="url(#colorNpa)" strokeWidth={3} />
                            </AreaChart>
                        </ResponsiveContainer>
                    </div>
                </div>

                {/* Portfolio Composition */}
                <div className="bg-white p-6 rounded-xl border border-secondary-200 shadow-sm">
                    <h3 className="text-lg font-bold text-secondary-900 mb-6 flex items-center gap-2">
                        <AlertCircle className="text-primary-600" size={20} />
                        Risk Buckets
                    </h3>
                    <div className="h-[250px] relative">
                        <ResponsiveContainer width="100%" height="100%">
                            <PieChart>
                                <Pie
                                    data={riskBuckets}
                                    cx="50%"
                                    cy="50%"
                                    innerRadius={60}
                                    outerRadius={80}
                                    paddingAngle={5}
                                    dataKey="value"
                                >
                                    {riskBuckets.map((entry, index) => (
                                        <Cell key={`cell-${index}`} fill={entry.color} strokeWidth={0} />
                                    ))}
                                </Pie>
                                <Tooltip />
                                <Legend layout="vertical" verticalAlign="bottom" height={36} />
                            </PieChart>
                        </ResponsiveContainer>
                        {/* Center Text */}
                        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 -mt-6 text-center">
                            <div className="text-3xl font-bold text-secondary-900">92.5%</div>
                            <div className="text-xs text-secondary-500 font-medium uppercase tracking-wider">Regular</div>
                        </div>
                    </div>
                    <div className="mt-4 space-y-3">
                        {riskBuckets.filter(b => b.name !== 'Regular').map((bucket, idx) => (
                            <div key={idx} className="flex justify-between items-center text-sm">
                                <div className="flex items-center gap-2">
                                    <div className="w-2 h-2 rounded-full" style={{ backgroundColor: bucket.color }}></div>
                                    <span className="text-secondary-600">{bucket.name}</span>
                                </div>
                                <span className="font-bold text-secondary-900">{bucket.value}%</span>
                            </div>
                        ))}
                    </div>
                </div>
            </div>

            {/* State Wise Risk Table */}
            <div className="bg-white rounded-xl border border-secondary-200 shadow-sm overflow-hidden">
                <div className="p-6 border-b border-secondary-100 flex justify-between items-center">
                    <h3 className="text-lg font-bold text-secondary-900">Regional Risk Profile</h3>
                    <button className="text-sm text-primary-600 font-bold hover:text-primary-700">View Full Report &rarr;</button>
                </div>
                <div className="overflow-x-auto">
                    <table className="w-full text-left text-sm">
                        <thead className="bg-secondary-50 text-secondary-500 font-medium">
                            <tr>
                                <th className="px-6 py-4">State</th>
                                <th className="px-6 py-4">Portfolio (GLP)</th>
                                <th className="px-6 py-4">PAR %</th>
                                <th className="px-6 py-4">Risk Level</th>
                                <th className="px-6 py-4 text-right">Action</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-secondary-100">
                            {stateWiseRisk.map((row, idx) => (
                                <tr key={idx} className="hover:bg-secondary-50/50 transition-colors">
                                    <td className="px-6 py-4 font-bold text-secondary-900">{row.state}</td>
                                    <td className="px-6 py-4 text-secondary-600">₹{row.glp.toLocaleString()} Cr</td>
                                    <td className="px-6 py-4">
                                        <span className={`px-2 py-1 rounded-md font-bold text-xs ${row.par > 4 ? 'bg-rose-100 text-rose-700' :
                                            row.par > 2 ? 'bg-amber-100 text-amber-700' :
                                                'bg-emerald-100 text-emerald-700'
                                            }`}>
                                            {row.par}%
                                        </span>
                                    </td>
                                    <td className="px-6 py-4">
                                        <div className="flex items-center gap-2">
                                            <div className={`w-2 h-2 rounded-full ${row.risk === 'Critical' ? 'bg-rose-500' :
                                                row.risk === 'High' ? 'bg-orange-500' :
                                                    row.risk === 'Medium' ? 'bg-amber-500' :
                                                        'bg-emerald-500'
                                                }`}></div>
                                            <span className="text-secondary-700 font-medium">{row.risk}</span>
                                        </div>
                                    </td>
                                    <td className="px-6 py-4 text-right">
                                        <button className="text-xs font-bold text-primary-600 border border-primary-200 px-3 py-1.5 rounded-lg hover:bg-primary-50 transition-colors">
                                            Analyze
                                        </button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
};

export default PortfolioDashboard;
