const fs = require('fs');
const glob = require('glob'); // Note: we might not need glob, can just readdirSync
const path = require('path');

const dir = path.join(__dirname, 'src', 'pages');
const files = fs.readdirSync(dir).filter(f => f.endsWith('Dashboard.tsx'));

files.forEach(file => {
    const filePath = path.join(dir, file);
    let content = fs.readFileSync(filePath, 'utf8');
    let modified = false;

    // 1. Add saveFile import
    if (!content.includes('import { saveFile }')) {
        const lines = content.split('\n');
        const reactImportIndex = lines.findIndex(l => l.includes('import { useRef } from \'react\''));
        if (reactImportIndex !== -1) {
            lines.splice(reactImportIndex + 1, 0, "import { saveFile } from '../lib/utils';");
            content = lines.join('\n');
            modified = true;
        } else {
            const lucideIndex = lines.findIndex(l => l.includes("from 'lucide-react';"));
            if (lucideIndex !== -1) {
                lines.splice(lucideIndex + 1, 0, "import { saveFile } from '../lib/utils';");
                content = lines.join('\n');
                modified = true;
            }
        }
    }

    // 2. Excel
    const excelTarget = "XLSX.writeFile(wb, getFilename('xlsx'));";
    if (content.includes(excelTarget)) {
        const excelReplacement = `const out = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
        saveFile(new Blob([out], { type: 'application/octet-stream' }), getFilename('xlsx'));`;
        content = content.replace(excelTarget, excelReplacement);
        modified = true;
    }

    // 3. PDF
    const pdfTarget = "pdf.save(getFilename('pdf'));";
    if (content.includes(pdfTarget)) {
        const pdfReplacement = "saveFile(pdf.output('blob'), getFilename('pdf'));";
        content = content.replace(pdfTarget, pdfReplacement);
        modified = true;
    }

    // 4. PPT
    const pptTarget = 'pptx.writeFile({ fileName: getFilename(\'pptx\') }).catch((err: any) => console.error("PPT Error:", err));';
    if (content.includes(pptTarget)) {
        const pptReplacement = `const blob = (await pptx.write('blob')) as Blob;
            saveFile(blob, getFilename('pptx'));`;
        content = content.replace(pptTarget, pptReplacement);
        modified = true;
    }

    if (modified) {
        fs.writeFileSync(filePath, content, 'utf8');
        console.log(`Updated ${file}`);
    }
});
