const fs = require('fs');
const file = 'src/pages/PortfolioDashboard.tsx';
let c = fs.readFileSync(file, 'utf8');

// Fix 1: ensure tab type includes vintage + regulatory
c = c.replace(
    "useState<'portfolio' | 'audit'>('portfolio')",
    "useState<'portfolio' | 'audit' | 'vintage' | 'regulatory'>('portfolio')"
);
// If it was already changed in a prior run, this is a no-op

// Fix 2: Fix the tabs array - find it and replace
// The old tabs array:
const oldTabsArr = `    const tabs = [
        { key: 'portfolio', label: '📉 Portfolio Quality' },
        { key: 'audit', label: '🛡️ Audit & Control' },
    ] as const;`;

const newTabsArr = `    const tabs = [
        { key: 'portfolio', label: '📉 Portfolio Quality' },
        { key: 'audit', label: '🛡️ Audit & Control' },
        { key: 'vintage', label: '📋 Vintage Cohorts' },
        { key: 'regulatory', label: '⚖️ Regulatory' },
    ] as const;`;

if (c.includes(oldTabsArr)) {
    c = c.replace(oldTabsArr, newTabsArr);
    console.log('tabs array fixed (CRLF-less match)');
} else {
    // Try CRLF version
    const oldTabsCRLF = oldTabsArr.replace(/\n/g, '\r\n');
    if (c.includes(oldTabsCRLF)) {
        c = c.replace(oldTabsCRLF, newTabsArr);
        console.log('tabs array fixed (CRLF match)');
    } else {
        // Manual line-by-line search and replace
        const lines = c.split('\n');
        let startLine = -1;
        for (let i = 0; i < lines.length; i++) {
            if (lines[i].includes("key: 'portfolio'") && lines[i - 1] && lines[i - 1].includes('tabs = [')) {
                startLine = i - 1;
            }
            if (startLine >= 0 && lines[i].includes('] as const;')) {
                // Replace this block
                lines.splice(startLine, i - startLine + 1,
                    "    const tabs = [",
                    "        { key: 'portfolio', label: '📉 Portfolio Quality' },",
                    "        { key: 'audit', label: '🛡\uFE0F Audit & Control' },",
                    "        { key: 'vintage', label: '📋 Vintage Cohorts' },",
                    "        { key: 'regulatory', label: '⚖\uFE0F Regulatory' },",
                    "    ] as const;"
                );
                console.log('tabs array fixed (line-by-line at', startLine + ')');
                break;
            }
        }
        c = lines.join('\n');
    }
}

fs.writeFileSync(file, c, 'utf8');
console.log('Done. Tab entries now:', (c.match(/key:/g) || []).length);
