const fs = require('fs');
const path = require('path');

function processDir(dir) {
    const files = fs.readdirSync(dir);
    for (const file of files) {
        const fullPath = path.join(dir, file);
        if (fs.statSync(fullPath).isDirectory()) {
            processDir(fullPath);
        } else if (fullPath.endsWith('.tsx')) {
            let content = fs.readFileSync(fullPath, 'utf8');
            let modified = false;

            // Simple regex to insert isAnimationActive={false} into recharts components
            // Matches <Area ...>, <Bar ...>, <Line ...>, <Pie ...>
            let newContent = content.replace(/<(Area|Bar|Line|Pie)\s([^>]*?)>/g, (match, tag, rest) => {
                if (rest.includes('isAnimationActive')) {
                    return match; // Already exists
                }
                modified = true;
                return `<${tag} isAnimationActive={false} ${rest}>`;
            });

            if (modified) {
                fs.writeFileSync(fullPath, newContent);
                console.log(`Fixed Recharts animation in ${file}`);
            }
        }
    }
}

processDir(path.join(__dirname, 'src/pages'));
processDir(path.join(__dirname, 'src/components'));
console.log('Done processing chart animations.');
