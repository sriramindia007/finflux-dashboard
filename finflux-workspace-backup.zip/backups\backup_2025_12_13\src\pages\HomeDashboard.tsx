import React, { useState } from 'react';
import { LayoutDashboard, Users, Building2, Activity, TrendingUp, AlertTriangle, ArrowUpRight, Droplet, Heart, Sun, FileText } from 'lucide-react';
import KPICard from '../components/KPICard';
import { COMPANY_METRICS, STATES_DATA, TOP_BRANCHES } from '../data/mfiData';

const formatNumber = (num: number) => num ? num.toLocaleString() : '0';

const HomeDashboard = () => {
    const [selectedRegion, setSelectedRegion] = useState('All');

    // Mapping dropdown values to data keys
    const stateKeyMap: Record<string, keyof typeof STATES_DATA> = {
        'Odisha': 'odisha',
        'Bihar': 'bihar',
        'Madhya Pradesh': 'madhyaPradesh',
        'West Bengal': 'westBengal',
        'Gujarat': 'gujarat',
        'Rajasthan': 'rajasthan',
        'Telangana': 'telangana',
        'Maharashtra': 'maharashtra',
        'Karnataka': 'karnataka',
        'Uttar Pradesh': 'uttarPradesh',
        'Tamil Nadu': 'tamilNadu',
        'Chhattisgarh': 'chhattisgarh',
        'Punjab': 'punjab',
        'Haryana': 'haryana',
        'Andhra Pradesh': 'andhra',
        'Himachal Pradesh': 'himachal',
    };

    // Determine metrics based on selection
    const metrics = (selectedRegion === 'All' ? COMPANY_METRICS : STATES_DATA[stateKeyMap[selectedRegion]] || COMPANY_METRICS) as any;

    // Filter Top Branches
    const topBranches = selectedRegion === 'All'
        ? TOP_BRANCHES
        : TOP_BRANCHES.filter(b => b.state === selectedRegion);

    const handleExport = () => {
        alert(`Exporting report for ${selectedRegion}...`);
    };

    return (
        <div className="space-y-6">
            {/* Header Area */}
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                    <h1 className="text-2xl font-bold text-secondary-900">Executive Overview</h1>
                    <p className="text-secondary-500">FY2025 Strategic Performance</p>
                </div>

                <div className="flex gap-2">
                    <select
                        value={selectedRegion}
                        onChange={(e) => setSelectedRegion(e.target.value)}
                        className="bg-white border border-secondary-300 rounded-lg px-4 py-2 text-secondary-700 outline-none focus:ring-2 focus:ring-primary-500 shadow-sm"
                    >
                        <option value="All">Global View (All Regions)</option>
                        {Object.values(STATES_DATA).map(state => (
                            <option key={state.name} value={state.name}>{state.name}</option>
                        ))}
                    </select>
                    <button
                        onClick={handleExport}
                        className="bg-primary-600 hover:bg-primary-700 text-white px-4 py-2 rounded-lg transition-colors flex items-center gap-2 shadow-md"
                    >
                        <FileText size={18} />
                        Export
                    </button>
                </div>
            </div>

            {/* Risk Note Banner */}
            {metrics.riskNote && (
                <div className="bg-amber-50 border-l-4 border-amber-500 p-4 rounded-r-lg flex items-start gap-3 shadow-sm animate-in fade-in slide-in-from-top-2">
                    <AlertTriangle className="text-amber-600 shrink-0" size={24} />
                    <div>
                        <h3 className="font-bold text-amber-800">Critical Risk Attention</h3>
                        <p className="text-amber-700">{metrics.riskNote}</p>
                    </div>
                </div>
            )}

            {/* Network Scale - Streamlined */}
            <div className="bg-white border border-secondary-200 rounded-xl p-6 shadow-sm">
                <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-3">
                        <div className="p-2 bg-primary-100 rounded-lg text-primary-600">
                            <Users size={20} />
                        </div>
                        <h2 className="text-lg font-bold text-secondary-900">Scale & Reach</h2>
                    </div>
                    <div className="text-2xl font-bold text-primary-600">{formatNumber(metrics.activeClients)} <span className="text-sm font-normal text-secondary-500">Active Borrowers</span></div>
                </div>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-4 border-t border-secondary-100">
                    <div>
                        <div className="text-xs text-secondary-500 uppercase font-semibold tracking-wide">Branches</div>
                        <div className="text-xl font-bold text-secondary-900">{metrics.totalBranches || metrics.branches}</div>
                        {(metrics.newBranchesFY25 || selectedRegion === 'All') && (
                            <div className="text-xs text-emerald-600 flex items-center gap-0.5 font-medium">+ {metrics.newBranchesFY25 || 180} New (FY25)</div>
                        )}
                    </div>
                    <div>
                        <div className="text-xs text-secondary-500 uppercase font-semibold tracking-wide">Coverage</div>
                        <div className="text-xl font-bold text-secondary-900">{metrics.totalDistricts || metrics.districts} <span className="text-sm font-normal text-secondary-500">Districts</span></div>
                    </div>
                    <div>
                        <div className="text-xs text-secondary-500 uppercase font-semibold tracking-wide">Workforce</div>
                        <div className="text-xl font-bold text-secondary-900">{selectedRegion === 'All' ? metrics.totalEmployees.toLocaleString() : '-'}</div>
                    </div>
                    <div>
                        <div className="text-xs text-secondary-500 uppercase font-semibold tracking-wide">Presence</div>
                        <div className="text-xl font-bold text-secondary-900">{selectedRegion === 'All' ? COMPANY_METRICS.totalStates : 1} <span className="text-sm font-normal text-secondary-500">States</span></div>
                    </div>
                </div>
            </div>

            {/* Financial Performance KPIs */}
            <h3 className="text-lg font-semibold text-secondary-800 pt-2">Financial Performance</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <KPICard
                    title="AUM (GLP)"
                    value={`₹${(metrics.currentGLP || metrics.glp).toLocaleString()} Cr`}
                    trend="up"
                    trendValue="12.4% YoY"
                    icon={LayoutDashboard}
                    className="border-t-4 border-t-primary-500"
                />
                <KPICard
                    title="PAR > 30 Days"
                    value={`${metrics.parOver30 || metrics.par30}%`}
                    trend="down"
                    trendValue="0.2% (MoM)"
                    icon={AlertTriangle}
                    className={`border-t-4 ${(metrics.parOver30 || metrics.par30) > 2.5 ? "border-t-amber-500" : "border-t-emerald-500"}`}
                />
                <KPICard
                    title="Disbursement (YTD)"
                    value={`₹${metrics.ytdDisbursement} Cr`}
                    trend="up"
                    trendValue="98% of Target"
                    icon={TrendingUp}
                    className="border-t-4 border-t-blue-500"
                />
                <KPICard
                    title="Collection Efficiency"
                    value="96.5%"
                    subValue={`MSME: ${COMPANY_METRICS.collectionEfficiencyMsme}%`}
                    trend="neutral"
                    trendValue="Stable"
                    icon={Activity}
                    className="border-t-4 border-t-indigo-500"
                />
            </div>

            {/* Social Impact Section */}
            <h3 className="text-lg font-semibold text-secondary-800 pt-2">Social Impact (Triple Bottom Line)</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-white border border-cyan-100 rounded-xl p-5 shadow-sm flex items-center justify-between hover:shadow-md transition-shadow">
                    <div>
                        <div className="text-cyan-600 font-bold mb-1 flex items-center gap-2"><Droplet size={16} /> SWASTH (WASH)</div>
                        <div className="text-2xl font-bold text-secondary-900">{COMPANY_METRICS.impactStats.swasth.toLocaleString()}</div>
                        <div className="text-xs text-secondary-500">Sanitation Units</div>
                    </div>
                    <div className="h-10 w-10 bg-cyan-50 rounded-full flex items-center justify-center text-cyan-600">
                        <ArrowUpRight size={20} />
                    </div>
                </div>
                <div className="bg-white border border-fuchsia-100 rounded-xl p-5 shadow-sm flex items-center justify-between hover:shadow-md transition-shadow">
                    <div>
                        <div className="text-fuchsia-600 font-bold mb-1 flex items-center gap-2"><Heart size={16} /> Samarth</div>
                        <div className="text-2xl font-bold text-secondary-900">{COMPANY_METRICS.impactStats.samarth.toLocaleString()}</div>
                        <div className="text-xs text-secondary-500">Inclusion (PWD/Trans)</div>
                    </div>
                    <div className="h-10 w-10 bg-fuchsia-50 rounded-full flex items-center justify-center text-fuchsia-600">
                        <ArrowUpRight size={20} />
                    </div>
                </div>
                <div className="bg-white border border-amber-100 rounded-xl p-5 shadow-sm flex items-center justify-between hover:shadow-md transition-shadow">
                    <div>
                        <div className="text-amber-600 font-bold mb-1 flex items-center gap-2"><Sun size={16} /> Green Energy</div>
                        <div className="text-2xl font-bold text-secondary-900">{COMPANY_METRICS.impactStats.solar.toLocaleString()}</div>
                        <div className="text-xs text-secondary-500">Solar Units</div>
                    </div>
                    <div className="h-10 w-10 bg-amber-50 rounded-full flex items-center justify-center text-amber-600">
                        <ArrowUpRight size={20} />
                    </div>
                </div>
            </div>

            {/* Top Branches Table */}
            <div className="bg-white rounded-xl border border-secondary-200 shadow-sm overflow-hidden mt-2">
                <div className="p-6 border-b border-secondary-200 flex justify-between items-center bg-secondary-50">
                    <h3 className="font-bold text-secondary-900">Branch Leaderboard</h3>
                </div>
                <div className="overflow-x-auto">
                    <table className="w-full text-left text-sm">
                        <thead className="bg-white text-secondary-500 font-semibold border-b border-secondary-100 uppercase text-xs tracking-wider">
                            <tr>
                                <th className="px-6 py-3">Branch Name</th>
                                <th className="px-6 py-3">Location</th>
                                <th className="px-6 py-3 text-right">GLP (Cr)</th>
                                <th className="px-6 py-3 text-right">Active Loans</th>
                                <th className="px-6 py-3 text-right">Risk (PAR30)</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-secondary-50">
                            {topBranches.length > 0 ? topBranches.slice(0, 5).map((branch, idx) => (
                                <tr key={idx} className="hover:bg-secondary-50 transition-colors">
                                    <td className="px-6 py-4 font-medium text-secondary-900 flex items-center gap-2">
                                        <Building2 size={16} className="text-secondary-400" />
                                        {branch.name}
                                    </td>
                                    <td className="px-6 py-4 text-secondary-600">{branch.district}, {branch.state}</td>
                                    <td className="px-6 py-4 text-right font-bold text-secondary-900">{branch.glp.toFixed(1)}</td>
                                    <td className="px-6 py-4 text-right text-secondary-600">{branch.activeLoans.toLocaleString()}</td>
                                    <td className="px-6 py-4 text-right">
                                        <span className={`px-2 py-1 rounded text-xs font-semibold ${branch.par30 < 2 ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'}`}>
                                            {branch.par30}%
                                        </span>
                                    </td>
                                </tr>
                            )) : (
                                <tr>
                                    <td colSpan={5} className="px-6 py-8 text-center text-secondary-500 italic">
                                        No top branches data available.
                                    </td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
};

export default HomeDashboard;
