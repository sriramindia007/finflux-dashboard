const fs = require('fs');
const path = require('path');

function processDir(dir) {
    const files = fs.readdirSync(dir);
    for (const file of files) {
        const fullPath = path.join(dir, file);
        if (fs.statSync(fullPath).isDirectory()) {
            processDir(fullPath);
        } else if (fullPath.endsWith('.tsx')) {
            let content = fs.readFileSync(fullPath, 'utf8');
            const lines = content.split('\n');
            const newLines = [];
            for (let i = 0; i < lines.length; i++) {
                if (lines[i].includes("import { saveFile } from '../lib/utils';")) {
                    // Check if next line or any nearby line imports from ../lib/utils
                    let hasAnother = false;
                    for (let j = i + 1; j < Math.min(i + 5, lines.length); j++) {
                        if (lines[j].includes('../lib/utils') && lines[j].includes('saveFile')) {
                            hasAnother = true;
                            break;
                        }
                    }
                    if (hasAnother) {
                        continue; // Skip the simple saveFile import because a combined one exists
                    }
                }
                newLines.push(lines[i]);
            }
            fs.writeFileSync(fullPath, newLines.join('\n'));
        }
    }
}

processDir(path.join(__dirname, 'src/pages'));
console.log('Fixed duplicate saveFile imports');
