/**
 * Geographic coordinates and hierarchy data for all FINFLUX states
 */

export const COORDINATES = {
    // Country
    INDIA: [20.5937, 78.9629] as [number, number],

    // States
    ODISHA: [20.9517, 85.0985] as [number, number],
    KARNATAKA: [15.3173, 75.7139] as [number, number],
    ANDHRA: [15.9129, 79.7400] as [number, number],
    MADHYA_PRADESH: [22.9734, 78.6569] as [number, number],
    TAMIL_NADU: [11.1271, 78.6569] as [number, number],

    // Odisha Districts
    ODISHA_KHORDHA: [20.1815, 85.6200] as [number, number],
    ODISHA_BHUBANESWAR: [20.2961, 85.8245] as [number, number],
    ODISHA_CUTTACK: [20.4625, 85.8828] as [number, number],
    ODISHA_PURI: [19.8134, 85.8312] as [number, number],
    ODISHA_BALASORE: [21.4934, 86.9135] as [number, number],

    // Karnataka Districts
    KARNATAKA_BANGALORE: [12.9716, 77.5946] as [number, number],
    KARNATAKA_MYSORE: [12.2958, 76.6394] as [number, number],
    KARNATAKA_BELGAUM: [15.8497, 74.4977] as [number, number],
    KARNATAKA_HUBLI: [15.3647, 75.1240] as [number, number],
    KARNATAKA_MANGALORE: [12.9141, 74.8560] as [number, number],

    // Andhra Pradesh Districts
    ANDHRA_VIJAYAWADA: [16.5062, 80.6480] as [number, number],
    ANDHRA_VISAKHAPATNAM: [17.6868, 83.2185] as [number, number],
    ANDHRA_GUNTUR: [16.3067, 80.4365] as [number, number],
    ANDHRA_TIRUPATI: [13.6288, 79.4192] as [number, number],
    ANDHRA_KAKINADA: [16.9891, 82.2475] as [number, number],

    // Madhya Pradesh Districts
    MP_INDORE: [22.7196, 75.8577] as [number, number],
    MP_BHOPAL: [23.2599, 77.4126] as [number, number],
    MP_JABALPUR: [23.1815, 79.9864] as [number, number],
    MP_GWALIOR: [26.2183, 78.1828] as [number, number],
    MP_UJJAIN: [23.1765, 75.7885] as [number, number],

    // Tamil Nadu Districts
    TN_CHENNAI: [13.0827, 80.2707] as [number, number],
    TN_COIMBATORE: [11.0168, 76.9558] as [number, number],
    TN_MADURAI: [9.9252, 78.1198] as [number, number],
    TN_SALEM: [11.6643, 78.1460] as [number, number],
    TN_TRICHY: [10.7905, 78.7047] as [number, number],

    // Sample Branches (Odisha - for drill-down demo)
    BRANCH_BAGHEITANGI: [20.1750, 85.6500] as [number, number],
    BRANCH_TANGI: [19.9234, 85.4045] as [number, number],
    BRANCH_BHUBANESWAR_URBAN: [20.3000, 85.8300] as [number, number],
    BRANCH_CUTTACK_CENTRAL: [20.4650, 85.8850] as [number, number],

    // Sample Villages
    VILLAGE_MUNDEL: [20.1850, 85.6550] as [number, number],
    VILLAGE_OLD_TOWN: [20.2900, 85.8400] as [number, number],

    // Sample Centres
    CENTRE_1: [20.1870, 85.6570] as [number, number],
    CENTRE_7: [20.2910, 85.8410] as [number, number],
};

export interface GeoHierarchy {
    level: 'Country' | 'State' | 'District' | 'Branch' | 'Village' | 'Centre';
    label: string;
    glp: number; // in Crores
    branches?: number | string;
    par30: number;
    digitalPercentage: number;
    meetings?: { total: number; within: number };
}

// Helper function to get stats for any level
export const getGeoStats = (level: string, parent?: string, label?: string): GeoHierarchy => {
    // Country level
    if (level === 'Country') {
        return {
            level: 'Country',
            label: 'India',
            glp: 8500,
            branches: 3520,
            par30: 3.2,
            digitalPercentage: 65,
            meetings: { total: 4500, within: 4100 },
        };
    }

    // State level
    if (level === 'State') {
        const stateData: Record<string, any> = {
            'Odisha': { glp: 3400, branches: 1420, par30: 2.8, digitalPercentage: 60 },
            'Karnataka': { glp: 2100, branches: 870, par30: 3.1, digitalPercentage: 68 },
            'Andhra Pradesh': { glp: 1700, branches: 710, par30: 3.5, digitalPercentage: 62 },
            'Madhya Pradesh': { glp: 850, branches: 350, par30: 3.8, digitalPercentage: 55 },
            'Tamil Nadu': { glp: 450, branches: 170, par30: 2.5, digitalPercentage: 72 },
        };
        const data = stateData[label || 'Odisha'];
        return {
            level: 'State',
            label: label || 'Odisha',
            glp: data.glp,
            branches: data.branches,
            par30: data.par30,
            digitalPercentage: data.digitalPercentage,
            meetings: { total: 1200, within: 1120 },
        };
    }

    // District level
    if (level === 'District') {
        const districtDefaults = {
            'Odisha': {
                'Khordha': { glp: 920, branches: 380, par30: 2.5 },
                'Bhubaneswar': { glp: 765, branches: 310, par30: 2.4 },
                'Cuttack': { glp: 720, branches: 290, par30: 2.9 },
                'Puri': { glp: 540, branches: 220, par30: 3.0 },
                'Balasore': { glp: 455, branches: 220, par30: 3.2 },
            },
            'Karnataka': {
                'Bangalore Urban': { glp: 580, branches: 240, par30: 2.9 },
                'Mysore': { glp: 420, branches: 175, par30: 3.0 },
                'Belgaum': { glp: 380, branches: 155, par30: 3.2 },
                'Hubli-Dharwad': { glp: 340, branches: 140, par30: 3.1 },
                'Mangalore': { glp: 380, branches: 160, par30: 3.0 },
            },
            'Andhra Pradesh': {
                'Vijayawada': { glp: 480, branches: 200, par30: 3.3 },
                'Visakhapatnam': { glp: 420, branches: 175, par30: 3.4 },
                'Guntur': { glp: 340, branches: 142, par30: 3.5 },
                'Tirupati': { glp: 290, branches: 120, par30: 3.6 },
                'Kakinada': { glp: 170, branches: 73, par30: 3.7 },
            },
            'Madhya Pradesh': {
                'Indore': { glp: 240, branches: 100, par30: 3.6 },
                'Bhopal': { glp: 200, branches: 83, par30: 3.8 },
                'Jabalpur': { glp: 170, branches: 71, par30: 3.9 },
                'Gwalior': { glp: 140, branches: 58, par30: 4.0 },
                'Ujjain': { glp: 100, branches: 38, par30: 4.1 },
            },
            'Tamil Nadu': {
                'Chennai': { glp: 150, branches: 57, par30: 2.3 },
                'Coimbatore': { glp: 110, branches: 42, par30: 2.4 },
                'Madurai': { glp: 95, branches: 36, par30: 2.6 },
                'Salem': { glp: 65, branches: 25, par30: 2.7 },
                'Tiruchirappalli': { glp: 30, branches: 10, par30: 2.8 },
            },
        };

        const stateDistricts = districtDefaults[parent || 'Odisha'];
        const data = stateDistricts[label || 'Khordha'];

        return {
            level: 'District',
            label: label || 'Khordha',
            glp: data.glp,
            branches: data.branches,
            par30: data.par30,
            digitalPercentage: 62,
            meetings: { total: 67, within: 59 },
        };
    }

    // Branch level (simplified)
    if (level === 'Branch') {
        return {
            level: 'Branch',
            label: label || 'Bagheitangi',
            glp: 45,
            branches: 2,
            par30: 1.2,
            digitalPercentage: 70,
            meetings: { total: 42, within: 37 },
        };
    }

    // Default fallback
    return {
        level: 'Country',
        label: 'India',
        glp: 8500,
        branches: 3520,
        par30: 3.2,
        digitalPercentage: 65,
    };
};
