import { useState, useMemo, useEffect } from 'react';
import {
    Users, Banknote, AlertCircle, CheckCircle2,
    MapPin, TrendingUp, Calendar, FileText, Smartphone, ChevronDown
} from 'lucide-react';
import KPICard from '../components/KPICard';
import { cn } from '../lib/utils';
import { ALL_STATES_DATA, Branch, State, District } from '../data/geoDataComplete';
import { getBranchHistory, generateProductMix, MONTHS, Month } from '../data/mfiData';

// --- Data Types ---
interface EnrichedBranchData {
    name: string;
    region: string; // District
    state: string;
    applications: { approved: number, received: number, approvedYtd: number, receivedYtd: number };
    disbursement: { count: number, countYtd: number, amount: number, amountYtd: number }; // amt in Cr
    collections: { due: number, paid: number, dueYtd: number, paidYtd: number, efficiency: number }; // amt in Cr
    overdue: number; // Cr
    glp: number; // Cr
    clients: { active: number, loans: number };
    meetings: { total: number, within: number, outside: number, attendance: number };
    digitalSplit: { digital: number, cash: number };
    par: { par30: number, par90: number };
    writeOff: number; // Cr
    coords: [number, number];
}

// Stats Generator based on GLP/Clients to make it look realistic
const enrichBranchData = (branch: Branch, district: string, state: string): EnrichedBranchData => {
    // Deterministic seed based on name length for stability
    const seed = branch.name.length;

    // Derived Metrics
    const basePAR = 1.5 + (seed % 3); // 1.5% - 4.5%
    const efficiency = 98 - (basePAR * 0.5);
    const activeClients = branch.clients;
    const loanCount = Math.floor(activeClients * 1.1);

    return {
        name: branch.name,
        region: district,
        state: state,
        applications: {
            received: Math.floor(activeClients * 0.1),
            approved: Math.floor(activeClients * 0.1 * 0.85),
            receivedYtd: activeClients,
            approvedYtd: Math.floor(activeClients * 0.85)
        },
        disbursement: {
            count: Math.floor(loanCount * 0.08),
            countYtd: Math.floor(loanCount * 0.8),
            amount: parseFloat((branch.glp * 0.1).toFixed(2)),
            amountYtd: parseFloat((branch.glp * 0.9).toFixed(2))
        },
        collections: {
            due: parseFloat((branch.glp * 0.05).toFixed(2)),
            paid: parseFloat((branch.glp * 0.05 * (efficiency / 100)).toFixed(2)),
            dueYtd: parseFloat((branch.glp * 0.6).toFixed(2)),
            paidYtd: parseFloat((branch.glp * 0.6 * (efficiency / 100)).toFixed(2)),
            efficiency: parseFloat(efficiency.toFixed(1))
        },
        overdue: parseFloat((branch.glp * (basePAR / 100)).toFixed(2)),
        glp: branch.glp,
        clients: { active: activeClients, loans: loanCount },
        meetings: {
            total: Math.floor(activeClients / 30), // ~30 clients per center/meeting
            within: Math.floor((activeClients / 30) * 0.9),
            outside: Math.floor((activeClients / 30) * 0.1),
            attendance: 90 + (seed % 5)
        },
        digitalSplit: { digital: 60 + (seed % 15), cash: 40 - (seed % 15) },
        par: { par30: basePAR, par90: parseFloat((basePAR * 0.3).toFixed(2)) },
        writeOff: branch.writeOff || parseFloat((branch.glp * 0.005).toFixed(4)),
        coords: branch.coord
    };
};

const BranchDashboard = () => {
    // Selection State
    const [selectedState, setSelectedState] = useState<State>(ALL_STATES_DATA[0]);
    const [selectedDistrict, setSelectedDistrict] = useState<District>(ALL_STATES_DATA[0].districts[0]);
    const [selectedBranchRaw, setSelectedBranchRaw] = useState<Branch>(ALL_STATES_DATA[0].districts[0].branches[0]);

    // View State
    const [selectedMonth, setSelectedMonth] = useState<Month>('Dec');

    // Update cascading View
    useEffect(() => {
        // Reset downstream selections when upstream changes
        if (selectedState) {
            const firstDist = selectedState.districts[0];
            setSelectedDistrict(firstDist);
            setSelectedBranchRaw(firstDist.branches[0]);
        }
    }, [selectedState]);

    useEffect(() => {
        if (selectedDistrict) {
            setSelectedBranchRaw(selectedDistrict.branches[0]);
        }
    }, [selectedDistrict]);

    // Enriched Data
    const branchData = useMemo(() =>
        enrichBranchData(selectedBranchRaw, selectedDistrict.name, selectedState.name),
        [selectedBranchRaw, selectedDistrict, selectedState]);

    // Product Mix Data (Time Series)
    const productMixData = useMemo(() => {
        // 1. Get History
        const history = getBranchHistory(branchData.name, branchData.glp, branchData.par.par30);
        // 2. Find Month
        const monthMetric = history.find(m => m.month === selectedMonth) || history[history.length - 1];
        // 3. Generate Mix
        const mix = generateProductMix(monthMetric.glp, monthMetric.par30);

        return { metric: monthMetric, mix };
    }, [branchData, selectedMonth]);


    // Format helpers
    const fmtCr = (v: number) => `₹${v.toFixed(2)} Cr`;
    const fmtK = (v: number) => `${(v / 1000).toFixed(1)}k`;

    return (
        <div className="flex flex-col gap-6 h-[calc(100vh-100px)]">

            {/* Header & Controls */}
            <div className="bg-white p-4 rounded-xl border border-secondary-200 shadow-sm flex flex-col md:flex-row justify-between items-center gap-4">
                <div className="flex items-center gap-4 w-full md:w-auto overflow-x-auto">
                    {/* State Selector */}
                    <div className="relative group">
                        <label className="text-[10px] text-secondary-500 font-bold uppercase tracking-wider mb-1 block">State</label>
                        <select
                            className="bg-secondary-50 border border-secondary-200 text-secondary-900 text-sm rounded-lg focus:ring-primary-500 focus:border-primary-500 block w-40 p-2.5 outline-none font-semibold"
                            value={selectedState.name}
                            onChange={(e) => setSelectedState(ALL_STATES_DATA.find(s => s.name === e.target.value)!)}
                        >
                            {ALL_STATES_DATA.map(s => <option key={s.name} value={s.name}>{s.name}</option>)}
                        </select>
                    </div>

                    {/* District Selector */}
                    <div className="relative group">
                        <label className="text-[10px] text-secondary-500 font-bold uppercase tracking-wider mb-1 block">District</label>
                        <select
                            className="bg-secondary-50 border border-secondary-200 text-secondary-900 text-sm rounded-lg focus:ring-primary-500 focus:border-primary-500 block w-40 p-2.5 outline-none font-semibold"
                            value={selectedDistrict.name}
                            onChange={(e) => setSelectedDistrict(selectedState.districts.find(d => d.name === e.target.value)!)}
                        >
                            {selectedState.districts.map(d => <option key={d.name} value={d.name}>{d.name}</option>)}
                        </select>
                    </div>

                    {/* Branch Selector */}
                    <div className="relative group">
                        <label className="text-[10px] text-secondary-500 font-bold uppercase tracking-wider mb-1 block">Branch</label>
                        <select
                            className="bg-yellow-50 border border-yellow-200 text-yellow-900 text-sm rounded-lg focus:ring-yellow-500 focus:border-yellow-500 block w-48 p-2.5 outline-none font-bold"
                            value={selectedBranchRaw.name}
                            onChange={(e) => setSelectedBranchRaw(selectedDistrict.branches.find(b => b.name === e.target.value)!)}
                        >
                            {selectedDistrict.branches.map(b => <option key={b.name} value={b.name}>{b.name}</option>)}
                        </select>
                    </div>
                </div>

                <div className="flex items-center gap-6 border-l border-secondary-200 pl-6">
                    <div className='text-right'>
                        <p className="text-secondary-500 flex items-center justify-end gap-1 text-xs"><MapPin size={12} /> {branchData.state}</p>
                        <h2 className="text-xl font-bold text-secondary-900">{branchData.name}</h2>
                    </div>
                    <div className="text-right">
                        <div className="text-xs text-secondary-500">Branch GLP</div>
                        <div className="text-2xl font-bold text-primary-600">{fmtCr(branchData.glp)}</div>
                    </div>
                </div>
            </div>

            {/* Main Content Scrollable */}
            <div className="flex-1 overflow-y-auto space-y-6 pr-2">

                {/* KPI Grid 1: Business Growth */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <KPICard title="Applications" value={branchData.applications.received.toString()} subValue={`Appr: ${branchData.applications.approved}`} icon={FileText} />
                    <KPICard title="Disbursed Loans" value={branchData.disbursement.count.toString()} subValue={`Value: ${fmtCr(branchData.disbursement.amount)}`} icon={CheckCircle2} />
                    <KPICard title="Active Clients" value={fmtK(branchData.clients.active)} subValue={`Loans: ${fmtK(branchData.clients.loans)}`} icon={Users} />
                    <KPICard title="Attendance" value={`${branchData.meetings.attendance}%`} subValue={`${branchData.meetings.total} Meetings`} icon={Calendar}
                        className={branchData.meetings.attendance < 90 ? "border-l-4 border-l-amber-500" : "border-l-4 border-l-emerald-500"} />
                </div>

                {/* KPI Grid 2: Financials & Collections */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <KPICard title="Collection Eff." value={`${branchData.collections.efficiency}%`}
                        subValue={`Due: ${fmtCr(branchData.collections.due)}`} icon={TrendingUp}
                        className={branchData.collections.efficiency >= 95.5 ? "border-l-4 border-l-emerald-500" : "border-l-4 border-l-amber-500"} />
                    <KPICard title="Collections Paid" value={fmtCr(branchData.collections.paid)} trend="neutral" trendValue="MTD" icon={Banknote} />
                    <KPICard title="Overdue" value={fmtCr(branchData.overdue)} trend="down" trendValue="Critical" icon={AlertCircle} className="border-l-4 border-l-rose-500" />
                    <KPICard title="Write-offs (YTD)" value={fmtCr(branchData.writeOff)} icon={Banknote} />
                </div>

                {/* Metric Split: Geo-Fence + PAR */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    {/* Geo-Fencing Stats */}
                    <div className="bg-white p-6 rounded-xl border border-secondary-200 shadow-sm">
                        <h4 className="font-semibold text-secondary-800 mb-4 flex justify-between">
                            <span>Centre Meeting Compliance</span>
                            <span className="text-sm font-normal text-secondary-500">Geo-Fence</span>
                        </h4>
                        <div className="flex items-center gap-6">
                            <div className="relative w-32 h-32 flex items-center justify-center rounded-full border-8 border-emerald-100">
                                <span className="text-2xl font-bold text-emerald-600">{Math.round((branchData.meetings.within / branchData.meetings.total) * 100)}%</span>
                            </div>
                            <div className="space-y-3 flex-1">
                                <div className="flex justify-between items-center text-sm">
                                    <span className="text-secondary-600">Within Fence</span>
                                    <span className="font-bold text-emerald-600">{branchData.meetings.within}</span>
                                </div>
                                <div className="w-full bg-secondary-100 h-2 rounded-full overflow-hidden">
                                    <div className="h-full bg-emerald-500" style={{ width: `${(branchData.meetings.within / branchData.meetings.total) * 100}%` }}></div>
                                </div>
                                <div className="flex justify-between items-center text-sm">
                                    <span className="text-secondary-600">Outside Fence</span>
                                    <span className="font-bold text-rose-600">{branchData.meetings.outside}</span>
                                </div>
                                <div className="w-full bg-secondary-100 h-2 rounded-full overflow-hidden">
                                    <div className="h-full bg-rose-500" style={{ width: `${(branchData.meetings.outside / branchData.meetings.total) * 100}%` }}></div>
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* PAR & Digital Stats */}
                    <div className="bg-white p-6 rounded-xl border border-secondary-200 shadow-sm space-y-6">
                        <div>
                            <h4 className="font-semibold text-secondary-800 mb-3">Portfolio at Risk (PAR)</h4>
                            <div className="flex gap-4">
                                <div className="flex-1 p-3 bg-rose-50 rounded-lg border border-rose-100 text-center">
                                    <div className="text-xs text-rose-600 uppercase font-bold tracking-wider">PAR {'>'} 30</div>
                                    <div className="text-xl font-bold text-rose-700">{branchData.par.par30}%</div>
                                </div>
                                <div className="flex-1 p-3 bg-rose-50 rounded-lg border border-rose-100 text-center">
                                    <div className="text-xs text-rose-600 uppercase font-bold tracking-wider">PAR {'>'} 90</div>
                                    <div className="text-xl font-bold text-rose-700">{branchData.par.par90}%</div>
                                </div>
                            </div>
                        </div>
                        <div>
                            <h4 className="font-semibold text-secondary-800 mb-3">Repayment Mode</h4>
                            <div className="flex items-center gap-4">
                                <div className="flex items-center gap-2">
                                    <Smartphone className="text-primary-500" size={20} />
                                    <div>
                                        <div className="text-xs text-secondary-500">Digital</div>
                                        <div className="font-bold">{branchData.digitalSplit.digital}%</div>
                                    </div>
                                </div>
                                <div className="flex-1 h-3 bg-secondary-100 rounded-full overflow-hidden flex">
                                    <div className="bg-primary-500 h-full" style={{ width: `${branchData.digitalSplit.digital}%` }}></div>
                                    <div className="bg-emerald-500 h-full" style={{ width: `${branchData.digitalSplit.cash}%` }}></div>
                                </div>
                                <div className="flex items-center gap-2">
                                    <Banknote className="text-emerald-500" size={20} />
                                    <div>
                                        <div className="text-xs text-secondary-500">Cash</div>
                                        <div className="font-bold">{branchData.digitalSplit.cash}%</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                {/* NEW SECTION: Product Portfolio & Risk Composition */}
                <div className="bg-white p-6 rounded-xl border border-secondary-200 shadow-sm">
                    <div className="flex flex-col sm:flex-row justify-between items-center mb-6 gap-4">
                        <div>
                            <h4 className="text-lg font-bold text-secondary-900">Product Portfolio & Risk Composition</h4>
                            <p className="text-sm text-secondary-500">Breakdown of GLP and PAR% by Product Type</p>
                        </div>
                        <div className="flex items-center gap-3">
                            <label className="text-sm font-semibold text-secondary-600">Period:</label>
                            <select
                                className="bg-white border border-secondary-300 text-secondary-900 text-sm rounded-lg focus:ring-primary-500 focus:border-primary-500 block p-2 outline-none"
                                value={selectedMonth}
                                onChange={(e) => setSelectedMonth(e.target.value as Month)}
                            >
                                {MONTHS.map(m => <option key={m} value={m}>{m} 2025</option>)}
                            </select>
                        </div>
                    </div>

                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                        {/* 1. Summary Cards for the Month */}
                        <div className="col-span-1 grid grid-cols-2 lg:grid-cols-1 gap-4">
                            <div className="bg-secondary-50 p-4 rounded-lg text-center border border-secondary-100">
                                <div className="text-secondary-500 text-xs font-bold uppercase mb-1">Total GLP ({selectedMonth})</div>
                                <div className="text-2xl font-bold text-primary-700">{fmtCr(productMixData.metric.glp)}</div>
                            </div>
                            <div className="bg-secondary-50 p-4 rounded-lg text-center border border-secondary-100">
                                <div className="text-secondary-500 text-xs font-bold uppercase mb-1">Blended PAR%</div>
                                <div className={`text-2xl font-bold ${productMixData.metric.par30 > 2.5 ? 'text-rose-600' : 'text-emerald-600'}`}>
                                    {productMixData.metric.par30}%
                                </div>
                            </div>
                        </div>

                        {/* 2. Detailed Table */}
                        <div className="col-span-1 lg:col-span-2 overflow-x-auto">
                            <table className="w-full text-left text-sm">
                                <thead className="bg-secondary-50 text-secondary-500 border-b border-secondary-200">
                                    <tr>
                                        <th className="py-3 px-4 font-semibold">Product Name</th>
                                        <th className="py-3 px-4 font-semibold text-right">Start Date</th>
                                        <th className="py-3 px-4 font-semibold text-right">GLP Contribution</th>
                                        <th className="py-3 px-4 font-semibold text-right">Amount (Cr)</th>
                                        <th className="py-3 px-4 font-semibold text-right">PAR (%)</th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-secondary-100">
                                    {productMixData.mix.sort((a, b) => b.glp - a.glp).map((prod, idx) => {
                                        const share = ((prod.glp / productMixData.metric.glp) * 100).toFixed(1);
                                        return (
                                            <tr key={idx} className="hover:bg-secondary-50 transition-colors">
                                                <td className="py-3 px-4 font-medium text-secondary-900">{prod.name}</td>
                                                <td className="py-3 px-4 text-secondary-500 text-right">Jan 2024</td>
                                                <td className="py-3 px-4 text-right">
                                                    <div className="flex items-center justify-end gap-2">
                                                        <span className="text-xs text-secondary-500">{share}%</span>
                                                        <div className="w-16 bg-secondary-100 h-1.5 rounded-full overflow-hidden">
                                                            <div className="bg-primary-500 h-full" style={{ width: `${share}%` }}></div>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td className="py-3 px-4 text-secondary-900 font-bold text-right">₹{prod.glp.toFixed(2)}</td>
                                                <td className="py-3 px-4 text-right">
                                                    <span className={`inline-block px-2 py-0.5 rounded text-xs font-bold ${prod.par30 < 2 ? 'bg-emerald-100 text-emerald-700' :
                                                        prod.par30 < 4 ? 'bg-amber-100 text-amber-700' : 'bg-rose-100 text-rose-700'
                                                        }`}>
                                                        {prod.par30}%
                                                    </span>
                                                </td>
                                            </tr>
                                        );
                                    })}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    );
};

export default BranchDashboard;
