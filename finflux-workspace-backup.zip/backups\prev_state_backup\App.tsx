import { Suspense, lazy } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import Layout from './components/Layout';
import Login from './pages/Login';

// Lazy load dashboard pages to reduce initial bundle size
const HomeDashboard = lazy(() => import('./pages/HomeDashboard'));
const GeoDashboard = lazy(() => import('./pages/GeoDashboard'));
const TrendsDashboard = lazy(() => import('./pages/TrendsDashboard'));
const BranchDashboard = lazy(() => import('./pages/BranchDashboard'));
const PortfolioDashboard = lazy(() => import('./pages/PortfolioDashboard'));

// Simple Loading Component
const LoadingFallback = () => (
    <div className="flex items-center justify-center h-screen bg-slate-50">
        <div className="flex flex-col items-center gap-4">
            <div className="w-12 h-12 border-4 border-primary-200 border-t-primary-600 rounded-full animate-spin"></div>
            <span className="text-secondary-500 font-medium">Loading Dashboard...</span>
        </div>
    </div>
);

function App() {
    return (
        <BrowserRouter>
            <Suspense fallback={<LoadingFallback />}>
                <Routes>
                    <Route path="/login" element={<Login />} />
                    <Route path="/" element={<Layout />}>
                        <Route index element={<Navigate to="/home" replace />} />
                        <Route path="home" element={<HomeDashboard />} />
                        <Route path="geo" element={<GeoDashboard />} />
                        <Route path="trends" element={<TrendsDashboard />} />
                        <Route path="branch" element={<BranchDashboard />} />
                        <Route path="portfolio" element={<PortfolioDashboard />} />
                    </Route>
                </Routes>
            </Suspense>
        </BrowserRouter>
    );
}

export default App;
