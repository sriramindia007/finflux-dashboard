const fs = require('fs');
// Collections Dashboard: header has Coll.Efficiency + Digital% + Overdue
// Cards below: Collection Efficiency + Current Overdue + Digital Collection
// Fix: Replace header badges with 3 UNIQUE metrics:
//   1. Keep: Coll. Efficiency (headline — stays)
//   2. Replace Digital %: → "Non-Starters" (early warning, not in header)
//   3. Replace Overdue:  → "Resolution Rate" (not in header)

const f = 'src/pages/CollectionsDashboard.tsx';
let c = fs.readFileSync(f, 'utf8');

// Check what we have
const headerSection = c.slice(c.indexOf('Efficiency Gauge summary'), c.indexOf('selectedMonth}\n') + 200);
console.log('Header section:', headerSection.slice(0, 500));

// Find exact marker for header stats area lines
const markers = [
    { find: "text-[10px] text-white/70 font-bold uppercase\">Digital %<", idx: 0 },
    { find: "text-[10px] text-white/50\">Cashless<", idx: 0 },
    { find: "text-[10px] text-white/70 font-bold uppercase\">Overdue<", idx: 0 },
    { find: "text-[10px] text-white/50\">PAR carried fwd<", idx: 0 },
];
markers.forEach(m => console.log(m.find.slice(0, 40), '->', c.includes(m.find)));

// Replace Digital % badge in header with "Non-Starters" (unique — not in KPI cards header territory)
// Line ~214-216:
// <div className="text-[10px] text-white/70 font-bold uppercase">Digital %</div>
// <div className="text-2xl font-bold text-cyan-300">{fp(sn(monthData.digitalPct), 1)}</div>
// <div className="text-[10px] text-white/50">Cashless</div>
// Replace with "Non-Starters" / early delinquency count:
c = c.replace(
    'text-[10px] text-white/70 font-bold uppercase">Digital %</div>',
    'text-[10px] text-white/70 font-bold uppercase">Non-Starters</div>'
);
c = c.replace(
    'text-2xl font-bold text-cyan-300">{fp(sn(monthData.digitalPct), 1)}</div>',
    'text-2xl font-bold text-cyan-300">{(monthData.nonStarters || 0).toLocaleString()}</div>'
);
c = c.replace(
    'text-[10px] text-white/50">Cashless</div>',
    'text-[10px] text-white/50">Early delinquency</div>'
);

// Replace Overdue badge in header with "Resolution Rate" (unique)
// Line ~219-221:
c = c.replace(
    'text-[10px] text-white/70 font-bold uppercase">Overdue</div>',
    'text-[10px] text-white/70 font-bold uppercase">Resolution Rate</div>'
);
c = c.replace(
    'text-2xl font-bold text-rose-300">{fc(sn(monthData.overdue), 0)}</div>',
    'text-2xl font-bold text-amber-300">{fp(sn(monthData.resolutionRate), 1)}</div>'
);
c = c.replace(
    'text-[10px] text-white/50">PAR carried fwd</div>',
    'text-[10px] text-white/50">Overdue cured</div>'
);

// Verify changes
console.log('Digital % in header:', (c.match(/Digital %/g) || []).length);
console.log('Overdue in header:', c.includes("uppercase\">Overdue<"));
console.log('Non-Starters in header:', c.includes("uppercase\">Non-Starters<"));
console.log('Resolution Rate in header:', c.includes("uppercase\">Resolution Rate<"));

fs.writeFileSync(f, c, 'utf8');
console.log('Done!');
