import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell, AreaChart, Area } from 'recharts';
import { AlertTriangle, TrendingDown, ShieldAlert, BadgePercent, AlertCircle, ArrowUpRight, ArrowDownRight, FileDown } from 'lucide-react';
import { COMPANY_METRICS, STATES_DATA, COMPANY_HISTORY } from '../data/mfiData';
import { useNavigate } from 'react-router-dom';
import { ALL_STATES_DATA } from '../data/geoDataComplete';

// Trend data adjusted to end at current company metrics (PAR ~3.2%)
// Trend data adjusted to end at current company metrics
const portfolioTrendData = COMPANY_HISTORY.slice(-6).map(m => ({ // Last 6 months
    month: m.month,
    par30: m.par30,
    par90: m.par90,
    par180: m.par180 || (m.par90 * 0.4), // Fallback if missing, though it should be there
    npa: m.par90, // Assuming NPA tracks with PAR90 for this view
    collectionEff: (m.collection / m.collectionDue * 100)
}));

// Calculated from Metrics
// Calculated from Metrics
const cm = COMPANY_METRICS;
const sma2 = Math.max(0, cm.par60 - cm.par90); // 61-90
const sma1 = Math.max(0, cm.par30 - cm.par60); // 31-60
const sma0 = 4.2; // Estimated 1-30 days (Static for now as we don't track PAR 1)
const hardcore = parseFloat((cm.par90 * 0.4).toFixed(2)); // PAR 180+ (Hardcore Risk)
const npa = parseFloat((cm.par90 - hardcore).toFixed(2)); // NPA (90-179)
const regular = 100 - (sma0 + sma1 + sma2 + cm.par90);

const riskBuckets = [
    { name: 'Regular', value: parseFloat(regular.toFixed(2)), color: '#10b981' },
    { name: 'SMA 0 (1-30)', value: sma0, color: '#f59e0b' },
    { name: 'SMA 1 (31-60)', value: parseFloat(sma1.toFixed(2)), color: '#f97316' },
    { name: 'SMA 2 (61-90)', value: parseFloat(sma2.toFixed(2)), color: '#ef4444' },
    { name: 'NPA (90-179)', value: npa, color: '#b91c1c' },
    { name: 'Hardcore (180+)', value: hardcore, color: '#7e22ce' },
];

// Use ALL_STATES_DATA (rolled up) for table consistency
const stateWiseRisk = ALL_STATES_DATA.map((state) => ({
    state: state.name,
    par: state.par30 || 0,
    par90: state.par90 || 0,
    par180: state.par180 || 0,
    glp: state.glp,
    writeOff: state.writeOff || 0,
    risk: (state.par30 || 0) > 3.0 ? 'High' : (state.par30 || 0) > 1.5 ? 'Medium' : 'Low'
})).sort((a, b) => b.par - a.par); // Sort by risk (high to low)

const PortfolioDashboard = () => {
    const navigate = useNavigate();

    // Calculate real-time efficiencies
    const mtdEfficiency = (COMPANY_METRICS.mtdCollection / COMPANY_METRICS.mtdCollectionDue * 100).toFixed(2);
    const writeOffVal = COMPANY_METRICS.ytdWriteoff;

    // Handle State Analysis - Navigate to Branch Dashboard filtered by state
    const handleAnalyze = (stateName: string) => {
        navigate(`/branch?state=${encodeURIComponent(stateName)}`);
    };

    // Handle Full Report Download
    const handleDownloadReport = () => {
        const headers = ['State', 'Portfolio (GLP)', 'PAR 30+', 'PAR 90+', 'PAR 180+', 'Write-offs (YTD)', 'Risk Level'];
        const rows = stateWiseRisk.map(row => [
            row.state,
            `₹${row.glp.toLocaleString()} Cr`,
            `${row.par.toFixed(2)}%`,
            `${row.par90.toFixed(2)}%`,
            `${row.par180.toFixed(2)}%`,
            `₹${row.writeOff.toFixed(2)} Cr`,
            row.risk
        ]);

        const csvContent = [
            headers.join(','),
            ...rows.map(row => row.join(','))
        ].join('\n');

        const blob = new Blob([csvContent], { type: 'text/csv' });
        const url = window.URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `Portfolio_Risk_Report_${new Date().toISOString().slice(0, 10)}.csv`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        window.URL.revokeObjectURL(url);
    };

    return (
        <div className="space-y-6">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                    <h2 className="text-2xl font-bold text-secondary-900">Portfolio Quality</h2>
                    <p className="text-secondary-500">Risk monitoring and asset quality analysis (Real-time)</p>
                </div>
                <div className="flex items-center gap-3">
                    <span className="text-sm font-medium text-secondary-600">As of:</span>
                    <select className="bg-white border border-secondary-300 rounded-lg px-3 py-2 text-sm text-secondary-700 font-medium shadow-sm">
                        <option>Dec 2025</option>
                        <option>Nov 2025</option>
                    </select>
                </div>
            </div>

            {/* Top Level Risk Metrics - Synced with mfiData.ts */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
                {[
                    { title: 'Portfolio at Risk (PAR 30+)', value: `${COMPANY_METRICS.parOver30}%`, change: '+0.3%', trend: 'up', icon: AlertTriangle, color: 'text-amber-600', bg: 'bg-amber-50' },
                    { title: 'GNPA (90+)', value: '0.8%', change: '+0.1%', trend: 'up', icon: ShieldAlert, color: 'text-rose-600', bg: 'bg-rose-50' },
                    { title: 'Hardcore Risk (180+)', value: `${(COMPANY_METRICS.par90 * 0.4).toFixed(2)}%`, change: '+0.05%', trend: 'up', icon: AlertTriangle, color: 'text-purple-600', bg: 'bg-purple-50' },
                    { title: 'Collection Efficiency', value: `${mtdEfficiency}%`, change: '-0.3%', trend: 'down', icon: BadgePercent, color: 'text-blue-600', bg: 'bg-blue-50' },
                    { title: 'Write-offs (YTD)', value: `₹${writeOffVal} Cr`, change: '0%', trend: 'flat', icon: TrendingDown, color: 'text-slate-600', bg: 'bg-slate-50' },
                ].map((metric, idx) => (
                    <div key={idx} className="bg-white p-5 rounded-xl border border-secondary-200 shadow-sm hover:shadow-md transition-shadow">
                        <div className="flex justify-between items-start mb-4">
                            <div className={`p-2.5 rounded-lg ${metric.bg} ${metric.color}`}>
                                <metric.icon size={20} />
                            </div>
                            <div className={`flex items-center text-xs font-bold px-2 py-1 rounded-full ${metric.trend === 'down' && metric.title.includes('Efficiency') ? 'bg-rose-100 text-rose-700' :
                                metric.trend === 'up' && !metric.title.includes('Efficiency') ? 'bg-rose-100 text-rose-700' :
                                    'bg-emerald-100 text-emerald-700'
                                }`}>
                                {metric.change}
                                {metric.trend === 'up' ? <ArrowUpRight size={14} /> : <ArrowDownRight size={14} />}
                            </div>
                        </div>
                        <div className="text-secondary-500 text-sm font-medium">{metric.title}</div>
                        <div className="text-2xl font-bold text-secondary-900 mt-1">{metric.value}</div>
                    </div>
                ))}
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* PAR Movement Trend */}
                <div className="lg:col-span-2 bg-white p-6 rounded-xl border border-secondary-200 shadow-sm">
                    <h3 className="text-lg font-bold text-secondary-900 mb-6 flex items-center gap-2">
                        <TrendingDown className="text-primary-600" size={20} />
                        Asset Quality Trend (Last 6 Months)
                    </h3>
                    <div className="h-[300px]">
                        <ResponsiveContainer width="100%" height="100%">
                            <AreaChart data={portfolioTrendData}>
                                <defs>
                                    <linearGradient id="colorPar30" x1="0" y1="0" x2="0" y2="1">
                                        <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.1} />
                                        <stop offset="95%" stopColor="#f59e0b" stopOpacity={0} />
                                    </linearGradient>
                                    <linearGradient id="colorNpa" x1="0" y1="0" x2="0" y2="1">
                                        <stop offset="5%" stopColor="#ef4444" stopOpacity={0.1} />
                                        <stop offset="95%" stopColor="#ef4444" stopOpacity={0} />
                                    </linearGradient>
                                    <linearGradient id="colorPar180" x1="0" y1="0" x2="0" y2="1">
                                        <stop offset="5%" stopColor="#7e22ce" stopOpacity={0.1} />
                                        <stop offset="95%" stopColor="#7e22ce" stopOpacity={0} />
                                    </linearGradient>
                                </defs>
                                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                                <XAxis dataKey="month" axisLine={false} tickLine={false} tick={{ fill: '#64748b' }} dy={10} />
                                <YAxis axisLine={false} tickLine={false} tick={{ fill: '#64748b' }} />
                                <Tooltip
                                    contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                                    formatter={(value: number) => `${value.toFixed(2)}%`}
                                />
                                <Legend />
                                <Area type="monotone" dataKey="par30" name="PAR 30+ (%)" stroke="#f59e0b" fillOpacity={1} fill="url(#colorPar30)" strokeWidth={3} />
                                <Area type="monotone" dataKey="npa" name="NPA 90+ (%)" stroke="#ef4444" fillOpacity={1} fill="url(#colorNpa)" strokeWidth={3} />
                                <Area type="monotone" dataKey="par180" name="PAR 180+ (%)" stroke="#7e22ce" fillOpacity={1} fill="url(#colorPar180)" strokeWidth={3} />
                            </AreaChart>
                        </ResponsiveContainer>
                    </div>
                </div>

                {/* Portfolio Composition - Enhanced */}
                <div className="bg-white p-6 rounded-xl border border-secondary-200 shadow-sm">
                    <h3 className="text-lg font-bold text-secondary-900 mb-4 flex items-center gap-2">
                        <AlertCircle className="text-primary-600" size={20} />
                        Portfolio Risk Distribution
                    </h3>
                    <div className="h-[320px] relative">
                        <ResponsiveContainer width="100%" height="100%">
                            <PieChart>
                                <Pie
                                    data={riskBuckets}
                                    cx="50%"
                                    cy="45%"
                                    innerRadius={70}
                                    outerRadius={100}
                                    paddingAngle={3}
                                    dataKey="value"
                                    label={({ name, value }) => `${value}%`}
                                    labelLine={false}
                                >
                                    {riskBuckets.map((entry, index) => (
                                        <Cell key={`cell-${index}`} fill={entry.color} strokeWidth={2} stroke="#fff" />
                                    ))}
                                </Pie>
                                <Tooltip
                                    contentStyle={{
                                        borderRadius: '8px',
                                        border: 'none',
                                        boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)'
                                    }}
                                />
                            </PieChart>
                        </ResponsiveContainer>
                        {/* Center Text */}
                        <div className="absolute top-[40%] left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-center">
                            <div className="text-4xl font-bold text-emerald-600">{riskBuckets[0].value}%</div>
                            <div className="text-sm text-secondary-500 font-semibold">Healthy</div>
                        </div>
                    </div>
                    <div className="mt-2 grid grid-cols-2 gap-2">
                        {riskBuckets.map((bucket, idx) => (
                            <div key={idx} className="flex items-center gap-2 p 2 rounded-lg hover:bg-secondary-50 transition-colors">
                                <div className="w-3 h-3 rounded-sm" style={{ backgroundColor: bucket.color }}></div>
                                <div className="flex-1">
                                    <div className="text-xs text-secondary-600">{bucket.name}</div>
                                    <div className="text-sm font-bold text-secondary-900">{bucket.value}%</div>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </div>

            {/* State Wise Risk Table */}
            <div className="bg-white rounded-xl border border-secondary-200 shadow-sm overflow-hidden">
                <div className="p-6 border-b border-secondary-100 flex justify-between items-center">
                    <h3 className="text-lg font-bold text-secondary-900">Regional Risk Profile</h3>
                    <button
                        onClick={handleDownloadReport}
                        className="flex items-center gap-2 text-sm text-primary-600 font-bold hover:text-primary-700 hover:bg-primary-50 px-3 py-2 rounded-lg transition-colors"
                    >
                        <FileDown size={16} />
                        Download Report
                    </button>
                </div>
                <div className="overflow-x-auto">
                    <table className="w-full text-left text-sm">
                        <thead className="bg-secondary-50 text-secondary-500 font-medium">
                            <tr>
                                <th className="px-6 py-4">State</th>
                                <th className="px-6 py-4">Portfolio (GLP)</th>
                                <th className="px-6 py-4">PAR 30+ %</th>
                                <th className="px-6 py-4">PAR 90+ %</th>
                                <th className="px-6 py-4">PAR 180+ %</th>
                                <th className="px-6 py-4">Write-Offs (YTD)</th>
                                <th className="px-6 py-4">Risk Level</th>
                                <th className="px-6 py-4 text-right">Action</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-secondary-100">
                            {stateWiseRisk.map((row, idx) => (
                                <tr key={idx} className="hover:bg-secondary-50/50 transition-colors">
                                    <td className="px-6 py-4 font-bold text-secondary-900">{row.state}</td>
                                    <td className="px-6 py-4 text-secondary-600">₹{row.glp.toLocaleString()} Cr</td>
                                    <td className="px-6 py-4">
                                        <span className={`px-2 py-1 rounded-md font-bold text-xs ${row.par > 3 ? 'bg-rose-100 text-rose-700' :
                                            row.par > 1.5 ? 'bg-amber-100 text-amber-700' :
                                                'bg-emerald-100 text-emerald-700'
                                            }`}>
                                            {row.par.toFixed(2)}%
                                        </span>
                                    </td>
                                    <td className="px-6 py-4 font-mono text-xs text-secondary-600">
                                        {row.par90.toFixed(2)}%
                                    </td>
                                    <td className="px-6 py-4 font-mono text-xs text-purple-600 font-bold">
                                        {row.par180.toFixed(2)}%
                                    </td>
                                    <td className="px-6 py-4 text-xs text-secondary-600">
                                        ₹{row.writeOff.toFixed(2)} Cr
                                    </td>
                                    <td className="px-6 py-4">
                                        <div className="flex items-center gap-2">
                                            <div className={`w-2 h-2 rounded-full ${row.risk === 'High' ? 'bg-rose-500' :
                                                row.risk === 'Medium' ? 'bg-amber-500' :
                                                    'bg-emerald-500'
                                                }`}></div>
                                            <span className="text-secondary-700 font-medium">{row.risk}</span>
                                        </div>
                                    </td>
                                    <td className="px-6 py-4 text-right">
                                        <button
                                            onClick={() => handleAnalyze(row.state)}
                                            className="text-xs font-bold text-primary-600 border border-primary-200 px-3 py-1.5 rounded-lg hover:bg-primary-50 hover:border-primary-300 transition-all"
                                        >
                                            Analyze →
                                        </button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
};

export default PortfolioDashboard;
