const fs = require('fs');
const f = 'src/pages/PortfolioDashboard.tsx';
let c = fs.readFileSync(f, 'utf8');

// Portfolio header badges: PAR 30+ (duplicate), GNPA 90+ (duplicate), Audit Score (unique)
// Fix: 
//  PAR 30+ → "Loan at Risk" (rupee amount = par30 * GLP / 100) — different framing from the % card
//  GNPA 90+ → keep (it's fine, gives % context quickly)
//  Audit Score → keep (unique)
// But to also eliminate the GNPA duplicate: replace GNPA header with "Write-offs YTD" rupee amount

// Step 1: Replace PAR 30+ header badge with "Loan at Risk (₹ Cr)"
// Need to add glp variable from COMPANY_METRICS to compute this
// Check if GLP already available in the component scope
if (!c.includes('const glp =')) {
    // Add after par180 computation
    c = c.replace(
        'const writeOffVal = COMPANY_METRICS.ytdWriteoff;',
        'const writeOffVal = COMPANY_METRICS.ytdWriteoff;\n    const currentGLP = COMPANY_METRICS.grossLoanPortfolio || 8725;'
    );
}

// Replace PAR 30+ header badge
c = c.replace(
    `<div className="text-xs text-white/60">PAR 30+</div>
                            <div className="text-xl font-bold text-amber-300">{par30.toFixed(2)}%</div>`,
    `<div className="text-xs text-white/60">Loan at Risk</div>
                            <div className="text-xl font-bold text-amber-300">₹{(currentGLP * par30 / 100).toFixed(0)} Cr</div>`
);

// Replace GNPA (90+) header badge with Write-offs YTD (₹ Cr) — unique framing
c = c.replace(
    `<div className="text-xs text-white/60">GNPA (90+)</div>
                            <div className="text-xl font-bold text-rose-300">{par90.toFixed(2)}%</div>`,
    `<div className="text-xs text-white/60">Write-offs YTD</div>
                            <div className="text-xl font-bold text-rose-300">₹{writeOffVal.toFixed(0)} Cr</div>`
);

// Verify
console.log('PAR 30+ in header:', c.includes('"text-xs text-white/60">PAR 30+<'));
console.log('GNPA in header:', c.includes('"text-xs text-white/60">GNPA'));
console.log('Loan at Risk in header:', c.includes('"text-xs text-white/60">Loan at Risk<'));
console.log('Write-offs YTD in header:', c.includes('"text-xs text-white/60">Write-offs YTD<'));
console.log('currentGLP added:', c.includes('const currentGLP'));

fs.writeFileSync(f, c, 'utf8');
console.log('PortfolioDashboard header fixed!');
