const fs = require('fs');
const f = 'src/pages/TrendsDashboard.tsx';
let c = fs.readFileSync(f, 'utf8');

// FIX: ₹35,000 avg ticket = 0.0035 Cr (not 0.000035 Cr)
// newDisbCount = disbursement_Cr / 0.0035 Cr_per_loan (gives loan count)
// newCustomersK = loan_count / 1000 (gives thousands)
// Example: 950 Cr / 0.0035 = 271,428 loans = ~271k
c = c.replace(
    '    const newDisbCount = Math.round((m.disbursement / 0.000035)); // avg ticket ₹35k = 0.000035 Cr\n    const newCustomersK = Math.round(newDisbCount / 1000);',
    '    // avg ticket ₹35,000 = 0.0035 Cr; disbursement_Cr / 0.0035 = loan count; / 1000 = thousands\n    const newCustomersK = Math.round(m.disbursement / 0.0035 / 1000);'
);

// Check fix applied
console.log('Fix applied:', c.includes('/ 0.0035 / 1000'));
fs.writeFileSync(f, c, 'utf8');
