const fs = require('fs');
const f = 'src/pages/PortfolioDashboard.tsx';
let c = fs.readFileSync(f, 'utf8');
const lines = c.split('\n');

let inHeader = false;
let par30BadgeStart = -1, par30BadgeEnd = -1;
let gnpaBadgeStart = -1, gnpaBadgeEnd = -1;

for (let i = 0; i < lines.length; i++) {
    // Find header section (dark background gradient div)
    if (lines[i].includes('from-slate-700') && lines[i].includes('via-rose-900')) inHeader = true;
    if (inHeader && lines[i].includes('</div>') && i > 270) { inHeader = false; break; }

    if (inHeader) {
        const l = lines[i].trim();
        if (l.includes('>PAR 30+<') && par30BadgeStart === -1) {
            // Find the containing div (go back up)
            for (let j = i; j >= i - 3; j--) {
                if (lines[j].trim().startsWith('<div') && lines[j].includes('bg-white/10')) {
                    par30BadgeStart = j; break;
                }
            }
            par30BadgeEnd = i + 2; // roughly 3 lines per badge
        }
        if (l.includes('>GNPA (90+)<') && gnpaBadgeStart === -1) {
            for (let j = i; j >= i - 3; j--) {
                if (lines[j].trim().startsWith('<div') && lines[j].includes('bg-white/10')) {
                    gnpaBadgeStart = j; break;
                }
            }
            gnpaBadgeEnd = i + 2;
        }
    }
}

console.log('PAR 30+ badge:', par30BadgeStart, '->', par30BadgeEnd);
if (par30BadgeStart >= 0) console.log('context:', lines.slice(par30BadgeStart, par30BadgeEnd + 1).map((l, i) => (par30BadgeStart + i) + ': ' + l));
console.log('GNPA badge:', gnpaBadgeStart, '->', gnpaBadgeEnd);
if (gnpaBadgeStart >= 0) console.log('context:', lines.slice(gnpaBadgeStart, gnpaBadgeEnd + 1).map((l, i) => (gnpaBadgeStart + i) + ': ' + l));
