const fs = require('fs');
const path = require('path');

function processDir(dir) {
    const files = fs.readdirSync(dir);
    for (const file of files) {
        const fullPath = path.join(dir, file);
        if (fs.statSync(fullPath).isDirectory()) {
            processDir(fullPath);
        } else if (fullPath.endsWith('.tsx')) {
            let content = fs.readFileSync(fullPath, 'utf8');
            let modified = false;

            // Notice we also add the parent containers: AreaChart, BarChart, LineChart, PieChart
            const patterns = [
                /<(AreaChart|BarChart|LineChart|PieChart|Area|Bar|Line|Pie) /g,
                /<(AreaChart|BarChart|LineChart|PieChart|Area|Bar|Line|Pie)>/g
            ];

            let newContent = content;
            for (const p of patterns) {
                newContent = newContent.replace(p, (match, tag) => {
                    // Skip 'BarChart2' icon and already-animated ones
                    if (tag === 'BarChart2' || match.includes('isAnimationActive')) return match;

                    modified = true;
                    // match is either "<Tag " or "<Tag>"
                    if (match.endsWith('>')) {
                        return `<${tag} isAnimationActive={false}>`;
                    }
                    return `<${tag} isAnimationActive={false} `;
                });
            }

            if (modified) {
                fs.writeFileSync(fullPath, newContent);
                console.log(`Fixed missing chart animations in ${file}`);
            }
        }
    }
}

processDir(path.join(__dirname, 'src/pages'));
processDir(path.join(__dirname, 'src/components'));
console.log('Done deep-fixing charts');
