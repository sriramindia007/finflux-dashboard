import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import Layout from './components/Layout';
import Login from './pages/Login';
import HomeDashboard from './pages/HomeDashboard';
import ProductDashboard from './pages/ProductDashboard';
import GeoDashboard from './pages/GeoDashboard';
import TrendsDashboard from './pages/TrendsDashboard';
import BranchDashboard from './pages/BranchDashboard';
import PortfolioQualityDashboard from './pages/PortfolioQualityDashboard';

function App() {
    return (
        <BrowserRouter>
            <Routes>
                <Route path="/login" element={<Login />} />
                <Route path="/" element={<Layout />}>
                    <Route index element={<Navigate to="/home" replace />} />
                    <Route path="home" element={<HomeDashboard />} />
                    <Route path="products" element={<ProductDashboard />} />
                    <Route path="geo" element={<GeoDashboard />} />
                    <Route path="trends" element={<TrendsDashboard />} />
                    <Route path="branch" element={<BranchDashboard />} />
                    <Route path="portfolio" element={<PortfolioQualityDashboard />} />
                </Route>
            </Routes>
        </BrowserRouter>
    );
}

export default App;
