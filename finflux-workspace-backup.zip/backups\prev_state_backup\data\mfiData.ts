/**
 * FINFLUX Analytics - Centralized Data Engine
 * Contains Month-wise data (Jan-Dec 2025) for all hierarchy levels.
 * Single Source of Truth for all Dashboards.
 */

export type Month = 'Jan' | 'Feb' | 'Mar' | 'Apr' | 'May' | 'Jun' | 'Jul' | 'Aug' | 'Sep' | 'Oct' | 'Nov' | 'Dec';
export const MONTHS: Month[] = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

export interface MonthlyMetric {
    month: Month;
    glp: number;            // Portfolio (Cr)
    disbursement: number;   // Cr
    collection: number;     // Cr
    collectionDue: number;  // Cr
    par30: number;          // %
    par90: number;          // %
    activeClients: number;  // Count
}

// ------------------------------------------------------------------
// PRODUCT TAXONOMY & MIX DEFINITIONS
// ------------------------------------------------------------------

export type ProductType =
    | 'Group Loans (JLG)'
    | 'MSME Business'
    | 'JIT (Emergency)'
    | 'Samarth (PwD)'
    | 'Swasth (WASH)'
    | 'Housing'
    | 'Green/Climate'
    | 'Consumer Durable'
    | 'Solar/EV';

export const PRODUCTS_CONFIG: Record<ProductType, { label: string, share: number, risk: number }> = {
    'Group Loans (JLG)': { label: 'Group Loans (JLG)', share: 0.55, risk: 1.0 },       // 55% share, Base risk
    'MSME Business': { label: 'MSME Business', share: 0.15, risk: 1.5 },               // 15% share, Higher risk
    'Housing': { label: 'Housing Loan', share: 0.12, risk: 0.6 },                      // 12% share, Low risk
    'JIT (Emergency)': { label: 'JIT (Just In Time)', share: 0.05, risk: 0.8 },
    'Samarth (PwD)': { label: 'Samarth (PwD)', share: 0.03, risk: 0.7 },
    'Swasth (WASH)': { label: 'Swasth (Water/Sanitation)', share: 0.03, risk: 0.5 },
    'Green/Climate': { label: 'Green Box/Climate', share: 0.03, risk: 0.9 },
    'Consumer Durable': { label: 'Consumer Durable', share: 0.02, risk: 1.2 },
    'Solar/EV': { label: 'Rooftop Solar & EV', share: 0.02, risk: 1.1 }
};

export interface ProductMetric {
    name: ProductType;
    glp: number;      // Cr
    clients: number;
    par30: number;    // %
}

// Generate a breakdown for a given Total GLP and Base PAR
export const generateProductMix = (totalGLP: number, basePAR: number): ProductMetric[] => {
    return Object.keys(PRODUCTS_CONFIG).map((key) => {
        const type = key as ProductType;
        const config = PRODUCTS_CONFIG[type];

        // Random variance in share (+/- 10% relative)
        const variance = 1 + ((Math.random() * 0.2) - 0.1);
        const productGLP = totalGLP * config.share * variance;

        // PAR varies by product risk profile
        const productPAR = basePAR * config.risk * (0.9 + Math.random() * 0.2);

        // Assume varying loan sizes for client count derivation
        const avgLoanSize = type === 'Housing' ? 0.003 : type === 'MSME Business' ? 0.001 : 0.00035; // in Cr

        return {
            name: type,
            glp: parseFloat(productGLP.toFixed(2)),
            clients: Math.floor(productGLP / avgLoanSize),
            par30: parseFloat(productPAR.toFixed(2))
        };
    });
};

// ------------------------------------------------------------------
// 1. DATA GENERATION UTILITIES (Deterministic Simulation)
// ------------------------------------------------------------------

// Base growth factors to simulate realistic MFI trends
const SEASONALITY = {
    Jan: 0.9, Feb: 0.95, Mar: 1.1,  // Q4 Push
    Apr: 0.85, May: 0.9, Jun: 0.95, // New FY Slump
    Jul: 1.0, Aug: 1.05, Sep: 1.1,  // Post-Monsoon pickup
    Oct: 1.15, Nov: 1.2, Dec: 1.25  // Festive High
};

// Generate a year's history based on a target End-of-Year value and a growth curve
const generateHistory = (targetGLP: number, basePAR: number): MonthlyMetric[] => {
    const history: MonthlyMetric[] = [];
    let currentGLP = targetGLP * 0.75; // Start year at 75% of target

    MONTHS.forEach((month, idx) => {
        const growthFactor = SEASONALITY[month];

        // GLP grows steadily with seasonal bumps
        currentGLP = currentGLP * (1 + (0.02 * growthFactor));

        // Disbursement is derived from GLP growth + Churn replacement
        const disb = (currentGLP * 0.15 * growthFactor);

        // Collection is ~98% of what's due, which is ~12% of GLP
        const due = currentGLP * 0.12;
        const coll = due * (0.96 + (Math.random() * 0.03)); // 96-99% efficiency

        // PAR fluctuates
        const par30 = basePAR + (Math.sin(idx) * 0.2) + (Math.random() * 0.1);
        const par90 = par30 * 0.3;

        history.push({
            month,
            glp: parseFloat(currentGLP.toFixed(2)),
            disbursement: parseFloat(disb.toFixed(2)),
            collection: parseFloat(coll.toFixed(2)),
            collectionDue: parseFloat(due.toFixed(2)),
            par30: parseFloat(par30.toFixed(2)),
            par90: parseFloat(par90.toFixed(2)),
            activeClients: Math.floor(currentGLP * 250) // ~25k loan size avg
        });
    });

    return history;
};

// ------------------------------------------------------------------
// 2. CENTRAL DATA STORE
// ------------------------------------------------------------------

// State Targets (Dec 2025)
const STATE_TARGETS = {
    'Odisha': { glp: 3400, par: 2.8 },
    'Karnataka': { glp: 2100, par: 3.1 },
    'Andhra Pradesh': { glp: 1700, par: 3.5 },
    'Madhya Pradesh': { glp: 850, par: 3.8 },
    'Tamil Nadu': { glp: 450, par: 2.5 },
};

// Generate State Histories
export const STATE_HISTORY: Record<string, MonthlyMetric[]> = {};
Object.entries(STATE_TARGETS).forEach(([state, target]) => {
    STATE_HISTORY[state] = generateHistory(target.glp, target.par);
});

// Generate Company History (Aggregation of States)
export const COMPANY_HISTORY: MonthlyMetric[] = MONTHS.map((month, idx) => {
    const metric: MonthlyMetric = {
        month,
        glp: 0, disbursement: 0, collection: 0, collectionDue: 0, par30: 0, par90: 0, activeClients: 0
    };

    let totalParWeighted = 0;

    Object.values(STATE_HISTORY).forEach(stateHistory => {
        const stateMonth = stateHistory[idx];
        metric.glp += stateMonth.glp;
        metric.disbursement += stateMonth.disbursement;
        metric.collection += stateMonth.collection;
        metric.collectionDue += stateMonth.collectionDue;
        metric.activeClients += stateMonth.activeClients;
        totalParWeighted += (stateMonth.par30 * stateMonth.glp);
    });

    // Averaging Rates
    metric.par30 = parseFloat((totalParWeighted / metric.glp).toFixed(2));
    metric.par90 = parseFloat((metric.par30 * 0.3).toFixed(2));

    // Floating Point Cleanup
    metric.glp = parseFloat(metric.glp.toFixed(2));
    metric.disbursement = parseFloat(metric.disbursement.toFixed(2));
    metric.collection = parseFloat(metric.collection.toFixed(2));
    metric.collectionDue = parseFloat(metric.collectionDue.toFixed(2));

    return metric;
});

// ------------------------------------------------------------------
// 3. EXPORTED CONSTANTS (Legacy Support + Easy Access)
// ------------------------------------------------------------------

export const CURRENT_MONTH = 'Dec';
const currentIdx = MONTHS.indexOf(CURRENT_MONTH);

export const COMPANY_METRICS = {
    ...COMPANY_HISTORY[currentIdx],
    currentGLP: COMPANY_HISTORY[currentIdx].glp,
    mtdDisbursement: COMPANY_HISTORY[currentIdx].disbursement,
    mtdCollection: COMPANY_HISTORY[currentIdx].collection,
    mtdCollectionDue: COMPANY_HISTORY[currentIdx].collectionDue,
    parOver30: COMPANY_HISTORY[currentIdx].par30,

    // YTD Calculations (Sum of all months up to Dec)
    ytdDisbursement: COMPANY_HISTORY.reduce((sum, m) => sum + m.disbursement, 0),
    ytdDisbursementTarget: 9500,
    ytdCollection: COMPANY_HISTORY.reduce((sum, m) => sum + m.collection, 0),
    ytdCollectionDue: COMPANY_HISTORY.reduce((sum, m) => sum + m.collectionDue, 0),
    ytdWriteoff: 65,
    activeClients: COMPANY_HISTORY[currentIdx].activeClients,
    totalBranches: 3520,

    // Calculated Overdue
    overdueAmount: parseFloat((COMPANY_HISTORY[currentIdx].glp * (COMPANY_HISTORY[currentIdx].par30 / 100)).toFixed(2)),

    // Product Breakdown
    productMix: generateProductMix(COMPANY_HISTORY[currentIdx].glp, COMPANY_HISTORY[currentIdx].par30)
};

// Static Metadata for States
const STATE_META: Record<string, { branches: number; districts: number }> = {
    'Odisha': { branches: 1420, districts: 16 },
    'Karnataka': { branches: 870, districts: 12 },
    'Andhra Pradesh': { branches: 710, districts: 11 },
    'Madhya Pradesh': { branches: 350, districts: 8 },
    'Tamil Nadu': { branches: 170, districts: 5 },
};

// Helper for State Data Access
export const getStatesData = () => {
    const states: any = {};
    Object.keys(STATE_HISTORY).forEach(key => {
        let id = key.toLowerCase().replace(/\s/g, '');

        // Map to legacy keys for compatibility
        if (id === 'andhrapradesh') id = 'andhra';
        if (id === 'madhyapradesh') id = 'madhyaPradesh';
        if (id === 'tamilnadu') id = 'tamilNadu';

        const hist = STATE_HISTORY[key];
        const curr = hist[currentIdx];
        const meta = STATE_META[key];

        states[id] = {
            name: key,
            glp: curr.glp,
            par30: curr.par30,
            par90: curr.par90,
            activeClients: curr.activeClients,
            mtdDisbursement: curr.disbursement,
            mtdCollection: curr.collection,
            mtdCollectionDue: curr.collectionDue,
            ytdDisbursement: hist.reduce((sum, m) => sum + m.disbursement, 0),
            ytdCollection: hist.reduce((sum, m) => sum + m.collection, 0),
            ytdCollectionDue: hist.reduce((sum, m) => sum + m.collectionDue, 0),
            branches: meta.branches,
            districts: meta.districts,
            productMix: generateProductMix(curr.glp, curr.par30), // Mix for State
            history: hist // Full history access
        };
    });
    return states;
};

export const STATES_DATA = getStatesData();

// ------------------------------------------------------------------
// 4. BRANCH & CENTRE GENERATORS (Drill Down Support)
// ------------------------------------------------------------------

// Deterministically generate history for ANY branch ID
export const getBranchHistory = (branchId: string, baseGLP: number, basePAR: number) => {
    return generateHistory(baseGLP, basePAR);
};

// Export formatted helpers
export const formatCurrency = (value: number) => {
    if (value >= 10000) return `₹${(value / 10000).toFixed(1)} L`;
    if (value >= 100) return `₹${value.toFixed(1)} Cr`;
    return `₹${value.toFixed(2)} Cr`;
};

// Top 20 Branches across India (by GLP) - Static Data for Table
export const TOP_BRANCHES = [
    { name: 'Bhubaneswar Urban', state: 'Odisha', district: 'Bhubaneswar', glp: 50.0, activeLoans: 12000, par30: 1.8 },
    { name: 'Tangi', state: 'Odisha', district: 'Khordha', glp: 47.5, activeLoans: 11000, par30: 1.5 },
    { name: 'Bagheitangi', state: 'Odisha', district: 'Khordha', glp: 45.0, activeLoans: 10500, par30: 1.2 },
    { name: 'Cuttack Central', state: 'Odisha', district: 'Cuttack', glp: 40.0, activeLoans: 9500, par30: 2.1 },
    { name: 'Puri Town', state: 'Odisha', district: 'Puri', glp: 37.5, activeLoans: 9000, par30: 2.3 },
    { name: 'Bangalore Central', state: 'Karnataka', district: 'Bangalore', glp: 42.0, activeLoans: 10000, par30: 2.0 },
    { name: 'Mysore City', state: 'Karnataka', district: 'Mysore', glp: 38.5, activeLoans: 9200, par30: 2.4 },
    { name: 'Vijayawada Central', state: 'Andhra Pradesh', district: 'Vijayawada', glp: 44.0, activeLoans: 10500, par30: 3.0 },
    { name: 'Indore Central', state: 'Madhya Pradesh', district: 'Indore', glp: 28.0, activeLoans: 6700, par30: 3.8 },
    { name: 'Chennai T Nagar', state: 'Tamil Nadu', district: 'Chennai', glp: 30.0, activeLoans: 7200, par30: 2.2 },
];
