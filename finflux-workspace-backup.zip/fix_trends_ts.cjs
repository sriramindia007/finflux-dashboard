const fs = require('fs');
const f = 'src/pages/TrendsDashboard.tsx';
let c = fs.readFileSync(f, 'utf8');

// Fix 1: getQuarterlyData return type - quarterly items don't have rawMonth, change filter to cast
c = c.replace(
    '}).filter(Boolean) as typeof trendsData;',
    '}).filter(Boolean) as any[];'
);

// Fix 2: collEff in quarterly is string (toFixed returns string), should be number
c = c.replace(
    "collEff: parseFloat(subset.reduce((s, m) => s + m.collEff, 0) / subset.length).toFixed(2),",
    "collEff: parseFloat((subset.reduce((s, m) => s + Number(m.collEff), 0) / subset.length).toFixed(2)),"
);

fs.writeFileSync(f, c, 'utf8');
console.log('Fixed TS errors');
