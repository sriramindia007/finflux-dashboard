const fs = require('fs');
const path = require('path');
const dir = path.join(__dirname, 'src', 'pages');

const files = fs.readdirSync(dir).filter(f => f.endsWith('Dashboard.tsx'));
files.forEach(file => {
    const p = path.join(dir, file);
    let contents = fs.readFileSync(p, 'utf8');

    // Look for: h: \`${(slice.h / 810) * 100}%\`
    // And replace with: h: `${(slice.h / 810) * 100}%`

    const badStr = "h: \\`${(slice.h / 810) * 100}%\\`";
    const goodStr = "h: `${(slice.h / 810) * 100}%`";

    if (contents.includes(badStr)) {
        contents = contents.split(badStr).join(goodStr);
        fs.writeFileSync(p, contents);
        console.log('Fixed backticks in', file);
    }
});
