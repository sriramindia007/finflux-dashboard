import { useState, useMemo } from 'react';
import {
    BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip,
    ResponsiveContainer, Legend, Cell, ReferenceLine, PieChart, Pie
} from 'recharts';
import {
    TrendingUp, TrendingDown, AlertTriangle, CheckCircle2, Smartphone,
    Banknote, Target, Activity, AlertCircle, RefreshCw, ShieldAlert,
    Download, Camera
} from 'lucide-react';
import { saveFile, exportToPDF, exportToPPT } from '../lib/utils';
import { useRef } from 'react';
import {
    COLLECTIONS_HISTORY, CURRENT_COLLECTIONS, HIGH_RISK_CENTRES,
    type CollectionMetric
} from '../data/financeData';
import { COMPANY_HISTORY, MONTHS, type Month } from '../data/mfiData';
import { ALL_STATES_DATA } from '../data/geoDataComplete';
import KPICard from '../components/KPICard';
import { cn } from '../lib/utils';

// ── Formatting Helpers ──────────────────────────────────────────────────────
const fc = (v: number, d = 2) => `₹${v.toFixed(d)} Cr`;
const fp = (v: number, d = 2) => `${v.toFixed(d)}%`;
const sn = (v: number | undefined, fallback = 0) =>
    v === undefined || isNaN(v) || !isFinite(v) ? fallback : v;

const DPD_COLORS = [
    '#f59e0b',  // 1-30  amber — watch
    '#f97316',  // 31-60 orange — concern
    '#ef4444',  // 61-90 red — serious
    '#b91c1c',  // 91-180 dark red — critical
    '#7f1d1d',  // 180+  very dark — NPA
];

const CollectionsDashboard = () => {
    const exportRef = useRef<HTMLDivElement>(null);
    const [selectedMonth, setSelectedMonth] = useState<Month>('Feb'); // Feb 2026 = current
    const [selectedState, setSelectedState] = useState<string>('All');

    const monthData: CollectionMetric = useMemo(() => {
        return COLLECTIONS_HISTORY.find(m => m.month === selectedMonth) || CURRENT_COLLECTIONS;
    }, [selectedMonth]);

    // State-wise collection efficiency from geo data
    const stateCollectionData = useMemo(() => {
        return ALL_STATES_DATA.map(s => {
            const par30 = s.par30 || 2.5;
            const eff = Math.max(92, 99.2 - par30 * 0.8);
            return {
                name: s.name,
                efficiency: parseFloat(eff.toFixed(1)),
                par30,
                glp: s.glp || 0,
                overdue: parseFloat(((s.glp || 0) * (par30 / 100)).toFixed(2))
            };
        }).sort((a, b) => a.efficiency - b.efficiency);
    }, []);

    // 12-month trend: demand vs collected
    const trendData = useMemo(() => {
        return COLLECTIONS_HISTORY.map(m => ({
            month: m.month,
            Scheduled: parseFloat(m.scheduled.toFixed(2)),
            Collected: parseFloat(m.collected.toFixed(2)),
            efficiency: m.efficiency,
            overdue: parseFloat(m.overdue.toFixed(2))
        }));
    }, []);

    // Digital vs Cash trend
    const paymentTrendData = useMemo(() => COLLECTIONS_HISTORY.map(m => ({
        month: m.month,
        Digital: parseFloat(m.digitalCollection.toFixed(2)),
        Cash: parseFloat(m.cashCollection.toFixed(2)),
        digitalPct: m.digitalPct
    })), []);

    // Resolution rate trend
    const resolutionTrend = useMemo(() => COLLECTIONS_HISTORY.map(m => ({
        month: m.month,
        'Resolution Rate': m.resolutionRate,
        'Recovery (NPA)': parseFloat(m.recoveryFromNPA.toFixed(2))
    })), []);

    const filteredRiskCentres = useMemo(() =>
        selectedState === 'All'
            ? HIGH_RISK_CENTRES
            : HIGH_RISK_CENTRES.filter(c => c.state === selectedState),
        [selectedState]
    );

    const prevMonth = COLLECTIONS_HISTORY[MONTHS.indexOf(selectedMonth) - 1];

    // ── Export Logic ──
    const getFilename = (ext: string) => `FINFLUX_Collections_${selectedMonth}_2025.${ext}`;

    const handleExportExcel = async () => {
        const XLSX = await import('xlsx');

        const summaryRows = [
            ['FINFLUX ANALYTICS - COLLECTIONS & RECOVERY REPORT'],
            ['Month', selectedMonth, '2025'],
            [''],
            ['Overall KPI', 'Value'],
            ['Collection Efficiency', `${sn(monthData.efficiency)}%`],
            ['MTD Scheduled (Cr)', fc(sn(monthData.scheduled))],
            ['MTD Collected (Cr)', fc(sn(monthData.collected))],
            ['Current Overdue (Cr)', fc(sn(monthData.overdue))],
            ['Resolution Rate', `${sn(monthData.resolutionRate)}%`],
            ['Digital Collection', `${sn(monthData.digitalPct)}%`],
            ['Non-Starters', sn(monthData.nonStarters)]
        ];

        const stateRows = [
            ['State-wise Collection Breakup'],
            [],
            ['State', 'Collection Efficiency (%)', 'PAR 30 (%)', 'GLP (Cr)', 'Overdue (Cr)'],
            ...stateCollectionData.map(r => [r.name, r.efficiency, r.par30, r.glp, r.overdue])
        ];

        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(summaryRows), "Summary");
        XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(stateRows), "State Breakup");
        const out = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
        saveFile(new Blob([out], { type: 'application/octet-stream' }), getFilename('xlsx'));
    };


    const handleExportPDF = async () => {
        if (!exportRef.current) return;
        try { await exportToPDF([exportRef as React.RefObject<HTMLElement>], getFilename('pdf')); }
        catch (e) { console.error(e); alert('Error generating PDF.'); }
    };

    const handleExportPPT = async () => {
        if (!exportRef.current) return;
        try { await exportToPPT([exportRef as React.RefObject<HTMLElement>], getFilename('pptx')); }
        catch (e) { console.error(e); alert('Error generating PPT.'); }
    };


    return (
        <div ref={exportRef} className="space-y-6">
            {/* ── FINFLUX Branded Header ─────────────────────────────────── */}
            <div className="bg-gradient-to-r from-emerald-700 via-teal-600 to-cyan-600 rounded-xl p-5 text-white shadow-lg">
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                    <div>
                        <div className="text-xs font-bold uppercase tracking-widest text-emerald-200 mb-1">FINFLUX Analytics · Collections & Recovery</div>
                        <h2 className="text-2xl font-bold">Demand ↔ Collection · DPD Buckets · Recovery</h2>
                        <p className="text-emerald-200 text-sm mt-1">FY 2025-26 · Data as of <strong>{selectedMonth} {['Jan', 'Feb', 'Mar'].includes(selectedMonth) ? '2026' : '2025'}</strong> · All figures in ₹ Crore</p>
                    </div>
                    <div className="flex items-center gap-3 flex-wrap">
                        {/* Efficiency Gauge summary */}
                        <div className="bg-white/10 border border-white/20 rounded-lg px-4 py-2 text-center">
                            <div className="text-[10px] text-white/70 font-bold uppercase">Coll. Efficiency</div>
                            <div className={cn('text-2xl font-bold',
                                sn(monthData.efficiency) >= 98 ? 'text-emerald-300' :
                                    sn(monthData.efficiency) >= 96 ? 'text-amber-200' : 'text-rose-300'
                            )}>{fp(sn(monthData.efficiency), 1)}</div>
                            <div className="text-[10px] text-white/50">Target: 99.0%</div>
                        </div>
                        <div className="bg-white/10 border border-white/20 rounded-lg px-4 py-2 text-center">
                            <div className="text-[10px] text-white/70 font-bold uppercase">Non-Starters</div>
                            <div className="text-2xl font-bold text-cyan-300">{(monthData.nonStarters || 0).toLocaleString()}</div>
                            <div className="text-[10px] text-white/50">Early delinquency</div>
                        </div>
                        <div className="bg-white/10 border border-white/20 rounded-lg px-4 py-2 text-center">
                            <div className="text-[10px] text-white/70 font-bold uppercase">Resolution Rate</div>
                            <div className="text-2xl font-bold text-amber-300">{fp(sn(monthData.resolutionRate), 1)}</div>
                            <div className="text-[10px] text-white/50">Overdue cured</div>
                        </div>
                        <select
                            className="bg-white/10 border border-white/20 rounded-lg px-3 py-2 text-sm text-white outline-none"
                            value={selectedMonth}
                            onChange={e => setSelectedMonth(e.target.value as Month)}
                        >
                            {MONTHS.map(m => <option key={m} value={m} className="text-secondary-900">{m} {['Jan', 'Feb', 'Mar'].includes(m) ? '2026' : '2025'}</option>)}
                        </select>
                        <div className="relative group z-50">
                            <button className="bg-white/15 border border-white/25 rounded-lg px-3 py-2 text-sm text-white hover:bg-white/25 flex items-center gap-2 transition-colors">
                                <Download size={15} /> Export
                            </button>
                            <div className="absolute right-0 top-full pt-2 w-48 hidden group-hover:block z-[100]">
                                <div className="bg-white/95 backdrop-blur-sm rounded-lg shadow-xl border border-emerald-700/20 overflow-hidden text-left">
                                    <button onClick={handleExportExcel} className="w-full text-left px-4 py-3 text-sm font-medium text-slate-800 hover:bg-teal-50 hover:text-teal-700 transition-colors border-b border-secondary-100 flex justify-between items-center">Excel (.xlsx) <Download size={14} /></button>
                                    <button onClick={handleExportPDF} className="w-full text-left px-4 py-3 text-sm font-medium text-slate-800 hover:bg-teal-50 hover:text-teal-700 transition-colors border-b border-secondary-100 flex justify-between items-center">PDF Screenshot <Camera size={14} /></button>
                                    <button onClick={handleExportPPT} className="w-full text-left px-4 py-3 text-sm font-medium text-slate-800 hover:bg-teal-50 hover:text-teal-700 transition-colors flex justify-between items-center">PPT Screenshot <Camera size={14} /></button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


            {/* ── KPI Row 1: Core Collection Metrics ──────────────────────── */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                <KPICard
                    title="Collection Efficiency"
                    value={fp(sn(monthData.efficiency), 1)}
                    subValue={`Target: 99.0%`}
                    trend={sn(monthData.efficiency) >= 97 ? 'up' : 'down'}
                    trendValue={prevMonth ? `${(sn(monthData.efficiency) - sn(prevMonth.efficiency)).toFixed(1)}% vs last month` : ''}
                    icon={Target}
                    className={cn('border-l-4', sn(monthData.efficiency) >= 98 ? 'border-l-emerald-500' : sn(monthData.efficiency) >= 96 ? 'border-l-amber-500' : 'border-l-rose-500')}
                />
                <KPICard
                    title="MTD Scheduled"
                    value={fc(sn(monthData.scheduled))}
                    subValue="Due this month"
                    icon={Activity}
                    className="border-l-4 border-l-blue-500"
                />
                <KPICard
                    title="MTD Collected"
                    value={fc(sn(monthData.collected))}
                    subValue={`Overdue: ${fc(sn(monthData.overdue))}`}
                    trend="up"
                    icon={CheckCircle2}
                    className="border-l-4 border-l-emerald-500"
                />
                <KPICard
                    title="Current Overdue"
                    value={fc(sn(monthData.overdue))}
                    subValue={`${fp(sn(monthData.dpd[0]?.pct), 2)} of Portfolio`}
                    trend="down"
                    trendValue="PAR 30+"
                    icon={AlertTriangle}
                    className="border-l-4 border-l-rose-500"
                />
            </div>

            {/* ── KPI Row 2: Recovery & Channel ───────────────────────────── */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                <KPICard
                    title="Resolution Rate"
                    value={fp(sn(monthData.resolutionRate), 1)}
                    subValue="Overdue accounts cured"
                    trend="up"
                    icon={RefreshCw}
                    className="border-l-4 border-l-teal-500"
                />
                <KPICard
                    title="NPA Recovery"
                    value={fc(sn(monthData.recoveryFromNPA), 2)}
                    subValue="Recovered from write-offs"
                    trend="up"
                    icon={TrendingUp}
                    className="border-l-4 border-l-indigo-500"
                />
                <KPICard
                    title="Digital Collection"
                    value={`${fp(sn(monthData.digitalPct), 1)}`}
                    subValue={fc(sn(monthData.digitalCollection))}
                    trend="up"
                    trendValue="↑ YTD"
                    icon={Smartphone}
                    className="border-l-4 border-l-purple-500"
                />
                <KPICard
                    title="Non-Starters"
                    value={(monthData.nonStarters || 0).toLocaleString()}
                    subValue="Accounts never paid"
                    trend="down"
                    trendValue="Early delinquency signal"
                    icon={ShieldAlert}
                    className="border-l-4 border-l-orange-500"
                />
            </div>

            {/* ── DPD Bucket Table + State Heatmap ────────────────────────── */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">

                {/* DPD Waterfall Table */}
                <div className="bg-white rounded-xl border border-secondary-200 shadow-sm p-5">
                    <h3 className="text-sm font-bold text-secondary-800 uppercase tracking-wider mb-4 flex items-center gap-2">
                        <span className="w-2 h-2 rounded-full bg-rose-500 inline-block" />
                        Overdue Bucket Analysis (DPD)
                    </h3>
                    <div className="space-y-3">
                        {monthData.dpd.map((bucket, i) => (
                            <div key={bucket.bucket} className="space-y-1">
                                <div className="flex justify-between items-center text-xs">
                                    <span className="font-semibold text-secondary-700">{bucket.bucket}</span>
                                    <div className="flex gap-4 text-right">
                                        <span className="text-secondary-500">{bucket.accounts.toLocaleString()} accounts</span>
                                        <span className="font-bold text-secondary-800 w-24 text-right">{fc(sn(bucket.amount))}</span>
                                        <span className="font-bold w-14 text-right" style={{ color: DPD_COLORS[i] }}>{fp(sn(bucket.pct))}</span>
                                    </div>
                                </div>
                                <div className="w-full h-2 bg-secondary-100 rounded-full overflow-hidden">
                                    <div
                                        className="h-full rounded-full transition-all duration-700"
                                        style={{
                                            width: `${Math.min(100, (sn(bucket.pct) / (monthData.dpd[0]?.pct || 1)) * 100)}%`,
                                            backgroundColor: DPD_COLORS[i]
                                        }}
                                    />
                                </div>
                            </div>
                        ))}
                    </div>
                    <div className="mt-4 pt-4 border-t border-secondary-100 flex justify-between text-xs text-secondary-500">
                        <span>Total Overdue Portfolio at Risk</span>
                        <span className="font-bold text-rose-600">
                            {fc(sn(monthData.dpd.reduce((s, b) => s + sn(b.amount), 0)))}
                        </span>
                    </div>
                </div>

                {/* State-wise Collection Efficiency */}
                <div className="bg-white rounded-xl border border-secondary-200 shadow-sm p-5">
                    <h3 className="text-sm font-bold text-secondary-800 uppercase tracking-wider mb-4">
                        State-wise Collection Efficiency
                    </h3>
                    <ResponsiveContainer width="100%" height={240}>
                        <BarChart data={stateCollectionData} layout="vertical" margin={{ left: 80, right: 40 }}>
                            <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f1f5f9" />
                            <XAxis type="number" domain={[90, 100]} tickFormatter={v => `${v}%`} tick={{ fontSize: 10 }} />
                            <YAxis type="category" dataKey="name" tick={{ fontSize: 11 }} width={80} />
                            <Tooltip formatter={(v: number) => `${v.toFixed(1)}%`} />
                            <ReferenceLine x={99} stroke="#10b981" strokeDasharray="4 4" label={{ value: 'Target', fill: '#10b981', fontSize: 10 }} />
                            <Bar isAnimationActive={false} dataKey="efficiency" radius={[0, 4, 4, 0]}>
                                {stateCollectionData.map((entry, i) => (
                                    <Cell key={i} fill={entry.efficiency >= 99 ? '#10b981' : entry.efficiency >= 97 ? '#f59e0b' : '#ef4444'} />
                                ))}
                            </Bar>
                        </BarChart>
                    </ResponsiveContainer>
                </div>
            </div>

            {/* ── 12-Month Demand vs Collected Trend ──────────────────────── */}
            <div className="bg-white rounded-xl border border-secondary-200 shadow-sm p-5">
                <h3 className="text-sm font-bold text-secondary-800 uppercase tracking-wider mb-4">
                    12-Month: Scheduled vs Collected (₹ Cr)
                </h3>
                <ResponsiveContainer width="100%" height={240}>
                    <BarChart data={trendData} margin={{ top: 5, right: 30 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                        <XAxis dataKey="month" tick={{ fontSize: 11 }} />
                        <YAxis tickFormatter={v => `₹${v}`} tick={{ fontSize: 11 }} />
                        <Tooltip formatter={(v: number, name: string) => [`₹${v.toFixed(2)} Cr`, name]} />
                        <Legend />
                        <Bar isAnimationActive={false} dataKey="Scheduled" fill="#93c5fd" radius={[3, 3, 0, 0]} />
                        <Bar isAnimationActive={false} dataKey="Collected" fill="#10b981" radius={[3, 3, 0, 0]} />
                    </BarChart>
                </ResponsiveContainer>
            </div>

            {/* ── Digital vs Cash + Resolution Rate ───────────────────────── */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="bg-white rounded-xl border border-secondary-200 shadow-sm p-5">
                    <h3 className="text-sm font-bold text-secondary-800 uppercase tracking-wider mb-4 flex items-center gap-2">
                        <Smartphone size={14} className="text-purple-500" />
                        Digital vs Cash Collection Trend
                    </h3>
                    <ResponsiveContainer width="100%" height={220}>
                        <BarChart data={paymentTrendData} margin={{ top: 5, right: 20 }}>
                            <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                            <XAxis dataKey="month" tick={{ fontSize: 11 }} />
                            <YAxis tickFormatter={v => `₹${v}`} tick={{ fontSize: 11 }} />
                            <Tooltip formatter={(v: number, name: string) => [`₹${v.toFixed(2)} Cr`, name]} />
                            <Legend />
                            <Bar isAnimationActive={false} dataKey="Digital" stackId="a" fill="#8b5cf6" radius={[0, 0, 0, 0]} />
                            <Bar isAnimationActive={false} dataKey="Cash" stackId="a" fill="#d1d5db" radius={[3, 3, 0, 0]} />
                        </BarChart>
                    </ResponsiveContainer>
                </div>

                <div className="bg-white rounded-xl border border-secondary-200 shadow-sm p-5">
                    <h3 className="text-sm font-bold text-secondary-800 uppercase tracking-wider mb-4 flex items-center gap-2">
                        <RefreshCw size={14} className="text-teal-500" />
                        Overdue Resolution Rate (%)
                    </h3>
                    <ResponsiveContainer width="100%" height={220}>
                        <LineChart data={resolutionTrend} margin={{ top: 5, right: 20 }}>
                            <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                            <XAxis dataKey="month" tick={{ fontSize: 11 }} />
                            <YAxis domain={[55, 80]} tickFormatter={v => `${v}%`} tick={{ fontSize: 11 }} yAxisId="left" />
                            <YAxis orientation="right" tickFormatter={v => `₹${v}`} tick={{ fontSize: 11 }} yAxisId="right" />
                            <Tooltip />
                            <Legend />
                            <Line isAnimationActive={false} yAxisId="left" dataKey="Resolution Rate" stroke="#14b8a6" strokeWidth={2} dot={{ r: 3 }} />
                            <Line isAnimationActive={false} yAxisId="right" dataKey="Recovery (NPA)" stroke="#6366f1" strokeWidth={2} dot={{ r: 3 }} />
                        </LineChart>
                    </ResponsiveContainer>
                </div>
            </div>

            {/* ── High-Risk Centres Table ──────────────────────────────────── */}
            <div className="bg-white rounded-xl border border-secondary-200 shadow-sm p-5">
                <div className="flex justify-between items-center mb-4">
                    <h3 className="text-sm font-bold text-secondary-800 uppercase tracking-wider flex items-center gap-2">
                        <AlertCircle size={14} className="text-rose-500" />
                        High-Risk Centres (PAR &gt; 4%) — Requires Immediate Attention
                    </h3>
                    <select
                        className="bg-white border border-secondary-300 rounded-lg px-3 py-1.5 text-xs text-secondary-700 outline-none"
                        value={selectedState}
                        onChange={e => setSelectedState(e.target.value)}
                    >
                        <option value="All">All States</option>
                        {ALL_STATES_DATA.map(s => <option key={s.name} value={s.name}>{s.name}</option>)}
                    </select>
                </div>
                <div className="overflow-x-auto">
                    <table className="w-full text-left text-sm">
                        <thead className="bg-secondary-50 border-b border-secondary-200">
                            <tr>
                                {['Centre', 'Branch', 'District', 'State', 'PAR 30%', 'Overdue', 'Missed (Consec.)', 'Clients'].map(h => (
                                    <th key={h} className="py-2 px-3 text-xs font-semibold text-secondary-500 whitespace-nowrap">{h}</th>
                                ))}
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-secondary-100">
                            {filteredRiskCentres.map((c, i) => (
                                <tr key={i} className="hover:bg-rose-50 transition-colors">
                                    <td className="py-2 px-3 font-medium text-secondary-900 text-xs">{c.centreName}</td>
                                    <td className="py-2 px-3 text-secondary-600 text-xs">{c.branchName}</td>
                                    <td className="py-2 px-3 text-secondary-600 text-xs">{c.district}</td>
                                    <td className="py-2 px-3 text-secondary-600 text-xs">{c.state}</td>
                                    <td className="py-2 px-3 text-xs">
                                        <span className={cn(
                                            'px-2 py-0.5 rounded font-bold',
                                            c.par30 > 7 ? 'bg-rose-100 text-rose-700' : 'bg-amber-100 text-amber-700'
                                        )}>
                                            {fp(c.par30)}
                                        </span>
                                    </td>
                                    <td className="py-2 px-3 font-mono text-xs text-rose-600 font-semibold">₹{c.overdueAmount.toFixed(3)} Cr</td>
                                    <td className="py-2 px-3 text-xs text-center">
                                        {Array.from({ length: c.consecutiveMisses }).map((_, j) => (
                                            <span key={j} className="inline-block w-2 h-2 bg-rose-400 rounded-full mr-0.5" />
                                        ))}
                                        <span className="text-secondary-500 ml-1">{c.consecutiveMisses}</span>
                                    </td>
                                    <td className="py-2 px-3 text-xs text-secondary-600">{c.clients.toLocaleString()}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                    {filteredRiskCentres.length === 0 && (
                        <div className="text-center py-8 text-secondary-400 text-sm">No high-risk centres in this state 🎉</div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default CollectionsDashboard;
