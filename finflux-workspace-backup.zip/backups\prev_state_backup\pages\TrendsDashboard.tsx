import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { TrendingUp, Users, Wallet } from 'lucide-react';
import { COMPANY_HISTORY, COMPANY_METRICS } from '../data/mfiData';

// Map Central History to Chart Format
const trendsData = COMPANY_HISTORY.map(m => ({
    month: m.month,
    newCustomers: Math.floor(m.activeClients / 2000), // Simulated scale
    totalPar: m.par30,
    par0: parseFloat((m.par30 * 0.5).toFixed(2)),
    par30: m.par30,
    par60: parseFloat((m.par30 * 0.3).toFixed(2)),
    par90: m.par90,
    glp: m.glp,
    disb: m.disbursement,
    lastYearDisb: m.disbursement * 0.8, // Simulated lag
    branches: 3520 // Constant for now
}));

const TrendsDashboard = () => {
    return (
        <div className="space-y-6">
            <div className="flex items-center justify-between">
                <div>
                    <h2 className="text-2xl font-bold text-secondary-900">Growth Trends</h2>
                    <p className="text-secondary-500">Year-over-year performance analysis (2025)</p>
                </div>
                <select className="bg-white border border-secondary-300 rounded-lg px-3 py-2 text-sm text-secondary-700 outline-none focus:ring-2 focus:ring-primary-500">
                    <option>2025 (Current)</option>
                    <option>2024</option>
                    <option>2023</option>
                </select>
            </div>

            {/* Summary Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-gradient-to-br from-primary-500 to-primary-600 p-6 rounded-xl text-white shadow-lg">
                    <div className="flex items-center justify-between mb-2">
                        <Wallet size={24} />
                        <span className="text-xs bg-white/20 px-2 py-1 rounded-full">YTD</span>
                    </div>
                    <div className="text-3xl font-bold">₹8,500 Cr</div>
                    <div className="text-sm opacity-90">Portfolio (GLP)</div>
                    <div className="mt-2 text-xs">+21.4% vs last year</div>
                </div>

                <div className="bg-gradient-to-br from-emerald-500 to-emerald-600 p-6 rounded-xl text-white shadow-lg">
                    <div className="flex items-center justify-between mb-2">
                        <Users size={24} />
                        <span className="text-xs bg-white/20 px-2 py-1 rounded-full">Dec</span>
                    </div>
                    <div className="text-3xl font-bold">35k</div>
                    <div className="text-sm opacity-90">New Customers</div>
                    <div className="mt-2 text-xs">+133% vs Jan 2025</div>
                </div>

                <div className="bg-gradient-to-br from-rose-500 to-rose-600 p-6 rounded-xl text-white shadow-lg">
                    <div className="flex items-center justify-between mb-2">
                        <TrendingUp size={24} />
                        <span className="text-xs bg-white/20 px-2 py-1 rounded-full">Current</span>
                    </div>
                    <div className="text-3xl font-bold">3.9%</div>
                    <div className="text-sm opacity-90">Total PAR</div>
                    <div className="mt-2 text-xs">+1.1% vs Jan 2025</div>
                </div>
            </div>

            {/* Portfolio Growth Chart */}
            <div className="bg-white p-6 rounded-xl border border-secondary-200 shadow-sm">
                <h3 className="text-lg font-semibold text-secondary-800 mb-4">Portfolio Growth (GLP in Crores)</h3>
                <ResponsiveContainer width="100%" height={300}>
                    <LineChart data={trendsData}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                        <XAxis dataKey="month" stroke="#6b7280" />
                        <YAxis stroke="#6b7280" />
                        <Tooltip
                            contentStyle={{ backgroundColor: '#fff', border: '1px solid #e5e7eb', borderRadius: '8px' }}
                            formatter={(value) => `₹${value} Cr`}
                        />
                        <Legend />
                        <Line type="monotone" dataKey="glp" stroke="#0ea5e9" strokeWidth={3} name="GLP" dot={{ fill: '#0ea5e9', r: 4 }} />
                    </LineChart>
                </ResponsiveContainer>
            </div>

            {/* Disbursement Comparison */}
            <div className="bg-white p-6 rounded-xl border border-secondary-200 shadow-sm">
                <h3 className="text-lg font-semibold text-secondary-800 mb-4">Disbursement Trends (MTD in Crores)</h3>
                <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={trendsData}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                        <XAxis dataKey="month" stroke="#6b7280" />
                        <YAxis stroke="#6b7280" />
                        <Tooltip
                            contentStyle={{ backgroundColor: '#fff', border: '1px solid #e5e7eb', borderRadius: '8px' }}
                            formatter={(value) => `₹${value} Cr`}
                        />
                        <Legend />
                        <Bar dataKey="disb" fill="#10b981" name="2025 Disbursement" radius={[8, 8, 0, 0]} />
                        <Bar dataKey="lastYearDisb" fill="#94a3b8" name="2024 Disbursement" radius={[8, 8, 0, 0]} />
                    </BarChart>
                </ResponsiveContainer>
            </div>

            {/* PAR Breakdown */}
            <div className="bg-white p-6 rounded-xl border border-secondary-200 shadow-sm">
                <h3 className="text-lg font-semibold text-secondary-800 mb-4">Portfolio at Risk (PAR) Breakdown</h3>
                <ResponsiveContainer width="100%" height={300}>
                    <LineChart data={trendsData}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                        <XAxis dataKey="month" stroke="#6b7280" />
                        <YAxis stroke="#6b7280" />
                        <Tooltip
                            contentStyle={{ backgroundColor: '#fff', border: '1px solid #e5e7eb', borderRadius: '8px' }}
                            formatter={(value) => `${value}%`}
                        />
                        <Legend />
                        <Line type="monotone" dataKey="totalPar" stroke="#ef4444" strokeWidth={2} name="Total PAR" />
                        <Line type="monotone" dataKey="par0" stroke="#f59e0b" strokeWidth={2} name="PAR 0-30" />
                        <Line type="monotone" dataKey="par30" stroke="#f97316" strokeWidth={2} name="PAR 30-60" />
                        <Line type="monotone" dataKey="par90" stroke="#dc2626" strokeWidth={2} name="PAR >90" />
                    </LineChart>
                </ResponsiveContainer>
            </div>

            {/* Customer Acquisition */}
            <div className="bg-white p-6 rounded-xl border border-secondary-200 shadow-sm">
                <h3 className="text-lg font-semibold text-secondary-800 mb-4">New Customer Acquisition (in Thousands)</h3>
                <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={trendsData}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                        <XAxis dataKey="month" stroke="#6b7280" />
                        <YAxis stroke="#6b7280" />
                        <Tooltip
                            contentStyle={{ backgroundColor: '#fff', border: '1px solid #e5e7eb', borderRadius: '8px' }}
                            formatter={(value) => `${value}k`}
                        />
                        <Legend />
                        <Bar dataKey="newCustomers" fill="#6366f1" name="New Customers" radius={[8, 8, 0, 0]} />
                    </BarChart>
                </ResponsiveContainer>
            </div>
        </div>
    );
};

export default TrendsDashboard;
