const fs = require('fs');

function r(f, line, txt) {
    let lines = fs.readFileSync(f, 'utf8').split('\n');
    lines[line - 1] = lines[line - 1].replace('<>', txt);
    fs.writeFileSync(f, lines.join('\n'));
}

r('src/pages/PortfolioDashboard.tsx', 274, '<AreaChart data={portfolioTrendData}>');
r('src/pages/PortfolioDashboard.tsx', 310, '<PieChart>');
r('src/pages/PortfolioDashboard.tsx', 413, '<BarChart data={auditData.violationStats} layout="vertical" margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>');
r('src/pages/PortfolioDashboard.tsx', 434, '<PieChart>');

r('src/pages/HomeDashboard.tsx', 458, '<AreaChart data={chartData} margin={{ top: 5, right: 5, left: -10, bottom: 0 }}>');
r('src/pages/HomeDashboard.tsx', 605, '<BarChart data={chartData} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>');

r('src/pages/OriginationDashboard.tsx', 578, '<AreaChart data={viewData.trends}>');

r('src/pages/AuditDashboard.tsx', 143, '<BarChart data={auditData.violationStats} layout="vertical" margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>');
r('src/pages/AuditDashboard.tsx', 164, '<PieChart>');

r('src/pages/FinancialDashboard.tsx', 300, '<BarChart data={waterfallData} margin={{ top: 5, right: 20, bottom: 40 }}>');
r('src/pages/FinancialDashboard.tsx', 320, '<BarChart data={incomeTrend} margin={{ top: 5, right: 20 }}>');
r('src/pages/FinancialDashboard.tsx', 394, '<LineChart data={ratioTrend} margin={{ top: 5, right: 20 }}>');
r('src/pages/FinancialDashboard.tsx', 478, '<ComposedChart data={spreadTrend} margin={{ top: 5, right: 20 }}>');

r('src/pages/TrendsDashboard.tsx', 227, '<ComposedChart data={overallTrend} margin={{ top: 5, right: 20 }}>');

r('src/pages/CollectionsDashboard.tsx', 318, '<BarChart data={stateCollectionData} layout="vertical" margin={{ left: 80, right: 40 }}>');
r('src/pages/CollectionsDashboard.tsx', 340, '<BarChart data={trendData} margin={{ top: 5, right: 30 }}>');
r('src/pages/CollectionsDashboard.tsx', 360, '<BarChart data={paymentTrendData} margin={{ top: 5, right: 20 }}>');
r('src/pages/CollectionsDashboard.tsx', 378, '<LineChart data={resolutionTrend} margin={{ top: 5, right: 20 }}>');
