import { useNavigate, useLocation, Outlet, NavLink } from 'react-router-dom';
import { LayoutDashboard, Map, TrendingUp, LogOut, Menu, Building2, PieChart, Package } from 'lucide-react';
import { cn } from '../lib/utils';
import { useState } from 'react';

const Layout = () => {
    const [desktopSidebarOpen, setDesktopSidebarOpen] = useState(true);
    const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
    const navigate = useNavigate();
    const location = useLocation();

    const handleLogout = () => {
        navigate('/login');
    };

    const navItems = [
        { path: '/home', icon: LayoutDashboard, label: 'Home Dashboard' },
        { path: '/products', icon: Package, label: 'Products & Impact' },
        { path: '/geo', icon: Map, label: 'Geo Drill' },
        { path: '/branch', icon: Building2, label: 'Branch View' },
        { path: '/portfolio', icon: PieChart, label: 'Portfolio Quality' },
        { path: '/trends', icon: TrendingUp, label: 'Trends' },
    ];

    return (
        <div className="flex h-screen bg-secondary-50 text-secondary-900 overflow-hidden">
            {/* Mobile Sidebar Overlay Backdrop */}
            {mobileMenuOpen && (
                <div
                    className="fixed inset-0 bg-black/50 z-20 md:hidden glass-effect"
                    onClick={() => setMobileMenuOpen(false)}
                />
            )}

            {/* Sidebar */}
            <aside
                className={cn(
                    "fixed md:relative z-30 h-full bg-white border-r border-secondary-200 transition-all duration-300 flex flex-col",
                    // Mobile: Slide in/out
                    mobileMenuOpen ? "translate-x-0" : "-translate-x-full md:translate-x-0",
                    // Desktop: Width toggle
                    desktopSidebarOpen ? "md:w-64" : "md:w-20",
                    "w-64" // Fixed width on mobile when open
                )}
            >
                <div className="p-4 border-b border-secondary-200 flex items-center justify-between h-16 shrink-0">
                    {desktopSidebarOpen ? (
                        <div className="font-bold text-xl text-primary-600 tracking-tight flex items-center gap-2">
                            FINFLUX
                        </div>
                    ) : (
                        <div className="text-xl font-bold text-primary-600 mx-auto">F</div>
                    )}

                    {/* Desktop Collapse Toggle */}
                    <button
                        onClick={() => setDesktopSidebarOpen(!desktopSidebarOpen)}
                        className="hidden md:block p-1 hover:bg-secondary-100 rounded-md text-secondary-500"
                    >
                        <Menu size={20} />
                    </button>

                    {/* Mobile Close Button */}
                    <button
                        onClick={() => setMobileMenuOpen(false)}
                        className="md:hidden p-1 hover:bg-secondary-100 rounded-md text-secondary-500"
                    >
                        <Menu size={20} />
                    </button>
                </div>

                <nav className="flex-1 p-4 space-y-2 overflow-y-auto">
                    {navItems.map((item) => (
                        <NavLink
                            key={item.path}
                            to={item.path}
                            onClick={() => setMobileMenuOpen(false)} // Close on navigate (mobile)
                            className={({ isActive }) => cn(
                                "flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all duration-200 group whitespace-nowrap",
                                isActive
                                    ? "bg-primary-50 text-primary-700 shadow-sm ring-1 ring-primary-200/50"
                                    : "text-secondary-600 hover:bg-secondary-100 hover:text-secondary-900"
                            )}
                        >
                            <item.icon size={22} className={cn("shrink-0 transition-colors", location.pathname === item.path ? "text-primary-600" : "text-secondary-400 group-hover:text-secondary-600")} />
                            <span className={cn(
                                "font-medium transition-opacity duration-200",
                                !desktopSidebarOpen && "md:opacity-0 md:hidden", // Hide text when collapsed on desktop
                                desktopSidebarOpen && "md:opacity-100 md:block"
                            )}>
                                {item.label}
                            </span>
                        </NavLink>
                    ))}
                </nav>

                <div className="p-4 border-t border-secondary-200 shrink-0">
                    <button
                        onClick={handleLogout}
                        className={cn(
                            "flex items-center gap-3 px-3 py-2.5 rounded-lg transition-colors w-full text-left text-danger hover:bg-danger/10 whitespace-nowrap",
                            !desktopSidebarOpen && "md:justify-center"
                        )}
                    >
                        <LogOut size={22} className="shrink-0" />
                        <span className={cn(
                            "font-medium",
                            !desktopSidebarOpen && "md:hidden"
                        )}>
                            Logout
                        </span>
                    </button>
                </div>
            </aside>

            {/* Main Content */}
            <main className="flex-1 flex flex-col min-w-0 overflow-hidden">
                {/* Header */}
                <header className="h-16 bg-white border-b border-secondary-200 flex items-center justify-between px-4 md:px-6 shrink-0 z-10">
                    <div className="flex items-center gap-3">
                        {/* Mobile Menu Trigger */}
                        <button
                            onClick={() => setMobileMenuOpen(true)}
                            className="md:hidden p-2 -ml-2 text-secondary-600 hover:bg-secondary-100 rounded-lg"
                        >
                            <Menu size={24} />
                        </button>

                        <h1 className="text-lg font-semibold text-secondary-800 truncate">
                            {navItems.find(i => i.path === location.pathname)?.label || 'Dashboard'}
                        </h1>
                    </div>

                    <div className="flex items-center gap-4">
                        <div className="text-sm text-right hidden sm:block">
                            <div className="font-medium text-secondary-900">Sriram (Admin)</div>
                            <div className="text-xs text-secondary-500">Head Office</div>
                        </div>
                        <div className="w-9 h-9 bg-primary-100 text-primary-700 rounded-full flex items-center justify-center font-bold text-sm shrink-0">
                            SR
                        </div>
                    </div>
                </header>

                {/* Content Scroll Area */}
                <div className="flex-1 overflow-auto p-4 md:p-6 scroll-smooth">
                    <Outlet />
                </div>
            </main>
        </div>
    );
};

export default Layout;
