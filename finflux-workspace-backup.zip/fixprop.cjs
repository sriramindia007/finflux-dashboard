const fs = require('fs');
const f = 'src/pages/PortfolioDashboard.tsx';
let c = fs.readFileSync(f, 'utf8');
c = c.replace('COMPANY_METRICS.grossLoanPortfolio || 8725', 'COMPANY_METRICS.currentGLP || 8725');
console.log('fixed:', c.includes('COMPANY_METRICS.currentGLP'));
fs.writeFileSync(f, c, 'utf8');
