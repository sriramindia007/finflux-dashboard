const fs = require('fs');
const cp = require('child_process');
const files = cp.execSync('dir /s /b src\\pages\\*.tsx').toString().split('\r\n').map(l => l.trim()).filter(Boolean);

files.forEach(f => {
    let original = fs.readFileSync(f, 'utf8');
    // We only want to add isAnimationActive={false} to Recharts elements if they don't have it yet.
    // The tags are <Bar, <Line, <Area, <Pie, <Radar, <Scatter.
    let modified = original.replace(/<(Bar|Line|Area|Pie|Radar|Scatter)(?=\s|>)/g, '<$1 isAnimationActive={false}');
    if (original !== modified) {
        fs.writeFileSync(f, modified);
        console.log(`Updated ${f}`);
    }
});
