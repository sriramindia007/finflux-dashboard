const fs = require('fs');
const text = fs.readFileSync('src/pages/HomeDashboard.tsx', 'utf8');
const lines = text.split('\n');
lines.forEach((l, i) => {
    let count = (l.match(/`/g) || []).length;
    if (count % 2 !== 0) {
        console.log(`Line ${i + 1}: ${l.trim()}`);
    }
});
