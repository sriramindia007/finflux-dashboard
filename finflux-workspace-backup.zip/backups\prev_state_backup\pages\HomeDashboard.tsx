import { useState } from 'react';
import { Wallet, Users, Banknote, AlertCircle, Building2, MapPin, Milestone, Download, ShieldAlert, BadgePercent, TrendingUp } from 'lucide-react';
import KPICard from '../components/KPICard';
import { cn } from '../lib/utils';
import { COMPANY_METRICS, STATES_DATA, TOP_BRANCHES, formatCurrency } from '../data/mfiData';
import { ALL_STATES_DATA } from '../data/geoDataComplete';

const HomeDashboard = () => {
    const [selectedRegion, setSelectedRegion] = useState('All');

    // Determine which dataset to use based on filter
    const getRegionKey = (region: string) => {
        const lower = region.toLowerCase();
        if (lower === 'andhra pradesh') return 'andhra';
        if (lower === 'madhya pradesh') return 'madhyaPradesh';
        if (lower === 'tamil nadu') return 'tamilNadu';
        return lower;
    };

    const metrics = selectedRegion === 'All'
        ? COMPANY_METRICS
        : STATES_DATA[getRegionKey(selectedRegion) as keyof typeof STATES_DATA];

    const topBranches = selectedRegion === 'All'
        ? TOP_BRANCHES
        : TOP_BRANCHES.filter(b => b.state === selectedRegion);

    const handleExport = () => {
        // Create CSV Content
        const headers = ["Metric", "Value"];
        const rows = [
            ["Region", selectedRegion],
            ["GLP", `${metrics.glp} Cr`],
            ["Branches", metrics.branches || metrics.totalBranches],
            ["Active Clients", metrics.activeClients],
            ["MTD Disbursement", `${metrics.mtdDisbursement} Cr`],
            ["MTD Collection", `${metrics.mtdCollection} Cr`],
            ["PAR > 30", `${metrics.par30 || metrics.parOver30}%`]
        ];

        const csvContent = "data:text/csv;charset=utf-8,"
            + headers.join(",") + "\n"
            + rows.map(e => e.join(",")).join("\n");

        // Download
        const encodedUri = encodeURI(csvContent);
        const link = document.createElement("a");
        link.setAttribute("href", encodedUri);
        link.setAttribute("download", `Finflux_Report_${selectedRegion}_${new Date().toISOString().slice(0, 10)}.csv`);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    return (
        <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                    <h2 className="text-2xl font-bold text-secondary-900">Executive Overview</h2>
                    <p className="text-secondary-500">Real-time performance metrics</p>
                </div>
                <div className="flex gap-2">
                    <select
                        className="bg-white border border-secondary-300 rounded-lg px-3 py-2 text-sm text-secondary-700 outline-none focus:ring-2 focus:ring-primary-500"
                        value={selectedRegion}
                        onChange={(e) => setSelectedRegion(e.target.value)}
                    >
                        <option value="All">All Regions</option>
                        <option value="Odisha">Odisha</option>
                        <option value="Karnataka">Karnataka</option>
                        <option value="Andhra Pradesh">Andhra Pradesh</option>
                        <option value="Madhya Pradesh">Madhya Pradesh</option>
                        <option value="Tamil Nadu">Tamil Nadu</option>
                    </select>
                    <button
                        onClick={handleExport}
                        className="bg-white border border-secondary-300 rounded-lg px-3 py-2 text-sm text-secondary-700 hover:bg-secondary-50 flex items-center gap-2"
                    >
                        <Download size={16} />
                        Export Report
                    </button>
                </div>
            </div>

            {/* Primary KPI Grid - Cash Flow (Disbursement & Collections) */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <KPICard
                    title="Disbursement (MTD)"
                    value={`₹${metrics.mtdDisbursement} Cr`}
                    trend="up"
                    trendValue="10.5%"
                    icon={Wallet}
                    className="border-l-4 border-l-primary-500"
                />
                <KPICard
                    title="Disbursement (YTD)"
                    value={`₹${metrics.ytdDisbursement.toLocaleString()} Cr`}
                    subValue={selectedRegion === 'All' ? `Target: ₹${COMPANY_METRICS.ytdDisbursementTarget.toLocaleString()} Cr` : ''}
                    trend="up"
                    trendValue="5.2%"
                    icon={Wallet}
                />
                <KPICard
                    title="Collections (MTD)"
                    value={`₹${metrics.mtdCollection} Cr`}
                    subValue={selectedRegion === 'All' ? `/ ₹${COMPANY_METRICS.mtdCollectionDue} Cr Due` : ''}
                    trend="up"
                    trendValue="95.8%"
                    icon={Banknote}
                    className="border-l-4 border-l-emerald-500"
                />
                <KPICard
                    title="Collections (YTD)"
                    value={`₹${metrics.ytdCollection.toLocaleString()} Cr`}
                    subValue={selectedRegion === 'All' ? `/ ₹${COMPANY_METRICS.ytdCollectionDue.toLocaleString()} Cr Due` : ''}
                    trend="up"
                    trendValue="96.1%"
                    icon={Banknote}
                />
            </div>

            {/* Secondary KPI Grid - Portfolio Health & Scale */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <KPICard
                    title="Outstanding GLP"
                    value={`₹${(metrics.glp || metrics.currentGLP).toLocaleString()} Cr`}
                    trend="up"
                    trendValue="0.9%"
                    icon={Wallet}
                />
                <KPICard
                    title="PAR Total (>30 Days)"
                    value={`${metrics.par30 || metrics.parOver30}%`}
                    trend="down"
                    trendValue="0.1%"
                    icon={AlertCircle}
                />
                <KPICard
                    title="Overdue Amount"
                    value={`₹${selectedRegion === 'All' ? metrics.overdueAmount : (metrics.glp * (metrics.par30 / 100)).toFixed(1)} Cr`}
                    trend="down"
                    trendValue="2.1%"
                    icon={AlertCircle}
                />
                <KPICard
                    title="Active Clients"
                    value={`${(metrics.activeClients / 100000).toFixed(1)} L`}
                    subValue={metrics.activeClients.toLocaleString()}
                    trend="up"
                    trendValue="1.0%"
                    icon={Users}
                />
            </div>

            {/* Tertiary KPI Grid - Risk & Ops */}
            {/* Tertiary KPI Grid - Risk & Ops */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <KPICard
                    title="NPA (90+ Days)"
                    value={`${metrics.par90}%`}
                    subValue="Critical Risk"
                    trend="down"
                    trendValue="0.05%"
                    icon={ShieldAlert}
                    className="border-l-4 border-l-rose-500"
                />
                <KPICard
                    title="Collection Efficiency"
                    value={`${(metrics.mtdCollection / metrics.mtdCollectionDue * 100).toFixed(1)}%`}
                    subValue="Target: 99.0%"
                    trend="up"
                    trendValue="0.3%"
                    icon={BadgePercent}
                    className="border-l-4 border-l-blue-500"
                />
                <KPICard
                    title="Write-off (YTD)"
                    value={`₹${(selectedRegion === 'All'
                        ? ALL_STATES_DATA.reduce((sum, s) => sum + (s.writeOff || 0), 0)
                        : (ALL_STATES_DATA.find(s => s.name === selectedRegion)?.writeOff || 0)
                    ).toFixed(4)
                        } Cr`}
                    trend="neutral"
                    trendValue="0%"
                    icon={Banknote}
                />
                <KPICard
                    title="Active Branches"
                    value={(metrics.branches || metrics.totalBranches).toLocaleString()}
                    subValue={`${metrics.districts || 52} Districts`}
                    trend="neutral"
                    trendValue="Stable"
                    icon={Building2}
                />
            </div>

            {/* Charts Row */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Collection Efficiency Panel (Compact Vertical) */}
                <div className="bg-white p-5 rounded-lg border border-secondary-200 shadow-sm col-span-1 flex flex-col h-full">
                    <h3 className="text-xs font-bold text-secondary-800 uppercase tracking-wider mb-4">Collection Status</h3>
                    <div className="space-y-3 flex-1">
                        <div className="p-3 bg-emerald-50 rounded border border-emerald-100">
                            <div className="flex justify-between items-center mb-1">
                                <span className="text-[10px] text-emerald-700 font-bold uppercase">Paid On Time</span>
                                <span className="text-xs font-bold text-emerald-800">95.8%</span>
                            </div>
                            <div className="text-lg font-bold text-emerald-700">₹{metrics.mtdCollection} Cr</div>
                        </div>
                        <div className="p-3 bg-rose-50 rounded border border-rose-100">
                            <div className="flex justify-between items-center mb-1">
                                <span className="text-[10px] text-rose-700 font-bold uppercase">Overdue</span>
                                <span className="text-xs font-bold text-rose-800">4.2%</span>
                            </div>
                            <div className="text-lg font-bold text-rose-700">₹{(metrics.mtdCollection * 0.042).toFixed(1)} Cr</div>
                        </div>
                    </div>
                    <div className="mt-4 pt-4 border-t border-secondary-100">
                        <div className="text-[10px] text-secondary-500 mb-1">Overall Efficiency</div>
                        <div className="w-full bg-secondary-100 rounded-full h-1.5 overflow-hidden">
                            <div className="h-full bg-emerald-500 w-[96%]"></div>
                        </div>
                    </div>
                </div>

                {/* 3. Product Portfolio Mix (Expanded) - Now takes remaining space in Row 1 */}
                <div className="lg:col-span-2 bg-white p-5 rounded-lg border border-secondary-200 shadow-sm h-full">
                    <div className="flex justify-between items-center mb-5">
                        <div>
                            <h3 className="text-xs font-bold text-secondary-800 uppercase tracking-wider">Product Portfolio Mix</h3>
                            <p className="text-[10px] text-secondary-500 mt-0.5">GLP Breakdown by Product</p>
                        </div>
                        <div className="text-right">
                            <div className="text-lg font-bold text-secondary-900">₹{(metrics.glp || metrics.currentGLP).toLocaleString()} Cr</div>
                        </div>
                    </div>

                    <div className="space-y-4 overflow-y-auto max-h-[300px] pr-2">
                        {(metrics.productMix || []).sort((a: any, b: any) => b.glp - a.glp).map((product: any, idx: number) => {
                            const percentage = ((product.glp / (metrics.glp || metrics.currentGLP)) * 100);
                            return (
                                <div key={idx} className="relative group">
                                    <div className="flex justify-between items-end mb-1">
                                        <div className="flex flex-col">
                                            <span className="font-semibold text-secondary-800 text-xs">{product.name}</span>
                                            <span className="text-[10px] text-secondary-500">{product.clients.toLocaleString()} Clients</span>
                                        </div>
                                        <div className="text-right">
                                            <span className="font-bold text-secondary-900 text-sm block">₹{product.glp} Cr</span>
                                        </div>
                                    </div>
                                    <div className="w-full bg-secondary-100 rounded-full h-2 overflow-hidden flex items-center bg-opacity-50">
                                        <div
                                            className={`h-full rounded-full ${product.name.includes('Group') ? 'bg-indigo-500' :
                                                product.name.includes('MSME') ? 'bg-blue-500' :
                                                    product.name.includes('Housing') ? 'bg-emerald-500' :
                                                        product.name.includes('Green') ? 'bg-teal-500' :
                                                            'bg-amber-500'
                                                }`}
                                            style={{ width: `${percentage}%` }}
                                        ></div>
                                    </div>
                                    <div className="absolute right-0 top-0 opacity-0 group-hover:opacity-100 transition-opacity bg-gray-900 text-white text-[10px] px-2 py-1 rounded pointer-events-none transform -translate-y-full">
                                        Risk: {product.par30}%
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                </div>

            </div>

            {/* New Section: Branch Performance & Risk Matrix */}
            <div className="bg-white p-6 rounded-xl border border-secondary-200 shadow-sm">
                <div className="flex justify-between items-center mb-6">
                    <div>
                        <h3 className="text-lg font-bold text-secondary-900">Branch Performance Overview</h3>
                        <p className="text-sm text-secondary-500">Top Performing Units vs Risk Profile</p>
                    </div>
                    <button className="text-primary-600 text-sm font-semibold hover:text-primary-700">View All Branches →</button>
                </div>
                <div className="overflow-x-auto">
                    <table className="w-full text-left text-sm">
                        <thead className="bg-secondary-50 text-secondary-500 border-b border-secondary-200">
                            <tr>
                                <th className="py-3 px-4 font-semibold">Branch Name</th>
                                <th className="py-3 px-4 font-semibold">District</th>
                                <th className="py-3 px-4 text-right font-semibold">GLP (Cr)</th>
                                <th className="py-3 px-4 text-right font-semibold">Active Loans</th>
                                <th className="py-3 px-4 text-right font-semibold">PAR 30 (%)</th>
                                <th className="py-3 px-4 text-center font-semibold">Status</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-secondary-100">
                            {topBranches.slice(0, 10).map((branch, idx) => (
                                <tr key={idx} className="group hover:bg-secondary-50 transition-colors">
                                    <td className="py-3 px-4 cursor-pointer font-medium text-secondary-900">{branch.name}</td>
                                    <td className="py-3 px-4 text-secondary-600">{branch.district}</td>
                                    <td className="py-3 px-4 text-right font-bold text-secondary-800">₹{branch.glp.toFixed(2)}</td>
                                    <td className="py-3 px-4 text-right text-secondary-600">{branch.activeLoans?.toLocaleString() || '-'}</td>
                                    <td className="py-3 px-4 text-right">
                                        <span className={`inline-block px-2 py-1 rounded text-xs font-bold ${branch.par30 < 2 ? 'bg-emerald-100 text-emerald-700' :
                                            branch.par30 < 5 ? 'bg-amber-100 text-amber-700' :
                                                'bg-rose-100 text-rose-700'
                                            }`}>
                                            {branch.par30}%
                                        </span>
                                    </td>
                                    <td className="py-3 px-4 text-center">
                                        {branch.par30 < 2 ? (
                                            <span className="text-emerald-500 flex justify-center"><TrendingUp size={16} /></span>
                                        ) : (
                                            <span className="text-amber-500 flex justify-center"><AlertCircle size={16} /></span>
                                        )}
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
};

export default HomeDashboard;
