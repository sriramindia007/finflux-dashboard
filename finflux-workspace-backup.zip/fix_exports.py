import os
import glob

files = glob.glob('src/pages/*Dashboard.tsx')

for file in files:
    with open(file, 'r', encoding='utf-8') as f:
        content = f.read()

    modified = False

    # 1. Add saveFile import
    if "import { saveFile }" not in content:
        # insert after the last line containing "import"
        if "from 'lucide-react';" in content:
            content = content.replace("from 'lucide-react';", "from 'lucide-react';\nimport { saveFile } from '../lib/utils';")
            modified = True
        elif "import React" in content:
            content = content.replace("import React", "import React\nimport { saveFile } from '../lib/utils';")
            modified = True

    # 2. Excel
    excel_target = "XLSX.writeFile(wb, getFilename('xlsx'));"
    if excel_target in content:
        excel_replacement = r"""const out = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
        saveFile(new Blob([out], { type: 'application/octet-stream' }), getFilename('xlsx'));"""
        content = content.replace(excel_target, excel_replacement)
        modified = True

    # 3. PDF
    pdf_target = "pdf.save(getFilename('pdf'));"
    if pdf_target in content:
        pdf_replacement = "saveFile(pdf.output('blob'), getFilename('pdf'));"
        content = content.replace(pdf_target, pdf_replacement)
        modified = True

    # 4. PPT
    ppt_target = "pptx.writeFile({ fileName: getFilename('pptx') }).catch((err: any) => console.error(\"PPT Error:\", err));"
    if ppt_target in content:
        ppt_replacement = "const blob = (await pptx.write('blob')) as Blob;\n            saveFile(blob, getFilename('pptx'));"
        content = content.replace(ppt_target, ppt_replacement)
        modified = True

    ppt_target2 = "pptx.writeFile({ fileName: getFilename('pptx') }).catch((err) => console.error(\"PPT Error:\", err));"
    if ppt_target2 in content:
         ppt_replacement2 = "const blob = (await pptx.write('blob')) as Blob;\n            saveFile(blob, getFilename('pptx'));"
         content = content.replace(ppt_target2, ppt_replacement2)
         modified = True

    if modified:
        with open(file, 'w', encoding='utf-8') as f:
            f.write(content)
        print(f"Updated {file}")
