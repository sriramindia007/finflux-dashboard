const fs = require('fs');
const path = require('path');

function checkDir(dir) {
    const files = fs.readdirSync(dir);
    for (const file of files) {
        const fullPath = path.join(dir, file);
        if (fs.statSync(fullPath).isDirectory()) {
            checkDir(fullPath);
        } else if (fullPath.endsWith('.tsx')) {
            let content = fs.readFileSync(fullPath, 'utf8');
            const matches = content.match(/<(Area|Bar|Line|Pie|Cell)[^>]*>/g);
            if (matches) {
                for (const match of matches) {
                    if (!match.includes('isAnimationActive') && !match.includes('</')) {
                        console.log(`Missing animation tag in ${file}: ${match}`);
                    }
                }
            }
        }
    }
}

checkDir(path.join(__dirname, 'src/pages'));
checkDir(path.join(__dirname, 'src/components'));
