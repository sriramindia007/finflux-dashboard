const fs = require('fs');
// Portfolio header shows: PAR 30+, GNPA (90+), Audit Score
// KPI cards show: Portfolio at Risk (PAR 30+), GNPA (90+), Hardcore Risk (180+), Collection Efficiency, Write-offs
// Fix: Replace PAR 30+ in header with "Write-offs YTD" (rupee amount — unique framing)
// GNPA: These are legitimate duplicates in different formats, acceptable since users need both
// But to remove the pure duplicate, rename header PAR 30+ to show "Loan at Risk ₹" for rupee framing

const f = 'src/pages/PortfolioDashboard.tsx';
let c = fs.readFileSync(f, 'utf8');

// Find the header stat badge for PAR 30+
// It typically looks like: { label: 'PAR 30+', value or similar in header area
// Let's search for the pattern in the header section
const headerStart = c.indexOf('RISK MANAGEMENT');
const headerEnd = c.indexOf('</div>', headerStart + 2000);
const headerSection = c.slice(headerStart, headerStart + 1500);
console.log('Header area (first 600 chars):', headerSection.slice(0, 600));
