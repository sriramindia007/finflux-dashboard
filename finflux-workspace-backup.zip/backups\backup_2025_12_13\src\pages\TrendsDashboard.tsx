import React, { useState } from 'react';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, ComposedChart, Area } from 'recharts';
import { TrendingUp, Users, Wallet, History, BarChart3, AlertCircle } from 'lucide-react';
import { HISTORICAL_DATA, COMPANY_METRICS } from '../data/mfiData';

// Monthly Growth Data for Jan-Dec 2025 (Projected/Actuals)
// Adjusted to end at ~11,034 Cr to match FY25 AUM
const trendsData = [
    { month: 'Jan', newCustomers: 15, totalPar: 2.8, par0: 1.5, par30: 0.8, par60: 0.4, par90: 0.1, glp: 8500, disb: 650, lastYearDisb: 550, branches: 1600 },
    { month: 'Feb', newCustomers: 18, totalPar: 2.9, par0: 1.6, par30: 0.8, par60: 0.4, par90: 0.1, glp: 8700, disb: 680, lastYearDisb: 580, branches: 1603 },
    { month: 'Mar', newCustomers: 20, totalPar: 3.0, par0: 1.7, par30: 0.9, par60: 0.3, par90: 0.1, glp: 8950, disb: 750, lastYearDisb: 600, branches: 1605 },
    { month: 'Apr', newCustomers: 22, totalPar: 3.1, par0: 1.7, par30: 0.9, par60: 0.4, par90: 0.1, glp: 9200, disb: 700, lastYearDisb: 620, branches: 1610 },
    { month: 'May', newCustomers: 24, totalPar: 3.2, par0: 1.8, par30: 1.0, par60: 0.3, par90: 0.1, glp: 9450, disb: 720, lastYearDisb: 650, branches: 1612 },
    { month: 'Jun', newCustomers: 26, totalPar: 3.3, par0: 1.8, par30: 1.0, par60: 0.4, par90: 0.1, glp: 9700, disb: 740, lastYearDisb: 680, branches: 1615 },
    { month: 'Jul', newCustomers: 28, totalPar: 3.4, par0: 1.9, par30: 1.1, par60: 0.3, par90: 0.1, glp: 9900, disb: 760, lastYearDisb: 700, branches: 1618 },
    { month: 'Aug', newCustomers: 30, totalPar: 3.5, par0: 2.0, par30: 1.1, par60: 0.3, par90: 0.1, glp: 10100, disb: 780, lastYearDisb: 720, branches: 1622 },
    { month: 'Sep', newCustomers: 32, totalPar: 3.6, par0: 2.0, par30: 1.2, par60: 0.3, par90: 0.1, glp: 10300, disb: 800, lastYearDisb: 750, branches: 1625 },
    { month: 'Oct', newCustomers: 33, totalPar: 3.7, par0: 2.0, par30: 1.2, par60: 0.4, par90: 0.1, glp: 10500, disb: 850, lastYearDisb: 780, branches: 1628 },
    { month: 'Nov', newCustomers: 34, totalPar: 3.8, par0: 2.1, par30: 1.2, par60: 0.4, par90: 0.1, glp: 10800, disb: 900, lastYearDisb: 800, branches: 1632 },
    { month: 'Dec', newCustomers: 35, totalPar: 3.9, par0: 2.1, par30: 1.3, par60: 0.4, par90: 0.1, glp: 11034, disb: 950, lastYearDisb: 820, branches: 1636 },
];

const TrendsDashboard = () => {
    // Transform historical data for charts
    const historicalChartData = HISTORICAL_DATA.map(d => ({
        ...d,
        profit: d.profit === '-' ? 0 : Number(d.profit),
        borrowing: d.borrowing === '-' ? 0 : Number(d.borrowing),
        gnpa: typeof d.gnpa === 'string' ? parseFloat(d.gnpa.replace('%', '')) : 0,
        branches: Number(d.branches)
    }));

    return (
        <div className="space-y-8">
            <div className="flex items-center justify-between">
                <div>
                    <h2 className="text-2xl font-bold text-secondary-900">Growth Trends</h2>
                    <p className="text-secondary-500">Historical performance & FY25 analysis</p>
                </div>
                <div className="bg-white border border-secondary-300 rounded-lg px-3 py-2 text-sm text-secondary-700 font-medium">
                    FY 2025
                </div>
            </div>

            {/* Historical Section */}
            <div>
                <h3 className="text-lg font-bold text-secondary-800 mb-4 flex items-center gap-2">
                    <History size={20} className="text-primary-600" /> Annual Performance (FY21 - FY25)
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    {/* Branch Growth */}
                    <div className="bg-white p-5 rounded-xl border border-secondary-200 shadow-sm">
                        <div className="text-sm font-semibold text-secondary-600 mb-4">Network Scale (Branches)</div>
                        <ResponsiveContainer width="100%" height={250}>
                            <BarChart data={historicalChartData}>
                                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                                <XAxis dataKey="year" tick={{ fontSize: 11 }} />
                                <YAxis />
                                <Tooltip contentStyle={{ borderRadius: 8 }} />
                                <Bar dataKey="branches" fill="#3b82f6" radius={[4, 4, 0, 0]} name="Branches" />
                            </BarChart>
                        </ResponsiveContainer>
                    </div>

                    {/* Financials */}
                    <div className="bg-white p-5 rounded-xl border border-secondary-200 shadow-sm">
                        <div className="text-sm font-semibold text-secondary-600 mb-4">Financial Growth (₹ Cr)</div>
                        <ResponsiveContainer width="100%" height={250}>
                            <ComposedChart data={historicalChartData}>
                                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                                <XAxis dataKey="year" tick={{ fontSize: 11 }} />
                                <YAxis yAxisId="left" />
                                <YAxis yAxisId="right" orientation="right" />
                                <Tooltip contentStyle={{ borderRadius: 8 }} />
                                <Legend />
                                <Bar yAxisId="left" dataKey="borrowing" fill="#94a3b8" name="Borrowing" radius={[4, 4, 0, 0]} />
                                <Line yAxisId="right" type="monotone" dataKey="profit" stroke="#10b981" strokeWidth={3} name="Op. Profit" dot={{ r: 4 }} />
                            </ComposedChart>
                        </ResponsiveContainer>
                    </div>

                    {/* Asset Quality */}
                    <div className="bg-white p-5 rounded-xl border border-secondary-200 shadow-sm">
                        <div className="text-sm font-semibold text-secondary-600 mb-4">Asset Quality (GNPA %)</div>
                        <ResponsiveContainer width="100%" height={250}>
                            <LineChart data={historicalChartData}>
                                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                                <XAxis dataKey="year" tick={{ fontSize: 11 }} />
                                <YAxis domain={[0, 7]} />
                                <Tooltip contentStyle={{ borderRadius: 8 }} formatter={(val) => `${val}%`} />
                                <Line type="monotone" dataKey="gnpa" stroke="#ef4444" strokeWidth={3} name="GNPA %" dot={{ r: 4 }} />
                            </LineChart>
                        </ResponsiveContainer>
                    </div>
                </div>
            </div>

            {/* Monthly Trends (FY25) */}
            <div>
                <h3 className="text-lg font-bold text-secondary-800 mb-4 flex items-center gap-2">
                    <TrendingUp size={20} className="text-emerald-600" /> FY25 Monthly Trajectory
                </h3>

                {/* Summary Cards */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                    <div className="bg-gradient-to-br from-primary-500 to-primary-600 p-6 rounded-xl text-white shadow-lg">
                        <div className="flex items-center justify-between mb-2">
                            <Wallet size={24} />
                            <span className="text-xs bg-white/20 px-2 py-1 rounded-full">FY25 Closing</span>
                        </div>
                        <div className="text-3xl font-bold">₹{COMPANY_METRICS.currentGLP.toLocaleString()} Cr</div>
                        <div className="text-sm opacity-90">Total AUM</div>
                        <div className="mt-2 text-xs opacity-75">Target Achieved</div>
                    </div>

                    <div className="bg-gradient-to-br from-emerald-500 to-emerald-600 p-6 rounded-xl text-white shadow-lg">
                        <div className="flex items-center justify-between mb-2">
                            <Users size={24} />
                            <span className="text-xs bg-white/20 px-2 py-1 rounded-full">Base</span>
                        </div>
                        <div className="text-3xl font-bold">{(COMPANY_METRICS.activeClients / 1000000).toFixed(1)} Mn</div>
                        <div className="text-sm opacity-90">Active Clients</div>
                        <div className="mt-2 text-xs opacity-75">Broad based growth</div>
                    </div>

                    <div className="bg-gradient-to-br from-rose-500 to-rose-600 p-6 rounded-xl text-white shadow-lg">
                        <div className="flex items-center justify-between mb-2">
                            <TrendingUp size={24} />
                            <span className="text-xs bg-white/20 px-2 py-1 rounded-full">FY25</span>
                        </div>
                        <div className="text-3xl font-bold">{COMPANY_METRICS.gnpa}%</div>
                        <div className="text-sm opacity-90">GNPA</div>
                        <div className="mt-2 text-xs opacity-75">Maintained below 3%</div>
                    </div>
                </div>

                {/* Portfolio Growth Chart */}
                <div className="bg-white p-6 rounded-xl border border-secondary-200 shadow-sm mb-6">
                    <h3 className="text-sm font-semibold text-secondary-800 mb-4">Portfolio Growth (GLP in Crores)</h3>
                    <ResponsiveContainer width="100%" height={300}>
                        <AreaChart data={trendsData}>
                            <defs>
                                <linearGradient id="colorGlp" x1="0" y1="0" x2="0" y2="1">
                                    <stop offset="5%" stopColor="#0ea5e9" stopOpacity={0.8} />
                                    <stop offset="95%" stopColor="#0ea5e9" stopOpacity={0} />
                                </linearGradient>
                            </defs>
                            <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                            <XAxis dataKey="month" stroke="#6b7280" />
                            <YAxis stroke="#6b7280" />
                            <Tooltip contentStyle={{ borderRadius: 8 }} formatter={(val) => `₹${val} Cr`} />
                            <Area type="monotone" dataKey="glp" stroke="#0ea5e9" fillOpacity={1} fill="url(#colorGlp)" />
                        </AreaChart>
                    </ResponsiveContainer>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {/* Disbursement */}
                    <div className="bg-white p-6 rounded-xl border border-secondary-200 shadow-sm">
                        <h3 className="text-sm font-semibold text-secondary-800 mb-4">Monthly Disbursement (₹ Cr)</h3>
                        <ResponsiveContainer width="100%" height={300}>
                            <BarChart data={trendsData}>
                                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                                <XAxis dataKey="month" stroke="#6b7280" />
                                <YAxis stroke="#6b7280" />
                                <Tooltip contentStyle={{ borderRadius: 8 }} formatter={(val) => `₹${val} Cr`} />
                                <Legend />
                                <Bar dataKey="disb" fill="#10b981" name="FY25" radius={[4, 4, 0, 0]} />
                            </BarChart>
                        </ResponsiveContainer>
                    </div>

                    {/* PAR Breakdown */}
                    <div className="bg-white p-6 rounded-xl border border-secondary-200 shadow-sm">
                        <h3 className="text-sm font-semibold text-secondary-800 mb-4">Portfolio Risk Evolution</h3>
                        <ResponsiveContainer width="100%" height={300}>
                            <LineChart data={trendsData}>
                                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                                <XAxis dataKey="month" stroke="#6b7280" />
                                <YAxis stroke="#6b7280" />
                                <Tooltip contentStyle={{ borderRadius: 8 }} formatter={(val) => `${val}%`} />
                                <Legend />
                                <Line type="monotone" dataKey="totalPar" stroke="#ef4444" strokeWidth={2} name="Total PAR" />
                                <Line type="monotone" dataKey="par30" stroke="#f59e0b" strokeWidth={2} name="PAR 30+" />
                            </LineChart>
                        </ResponsiveContainer>
                    </div>
                </div>
            </div>
        </div>
    );
};

// Helper for AreaChart import
import { AreaChart } from 'recharts';

export default TrendsDashboard;
