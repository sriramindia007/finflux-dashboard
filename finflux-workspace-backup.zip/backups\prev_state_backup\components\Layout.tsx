import { useNavigate, useLocation, Outlet, NavLink } from 'react-router-dom';
import { LayoutDashboard, Map, TrendingUp, LogOut, Menu, Building2, PieChart } from 'lucide-react';
import { cn } from '../lib/utils';
import { useState } from 'react';

const Layout = () => {
    const [sidebarOpen, setSidebarOpen] = useState(true);
    const navigate = useNavigate();
    const location = useLocation();

    const handleLogout = () => {
        // Add auth logic here
        navigate('/login');
    };

    const navItems = [
        { path: '/home', icon: LayoutDashboard, label: 'Home Dashboard' },
        { path: '/geo', icon: Map, label: 'Geo Drill' },
        { path: '/branch', icon: Building2, label: 'Branch View' },
        { path: '/trends', icon: TrendingUp, label: 'Trends' },
        { path: '/portfolio', icon: PieChart, label: 'Portfolio Quality' }, // New Link
    ];

    return (
        <div className="flex h-screen bg-secondary-50 text-secondary-900 overflow-hidden">
            {/* Sidebar */}
            <aside
                className={cn(
                    "bg-white border-r border-secondary-200 transition-all duration-300 flex flex-col z-20",
                    sidebarOpen ? "w-64" : "w-20"
                )}
            >
                <div className="p-4 border-b border-secondary-200 flex items-center justify-between h-16">
                    {sidebarOpen ? (
                        <div className="font-bold text-xl text-primary-600 tracking-tight">FINFLUX</div>
                    ) : (
                        <div className="text-xl font-bold text-primary-600 mx-auto">F</div>
                    )}
                    <button onClick={() => setSidebarOpen(!sidebarOpen)} className="p-1 hover:bg-secondary-100 rounded-md text-secondary-500">
                        <Menu size={20} />
                    </button>
                </div>

                <nav className="flex-1 p-4 space-y-2">
                    {navItems.map((item) => (
                        <NavLink
                            key={item.path}
                            to={item.path}
                            className={({ isActive }) => cn(
                                "flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all duration-200 group",
                                isActive
                                    ? "bg-primary-50 text-primary-700 shadow-sm ring-1 ring-primary-200/50"
                                    : "text-secondary-600 hover:bg-secondary-100 hover:text-secondary-900"
                            )}
                        >
                            <item.icon size={22} className={cn("shrink-0 transition-colors", location.pathname === item.path ? "text-primary-600" : "text-secondary-400 group-hover:text-secondary-600")} />
                            {sidebarOpen && <span className="font-medium">{item.label}</span>}
                        </NavLink>
                    ))}
                </nav>

                <div className="p-4 border-t border-secondary-200">
                    <button
                        onClick={handleLogout}
                        className={cn(
                            "flex items-center gap-3 px-3 py-2.5 rounded-lg transition-colors w-full text-left text-danger hover:bg-danger/10",
                            !sidebarOpen && "justify-center"
                        )}
                    >
                        <LogOut size={22} className="shrink-0" />
                        {sidebarOpen && <span className="font-medium">Logout</span>}
                    </button>
                </div>
            </aside>

            {/* Main Content */}
            <main className="flex-1 flex flex-col min-w-0 overflow-hidden">
                {/* Header */}
                <header className="h-16 bg-white border-b border-secondary-200 flex items-center justify-between px-6 shrink-0">
                    <h1 className="text-lg font-semibold text-secondary-800">
                        {navItems.find(i => i.path === location.pathname)?.label || 'Dashboard'}
                    </h1>
                    <div className="flex items-center gap-4">
                        <div className="text-sm text-right hidden sm:block">
                            <div className="font-medium text-secondary-900">Sriram (Admin)</div>
                            <div className="text-xs text-secondary-500">Head Office</div>
                        </div>
                        <div className="w-9 h-9 bg-primary-100 text-primary-700 rounded-full flex items-center justify-center font-bold text-sm">
                            SR
                        </div>
                    </div>
                </header>

                {/* Content Scroll Area */}
                <div className="flex-1 overflow-auto p-6 scroll-smooth">
                    <Outlet />
                </div>
            </main>
        </div>
    );
};

export default Layout;
